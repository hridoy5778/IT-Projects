<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:login.php');
exit();
}
$employeer = $_SESSION['login'];
$email = $_REQUEST['email'];
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM seekerreg WHERE email='$email' AND status='active'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
$i = 0;
$name = mysql_result($result,$i,"name");
$address = mysql_result($result,$i,"address");
$email = mysql_result($result,$i,"email");
$phone = mysql_result($result,$i,"phone");
$mobile = mysql_result($result,$i,"mobile");
$web = mysql_result($result,$i,"web");
$others = mysql_result($result,$i,"others");
$lastdegree = mysql_result($result,$i,"lastdegree");
$cv = mysql_result($result,$i,"cv");
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="100%" border="0">
 <tr> 
    <td valign="top">
	<form action="" method="post" target="_self" enctype="multipart/form-data">
	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
    <td>Applicant Name</td>
    <td><input name="name" type="text" value="<?php echo $name;?>"></td>
  </tr>
  <tr>
    <td>Email Address</td>
    <td><input name="email" type="text" value="<?php echo $email;?>"></td>
  </tr>
  <tr>
    <td>Height Degree</td>
    <td><input name="lastdegree" type="text" value="<?php echo $lastdegree;?>"></td>
  </tr>
  <tr>
    <td>Phone Number</td>
    <td><input name="phone" type="text" value="<?php echo $phone;?>"></td>
  </tr>
  <tr>
    <td>Mobile Number</td>
    <td><input name="mobile" type="text" value="<?php echo $mobile;?>"></td>
  </tr>
  <tr>
    <td valign="top">Applicant Address</td>
    <td><textarea name="address" cols="18" rows="8"><?php echo $address;?></textarea></td>
  </tr>
  <tr>
    <td>Others Qualifications</td>
    <td><textarea name="others" cols="18" rows="8"><?php echo $others;?></textarea></td>
  </tr>
  <tr>
    <td>Web Site</td>
    <td><input name="web" type="text" value="<?php echo $web;?>"></td>
  </tr>
  
  
  <tr>
    <td></td>
            <td><a href="./cv/<?php echo $cv;?>">Download CV</a></td>
  </tr>
</table>

	
	</form>
	</td>
  </tr>
</table>

</body>
</html>
