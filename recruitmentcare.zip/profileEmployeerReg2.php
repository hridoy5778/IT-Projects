<?php session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
$email = $_REQUEST['email'];
$company = $_REQUEST['company'];
$name = $_REQUEST['name'];
$phone = $_REQUEST['phone'];
$mobile = $_REQUEST['mobile'];
$address = $_REQUEST['address'];
$city = $_REQUEST['city'];
$postcode = $_REQUEST['postcode'];
$password = $_REQUEST['password'];
$web = $_REQUEST['web'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "UPDATE employeerreg SET company='$company',name='$name',phone='$phone',mobile='$mobile',address='$address',city='$city',postcode='$postcode',web='$web' WHERE email='$email'";
$result = mysql_query($query);

$query2 = "UPDATE card SET pin='$password' WHERE email='$email'";
$result2 = mysql_query($query2);

?>
</head>

<body>
<table width="100%" border="0">
<tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td height="40%" bgcolor="#3333FF" colspan="2"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  
  <?php include_once('Employeermenu.htm'); ?>
  
  <tr>
    <td align="right" valign="top"></td>
  </tr>
  <tr>
    <td>Updation Completed...</td>
  </tr>
  
</table>

</body>
</html>
