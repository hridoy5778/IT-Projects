<table width="100%" border="3" cellspacing="0" cellpadding="3">
  <tr bgcolor="#FFFFFF"> 
    <td align="center" valign="middle" bordercolor="#663300"><a href="./admin/activation1.php" target="_self"><font face="Arial, Helvetica, sans-serif">Account 
      Activation</font></a></td>
	  
    <td align="center" valign="middle" bordercolor="#663300"><a href="./admin/searchjobStatus.php" target="_self"><font face="Arial, Helvetica, sans-serif">Job 
      Activation</font></a></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="./admin/category1.php" target="_self">Add 
      Job Category</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="./admin/subcategory1.php" target="_self">Add 
      Sub Category</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="./admin/cityname.php" target="_self">Add 
      City</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="./admin/lastdegree1.php" target="_self">Add 
      Degree Name</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="showPage.php" target="_self">Contents</a></font></td>
  </tr>
</table>
