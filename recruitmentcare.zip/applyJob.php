<?php session_start();
if(!isset($_SESSION['login']))
{
$maincategory = $_REQUEST['maincategory'];
$subcategory = $_REQUEST['subcategory'];
$city = $_REQUEST['city'];
$type = $_REQUEST['type'];
$frequency = $_REQUEST['frequency'];
//echo $type;
//echo $frequency;
//echo $city;
//exit();
header('location:signin.php?maincategory='.$maincategory.'&subcategory='.$subcategory.'&city='.$city.'&type='.$type.'&frequency='.$frequency);
exit();
}
$jobref = $_REQUEST['jobref'];
$employeer = $_REQUEST['employeer'];
$seeker = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <?php 
if(!isset($_SESSION['login']))
{?>
  <tr> 
    <td align="right" valign="top" colspan="3"><a href="signin.php" target="_self">SignIn/Register</a></td>
  </tr>
  <?php } else {?>
  <tr> 
    <td width="16%" align="right" valign="top">&nbsp;</td>
    <td width="78%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
    <td width="6%"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <?php }?>
  <tr> 
    <td colspan="3" align="center">Banner</td>
  </tr>
  <tr> 
    <td align="center" valign="top">Left Pane</td>
    <td align="center" valign="top"> 
      <?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "INSERT INTO applications (jobref,employeer,seeker) VALUES ('$jobref','$employeer','$seeker')";
mysql_query($query);

mysql_close();
?>
      <h3>Your job application has been successfully posted......</h3>
      <br> <br>
      Thank You. <br> </td>
    <td align="center" valign="top">Right Pane</td>
  </tr>
  <tr>
    <td align="center" valign="top">&nbsp;</td>
    <td align="left" valign="top"><a href="jobSector.php" target="_self">Bact 
      to Job search Page</a></td>
    <td align="center" valign="top">&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>
