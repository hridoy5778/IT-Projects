<table width="100%" border="0" cellspacing="0" cellpadding="0">
<?php 
if(isset($_SESSION['login']))
{?>
<tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="logout.php" target="_self">Logout</a></td>
 </tr>
 <?php } else {?>
 <tr>
    <td align="right" valign="top"><font face="Arial, Helvetica, sans-serif"><a href="signin.php" target="_self">Sign 
      In / Register</a></font></td>
  </tr> <?php }?>
</table>

