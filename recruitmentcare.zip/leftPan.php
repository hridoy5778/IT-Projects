<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p>Click on the page title below to edit.</p>
<table width="217" border="2" height="10%">
  <tr> 
    <td width="205"><a href = "showPage.php?id=1">Edit Clients</a></td>
  </tr>
  <tr> 
    <td><a href = "showPage.php?id=2">Edit Services</a></td>
  </tr>
  <tr> 
    <td><a href = "showPage.php?id=3">Edit Contact</a></td>
  </tr>
  <tr> 
    <td><a href = "showPage.php?id=4">Edit Help</a></td>
  </tr>
 
</table>
</body>
</html>
