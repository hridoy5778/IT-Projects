<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
$email = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT DISTINCT name FROM jobcategory";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query2 = "SELECT DISTINCT name FROM jobsubcategory";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
$query3 = "SELECT * FROM city WHERE status='a'";
$result3 = mysql_query($query3);
$num3 = mysql_num_rows($result3);
mysql_close();
?>
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td height="40%" bgcolor="#3333FF" colspan="2"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <?php include_once('Employeermenu.htm'); ?>
  <tr><td width="100%" align="center" colspan="2"></td></tr>
  <tr>
    <td align="left" valign="top"><form action="addjob2.php" method="post" target="_self">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>Post Name</td>
    <td><input name="name" type="text"></td>
  </tr>
  <tr>
    <td>Vacancy</td>
    <td><input name="vacancy" type="text"></td>
  </tr>
  <tr>
    <td>Category</td>
    <td><select name="maincategory">
	<option>Select&nbsp;&nbsp;Category</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?></select></td>
  </tr>
  <tr>
    <td>Sub Category</td>
    <td><select name="subcategory">
	<option>Select Sub Category</option>
		<?php
	   $i2=0;
while ($i2 < $num2) 
{
$name = mysql_result($result2,$i2,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i2++;
}
?></select></td>
  </tr>
  <tr>
    <td>City Name</td>
    <td><select name="city">
	<option>Select City</option>
		<?php
	   $i3=0;
while ($i3 < $num3) 
{
$name = mysql_result($result3,$i3,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i3++;
}
?></select></td>
  </tr>
  <tr>
    <td>Post Code</td>
    <td><input name="postcode" type="text"></td>
  </tr>
  <tr>
    <td>Job Type</td>
    <td><select name="type">
	<option>Select Job Type</option>
		<option>Permanent</option>
		<option>Part Time</option>
		<option>Contract</option>
		<option>Temporary</option>
		</select></td>
  </tr>
  <tr>
    <td>Salary</td>
    <td><input name="salary" type="text"></td>
  </tr>
  <tr>
    <td valign="top">Description</td>
    <td><textarea name="description" cols="" rows="10"></textarea></td>
  </tr>
  
  <tr>
    <td>Payment Frequency</td>
    <td><select name="frequency">
	<option>Select frequency Type</option>
		<OPTION>Per Annum</OPTION> <OPTION>Per Month</OPTION> 
  <OPTION>Per Week</OPTION> <OPTION>Per Day</OPTION> <OPTION>Per Hour</OPTION>
		</select></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td><input name="email" type="hidden" value="<?php echo $email;?>"></td>
  </tr>
  <tr>
    <td><input name="status" type="hidden" value="Inactive"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><input name="" type="submit"></td>
    <td><input name="" type="reset"></td>
  </tr>
</table>
</form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
