<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<?php
$company = $_POST['company'];
$name = $_POST['name'];
$address = $_POST['address'];
$status = $_POST['status'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$mobile = $_POST['mobile'];
$web = $_POST['web'];
$city = $_POST['city'];
$postcode = $_POST['postcode'];
$password = $_POST['password'];
$role = $_POST['role'];
include_once('config.php');
?>
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr align="center" bgcolor="#3333CC">
  <td width="29%" bgcolor="#3333FF"></td> 
    <td width="54%" height="40%" valign="top" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong>  
	  <td width="17%" valign="top" bgcolor="#3333FF"><div align="right"><strong><font size="4" face="Arial, Helvetica, sans-serif"><a href="/admin/" target="_self">Admin 
        Panel</a></font></strong></div></td>
  </tr>
  <tr> 
    <td align="center" colspan="3" bgcolor="#3333CC"> 
      <?php include_once('menu.php'); ?>
    </td>
  </tr>
  <tr>
    <td align="right" valign="top">
	<?php
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM card WHERE email = '$email'";
$result = mysql_query($query);
//echo $result;
$num = mysql_num_rows($result);
if($num<1)
{

$query2 = "insert into employeerreg (company,name,address,email,phone,mobile,web,status,city,postcode) values('$company','$name','$address','$email','$phone','$mobile','$web','$status','$city','$postcode')";
$result = mysql_query($query2);
//$carry = mysql_insert_id($dbconnection);

$query3 = "insert into card (pin,email,status,role) values('$password','$email','$status','$role')";
$result3 = mysql_query($query3);
mysql_close();?>
</td>
  </tr>
  
 <tr><td>Thank You for Registering<br>
      Your email is:&nbsp;<?php echo $email;?><br>
Your Password is :&nbsp;<?php echo $password;?><br>
You will be allowed to post any Job<br>
Please remember your email Id & password.<br>
Call for details 00-0000
<br>
Email has been sent with your Username and password..
<?php 
$to = $email;
$subject = "UserName/Pass from evolutionandRecruitment";
$message = "Hello! This is from Evolution care and recruitment."."\n\n"."User Name:  ".$email."\n\n"."Password:  ".$pin."\n\n\n\n"."Thank you";
$from = "jobs@evolutioncareandrecruitment.com";
$server = 'smtp.fasthosts.co.uk';
//$headers = "From: $from";
//mail($to,$subject,$message,$headers);
//ini_set("sendmail_from",$from);
ini_set("sendmail_from", " jobs@evolutioncareandrecruitment.com ");
mail($to, "UserName/Pass from evolutionandRecruitment", $message, "From: jobs@evolutioncareandrecruitment.com\nReply-To: " . $email . "\nX-Mailer: PHP/" . phpversion() );
} else {?></td></tr>
<tr>
    <td>Sorry! Your given email address is existed.<br>
      Please try to <a href="employeerReg.php" target="_self">Register</a> with 
      another email address. 
      <?php }?>
    </td>
  </tr>

  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
