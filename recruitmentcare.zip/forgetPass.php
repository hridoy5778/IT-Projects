<?php
session_start();
if(isset($_SESSION['login']))
{
unset($_SESSION['login']);
session_destroy();
}


?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td align="right" valign="top"></td>
  </tr>
  <tr align="center" bgcolor="#3333CC"> 
    <td height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
	  <td width="11%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><a href="/admin/" target="_self">Admin 
      Panel</a></font></strong></td>
  </tr>
  <tr> 
    <td align="center" colspan="2"> 
      <?php include_once('menu.php'); ?>
    </td>
  </tr>
  <tr> 
    <td colspan="2"><?php include_once('config.php');
	$email = $_POST['email'];
	mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM card WHERE email = '$email'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$i=0;
$pin = mysql_result($result,$i,"pin");
if($num>0)
{
$to = $email;
$subject = "UserName/Pass from evolutionandRecruitment";
$message = "Hello! This is from Evolution care and recruitment."."\n\n"."User Name:  ".$email."\n\n"."Password:  ".$pin."\n\n\n\n"."Thank you";
$from = "jobs@evolutioncareandrecruitment.com";
$server = 'smtp.fasthosts.co.uk';
//$headers = "From: $from";
//mail($to,$subject,$message,$headers);
//ini_set("sendmail_from",$from);
ini_set("sendmail_from", " jobs@evolutioncareandrecruitment.com ");
mail($to, "UserName/Pass from evolutionandRecruitment", $message, "From: jobs@evolutioncareandrecruitment.com\nReply-To: " . $email . "\nX-Mailer: PHP/" . phpversion() );

//mail($to,$subject,$message,"From: $from",$server);
	
?>	
	</td>
  </tr>
  <tr> 
    <td>The password has been sent to your email.<br>
Thank you from evolutioncareandrecruitment.com
<?php } else{?>
Sorry..<br>
      You are not registered with us. Free <a href="signin.php" target="_self">Signup</a> 
   <?php }?> </td>
  </tr>
</table>

</body>
</html>
