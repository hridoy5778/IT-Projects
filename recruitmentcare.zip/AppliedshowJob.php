<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
$seeker = $_SESSION['login'];

?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM job WHERE email IN (select employeer from applications where seeker = '$seeker')";
$result = mysql_query($query);
$num = mysql_num_rows($result);

?>
</head>
<body>
<table width="100%" border="0">
<tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?></td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td colspan="2" height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <?php include_once('Seekermenu.htm');?> 
  <tr>
    <td colspan="2"><?php mysql_close();

if($num>0)
{
$i=0;

while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$employeer = mysql_result($result,$i,"email");
$name = mysql_result($result,$i,"name");
$city = mysql_result($result,$i,"city");
$salary = mysql_result($result,$i,"salary");
$frequency = mysql_result($result,$i,"frequency");
$type = mysql_result($result,$i,"type");
$description = mysql_result($result,$i,"description");
?>
            
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr bgcolor="#FFFFFF"> 
                <td colspan="2" align="center" bgcolor="#FFFFFF"></td>
                <td width="27%" bgcolor="#FFFFFF"></td>
              </tr>
              <tr align="left" valign="top" bgcolor="#CCCCCC"> 
                <td><font color="#0099FF" size="3"><strong>Job Position:</strong></font><font color="#000000"><strong><?php echo $name;?></strong></font></td>
                <td>&nbsp;</td>
                <td><strong><font color="#0099FF">Ref:</font></strong><strong><font color="#000000"> 
                  <?php echo $id;?></font></strong></td>
              </tr>
              <tr align="right" bgcolor="#FFFFFF"> 
                <td valign="top"><div align="left"></div></td>
                <td valign="top">&nbsp;</td>
                <td align="left" valign="top">&nbsp;</td>
              </tr>
              <tr align="left" valign="top" bgcolor="#FFFFFF"> 
                <td width="37%"><strong><font color="#0099FF">Location</font></strong><font color="#0099FF"><strong>:</strong></font><strong><font color="#000000"> 
                  <?php echo $city;?></font></strong></td>
                <td width="36%"><strong><font color="#0099FF">Salary</font></strong><font color="#0099FF"><strong>:</strong></font><font color="#000000"><strong> 
                  <?php echo $salary;?>&nbsp;&nbsp;<?php echo $frequency;?></strong></font></td>
                <td><font color="#0099FF"><strong>Type: </strong></font><font color="#000000"><strong><?php echo $type;?></strong></font></td>
              </tr>
              <tr align="left" valign="top" bgcolor="#FFFFFF"> 
                <td colspan="2" valign="top"><font color="#0099FF"><strong>Description:</strong></font><strong><font color="#000000"> 
                  <?php echo $description;?></font></strong></td>
                <td valign="middle"></td>
              </tr>
            </table>

<?php 
$i++; 
}
}
else
{
echo "Sorry No job available";}?>
</td>
  </tr>
  <tr>
    <td align="left" valign="top"></td>
	
  </tr>
</table>

</body>
</html>
