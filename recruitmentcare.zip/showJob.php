<?php session_start();?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php

if(!isset($_REQUEST['description']))
{
$maincategory = $_REQUEST['maincategory'];
$subcategory = $_REQUEST['subcategory'];
$city = $_REQUEST['city'];
$type = $_REQUEST['type'];
$frequency = $_REQUEST['frequency'];
$post = $_REQUEST['post'];
$rop = $_REQUEST['rop'];
if($maincategory == "All")
{
$maincategory="%";
}
if($subcategory == "All")
{
$subcategory="%";
}
if($city == "All")
{
$city="%";
}
if($type == "All")
{
$type="%";
}
if($frequency == "All")
{
$frequency="%";
}
if($post == "")
{
if($rop=="title")
{
$post="%";
$description="%";
}
else
{
$post="%";
$description="%";
}
}
else
{
if($rop=="title")
{
$post="%".$post."%";
}
else
{
$post="%".$post."%";
$description="%".$post."%";
}
}
}
else
{
$maincategory = $_REQUEST['maincategory'];
$subcategory = $_REQUEST['subcategory'];
$city = $_REQUEST['city'];
$type = $_REQUEST['type'];
$frequency = $_REQUEST['frequency'];
$post = $_REQUEST['post'];
$rop = $_REQUEST['rop'];
$description = $_REQUEST['description'];
}
$maincategoryN = $maincategory;
$subcategoryN = $subcategory;
$cityN = $city;
$typeN = $type;
$frequencyN = $frequency;
$postN = $post;
$ropN = $rop;
$descriptionN = $description;


?>
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<?php 
if(!isset($_SESSION['login']))
{?>
  <tr>
    <td align="right" valign="top" colspan="3" bgcolor="#3333CC"><a href="signin.php" target="_self"><font face="Arial, Helvetica, sans-serif" color="#FFFFFF"><strong>SignIn/Register</strong></font></a></td>
  </tr><?php } else {?>
  <tr>
    <td width="20%" align="right" valign="top">&nbsp;</td>
	<td width="69%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="11%"><a href="signin.php" target="_self">Logout</a></td>
  </tr><?php }?>
  <tr align="center" bgcolor="#3333CC">
  <td bgcolor="#3333FF"></td> 
    <td height="40%" valign="top" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong> 
	  <td valign="top" bgcolor="#3333FF"><div align="right"><strong><font size="4" face="Arial, Helvetica, sans-serif"><a href="/admin/" target="_self">Admin 
        Panel</a></font></strong></div></td>
  </tr>
  <tr><td align="center" colspan="3"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="left" valign="top" width="20%"><?php include_once('searchjob.php');?></td>
	<td align="center" valign="top" width="69%">
	<table width="106%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td valign="top" align="center"><strong><font size="5">Jobs search result</font></strong><br>
            <strong><font size="3">Please login for applying any job.</font></strong><br>
			
              <?php 
	include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query2 = "SELECT * FROM job WHERE maincategory LIKE '$maincategory' AND subcategory LIKE '$subcategory' AND status='active' AND city LIKE '$city' AND type LIKE '$type' AND frequency LIKE '$frequency' AND name LIKE '$post' AND description LIKE '$description'";
$query = "SELECT * FROM job WHERE maincategory LIKE '$maincategory' AND subcategory LIKE '$subcategory' AND status='active' AND city LIKE '$city' AND type LIKE '$type' AND frequency LIKE '$frequency' AND name LIKE '$post' AND description LIKE '$description'";
$result2 = mysql_query($query2);
$result = mysql_query($query);
$num = mysql_numrows($result);
$num2 = mysql_numrows($result2);
mysql_close();
if($num>0)
{
if($num>10)
{
$pageM=$num%10;
$pageD=$num/10;
if($pageM==0)
{
$page = $pageD;
//echo $page;
}
else
{

$page = $pageD+1;
//echo ((int)$page);
}
}
else
{
}
if(isset($_REQUEST['next']))
{
$i=$_REQUEST['next'];
$prev = $i-10;
}
else
{
$i=0;
}
$stop = 0;
while ($i < $num) 
{

$id = mysql_result($result,$i,"id");
$employeer = mysql_result($result,$i,"email");
$name = mysql_result($result,$i,"name");
$city = mysql_result($result,$i,"city");
$salary = mysql_result($result,$i,"salary");
$frequency = mysql_result($result,$i,"frequency");
$type = mysql_result($result,$i,"type");
$description = mysql_result($result,$i,"description");
?>
            
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr bgcolor="#FFFFFF"> 
                <td colspan="2" align="center" bgcolor="#FFFFFF"></td>
                <td width="27%" bgcolor="#FFFFFF"></td>
              </tr>
              <tr align="left" valign="top" bgcolor="#CCCCCC"> 
                <td><font color="#0099FF" size="3"><strong>Job Position:</strong></font><font color="#000000"><strong><?php echo $name;?></strong></font></td>
                <td>&nbsp;</td>
                <td><strong><font color="#0099FF">Ref:</font></strong><strong><font color="#000000"> 
                  <?php echo $id;?></font></strong></td>
              </tr>
              <tr align="right" bgcolor="#FFFFFF"> 
                <td valign="top"><div align="left"></div></td>
                <td valign="top">&nbsp;</td>
                <td align="left" valign="top">&nbsp;</td>
              </tr>
              <tr align="left" valign="top" bgcolor="#FFFFFF"> 
                <td width="37%"><strong><font color="#0099FF">Location</font></strong><font color="#0099FF"><strong>:</strong></font><strong><font color="#000000"> 
                  <?php echo $city;?></font></strong></td>
                <td width="36%"><strong><font color="#0099FF">Salary</font></strong><font color="#0099FF"><strong>:</strong></font><font color="#000000"><strong> 
                  <?php echo $salary;?>&nbsp;&nbsp;<?php echo $frequency;?></strong></font></td>
                <td><font color="#0099FF"><strong>Type: </strong></font><font color="#000000"><strong><?php echo $type;?></strong></font></td>
              </tr>
              <tr align="left" valign="top" bgcolor="#FFFFFF"> 
                <td colspan="2" valign="top"><font color="#0099FF"><strong>Description:</strong></font><strong><font color="#000000"> 
                  <?php echo $description;?></font></strong></td>
                <td valign="middle"><a href="applyJob.php?maincategory=<?php echo $maincategory;?>&subcategory=<?php echo $subcategory;?>&type=<?php echo $type;?>&frequency=<?php echo $frequency;?>&city=<?php echo $city;?>&jobref=<?php echo $id;?>&employeer=<?php echo $employeer;?>"><img src="image/apply.gif" border="0"></a></td>
              </tr>
            </table>

<?php
$stop = $stop+1;
if($stop==10 || $i==($num-1))
{
$next = $i;
if($i<($num-1)){
?>
<a href="showJob.php?next=<?php echo $next+1; ?>&maincategory=<?php echo $maincategoryN;?>&subcategory=<?php echo $subcategoryN;?>&type=<?php echo $typeN;?>&frequency=<?php echo $frequencyN;?>&city=<?php echo $cityN;?>&post=<?php echo $postN;?>&rop=<?php echo $ropN;?>&description=<?php echo $descriptionN;?>" target="_self">Next</a>
<?php } if(isset($_REQUEST['next']) && $prev>=0)
{?>
<a href="showJob.php?next=<?php echo $prev; ?>&maincategory=<?php echo $maincategoryN;?>&subcategory=<?php echo $subcategoryN;?>&type=<?php echo $typeN;?>&frequency=<?php echo $frequencyN;?>&city=<?php echo $cityN;?>&post=<?php echo $postN;?>&rop=<?php echo $ropN;?>&description=<?php echo $descriptionN;?>" target="_self">Previous</a>
<?php }?>
<?php 
exit();
} 
$i++; 
}

?>

<?php }
else
{
echo "Sorry No job available";}?>
</td>
  </tr>
</table>
	</td>
	
  </tr>
  
</table>

</body>
</html>
