<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<?php
ini_set("sendmail_from", " jobs@evolutioncareandrecruitment.com ");
//mail("jobs@evolutioncareandrecruitment.com","Form from " . $email , $message , "From: jobs@evolutioncareandrecruitment.com\nReply-To: " . $email . "\nX-Mailer: PHP/" . phpversion() ); 

mail($_POST['email'], "Feedback Form results" . $email, $_POST['message'], "From: jobs@evolutioncareandrecruitment.com\nReply-To: " . $email . "\nX-Mailer: PHP/" . phpversion() );


?>

</body>
</html>
