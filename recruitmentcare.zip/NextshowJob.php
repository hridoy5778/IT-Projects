<?php session_start();?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
$maincategory = $_REQUEST['maincategory'];
$subcategory = $_REQUEST['subcategory'];
$city = $_REQUEST['city'];
$type = $_REQUEST['type'];
$frequency = $_REQUEST['frequency'];
$post = $_REQUEST['post'];
$rop = $_REQUEST['rop'];
$serial=$_REQUEST['serial'];
$description=$_REQUEST['description'];

$maincategoryN = $maincategory;
$subcategoryN = $subcategory;
$cityN = $city;
$typeN = $type;
$frequencyN = $frequency;
$postN = $post;
$ropN = $rop;
$descriptionN = $description;
?>
</head>

<body>
<table width="100%" border="0">
<?php 
if(!isset($_SESSION['login']))
{?>
  <tr>
    <td align="right" valign="top" colspan="3"><a href="signin.php" target="_self">SignIn/Register</a></td>
  </tr><?php } else {?>
  <tr>
    <td width="21%" align="right" valign="top">&nbsp;</td>
	<td width="75%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="4%"><a href="signin.php" target="_self">Logout</a></td>
  </tr><?php }?>
  <tr align="center" valign="top"> 
    <td colspan="3"></td>
  </tr>
  <tr><td align="center" colspan="3"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="left" valign="top" width="21%"><?php include_once('searchjob.php');?></td>
	<td align="center" valign="top" width="75%">
	<table width="106%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td valign="top" align="center"><strong><font size="5">Jobs search result</font></strong><br>
            <strong><font size="3">Please login for applying any job.</font></strong><br>
              <?php 
	include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
//$serial=$serial+9;
//$query = "SELECT * FROM job WHERE maincategory LIKE '$maincategory' AND subcategory LIKE '$subcategory' AND status='active' AND city LIKE '$city' AND type LIKE '$type' AND frequency LIKE '$frequency' AND name LIKE '$post' AND description LIKE '$description'";
//echo $serial;
$query = "SELECT * FROM job WHERE maincategory LIKE '$maincategory' AND subcategory LIKE '$subcategory' AND status='active' AND city LIKE '$city' AND type LIKE '$type' AND frequency LIKE '$frequency' AND name LIKE '$post' AND description LIKE '$description' limit 10,10";
//$result2 = mysql_query($query2);
$result = mysql_query($query);
$num = mysql_numrows($result);
//$num2 = mysql_numrows($result2);
mysql_close();

if($num>0)
{

$i=0;

while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$employeer = mysql_result($result,$i,"email");
$name = mysql_result($result,$i,"name");
$city = mysql_result($result,$i,"city");
$salary = mysql_result($result,$i,"salary");
$frequency = mysql_result($result,$i,"frequency");
$type = mysql_result($result,$i,"type");
$description = mysql_result($result,$i,"description");
?>
            
            <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
              <tr bgcolor="#FFFFFF"> 
                <td width="33%" align="center" bgcolor="#FFFFFF"><br></td>
                <td width="50%" bgcolor="#FFFFFF"><br></td>
              </tr>
              <tr align="left" valign="top" bgcolor="#CCCCCC"> 
                <td><font color="#0099FF" size="3"><strong>Job Position:</strong></font><font color="#000000"><strong><?php echo $name;?></strong></font></td>
                <td>&nbsp;</td>
                <td><strong><font color="#0099FF">Ref:</font></strong><strong><font color="#000000"> 
                  <?php echo $id;?></font></strong></td>
              </tr>
              <tr align="right" bgcolor="#FFFFFF"> 
                <td valign="top"><div align="left"></div></td>
                <td valign="top">&nbsp;</td>
                <td align="left" valign="top">&nbsp;</td>
              </tr>
              <tr align="left" valign="top" bgcolor="#FFFFFF"> 
                <td width="33%"><strong><font color="#0099FF">Location</font></strong><font color="#0099FF"><strong>:</strong></font><strong><font color="#000000"> 
                  <?php echo $city;?></font></strong></td>
                <td width="50%"><strong><font color="#0099FF">Salary</font></strong><font color="#0099FF"><strong>:</strong></font><font color="#000000"><strong> 
                  <?php echo $salary;?>&nbsp;&nbsp;<?php echo $frequency;?></strong></font></td>
                <td width="17%"><font color="#0099FF"><strong>Type: </strong></font><font color="#000000"><strong><?php echo $type;?></strong></font></td>
              </tr>
              <tr align="left" valign="top" bgcolor="#FFFFFF"> 
                <td colspan="3"><font color="#0099FF"><strong>Description:</strong></font><strong><font color="#000000"> 
                  <?php echo $description;?></font></strong></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td width="33%" align="center" bgcolor="#FFFFFF"><br></td>
                <td width="50%" bgcolor="#FFFFFF"><br></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td width="33%" align="center" bgcolor="#FFFFFF"><br></td>
                <td width="50%" bgcolor="#FFFFFF"><br></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td width="33%" align="left" valign="top"><a href="applyJob.php?maincategory=<?php echo $maincategory;?>&subcategory=<?php echo $subcategory;?>&type=<?php echo $type;?>&frequency=<?php echo $frequency;?>&city=<?php echo $city;?>&jobref=<?php echo $id;?>&employeer=<?php echo $employeer;?>"><img src="image/apply.gif" border="0"></a><br></td>
                <td width="50%">&nbsp;</td>
              </tr>
            </table>

<?php 
$i++; 
}
}
else
{
echo "Sorry No job available";}?>
</td>
  </tr>
</table>
	
	</td>
	
  </tr>
  <?php if($num>10)
  {?>
  <tr align="right" valign="top"> 
    <td colspan="3"><a href="NextshowJob.php?maincategory=<?php echo $maincategory;?>&subcategory=<?php echo $subcategory;?>&city=<?php echo $city;?>&type=<?php echo $type;?>&frequency=<?php echo $frequency;?>&post=<?php echo $post;?>&rop=<?php echo $rop;?>&description=<?php echo $description;?>" target="_self">Next</a></td>
  </tr>
  <?php }
  else{
  ?>
  <tr align="right" valign="top"> 
    <td colspan="3"><a href="showJob.php?maincategory=<?php echo $maincategoryN;?>&subcategory=<?php echo $subcategoryN;?>&city=<?php echo $cityN;?>&type=<?php echo $typeN;?>&frequency=<?php echo $frequencyN;?>&post=<?php echo $postN;?>&rop=<?php echo $ropN;?>&description=<?php echo $descriptionN;?>" target="_self">Previous</a></td>
  </tr>
  <?php 
  }
  ?>
</table>

</body>
</html>
