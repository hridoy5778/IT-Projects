<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT DISTINCT name FROM jobcategory";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query2 = "SELECT DISTINCT name FROM jobsubcategory";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
$query3 = "SELECT * FROM city WHERE status='a'";
$result3 = mysql_query($query3);
$num3 = mysql_num_rows($result3);
mysql_close();
?>
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FF9900">
<form action="showJob.php" method="post" target="_self" style="background-color: #FF9900">
  <table width="85%" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FF9900">
    <tr>
      <td align="center" valign="top"><font color="#FFFFFF" face="Arial, Helvetica, sans-serif"><strong><u>Search 
        Job</u></strong></font></td>
    </tr>
    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;Enter 
        Keyword(s)</font></strong></td>
    </tr>
	<tr align="left"> 
      <td height="46" valign="top">
<p>&nbsp; 
          <input name="post" type="text" size="35"><br>
          <strong><font face="Arial, Helvetica, sans-serif">&nbsp; </font></strong>
        <strong><font face="Arial, Helvetica, sans-serif">
          <input name="rop" type="radio" value="title" checked>
          in title only</font></strong>&nbsp;
          <input name="rop" type="radio" value="titledes">
          in titile & description</td>
    </tr>
	
	<tr align="left"> 
      <td valign="top">&nbsp; &nbsp; <strong><font face="Arial, Helvetica, sans-serif">Job 
        Sector </font></strong>&nbsp;<strong><font face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;Job 
        Role</font></strong></td>
	  	
    </tr>
   
    
    <tr align="left"> 
      <td> &nbsp; &nbsp; 
        <select name="maincategory">
          <option>All</option>
          <?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?>
        </select>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <select name="subcategory">
          <option>All</option>
          <?php
	   $i2=0;
while ($i2 < $num2) 
{
$name = mysql_result($result2,$i2,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i2++;
}
?>
        </select>
		
		</td>
      
    </tr>
    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;City</font></strong></td>
    </tr>
    <tr align="left"> 
      <td> &nbsp; &nbsp; 
        <select name="city">
          <option>All</option>
          <?php
	   $i3=0;
while ($i3 < $num3) 
{
$name = mysql_result($result3,$i3,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i3++;
}
?>
        </select></td>
    </tr>
    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;Job 
        Type</font></strong></td>
    </tr>
    <tr align="left"> 
      <td> &nbsp; &nbsp; 
        <select name="type">
          <option>All</option>
          <option>Permanent</option>
          <option>Part Time</option>
          <option>Contract</option>
          <option>Temporary</option>
        </select></td>
    </tr>
    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;Payment 
        Frequency</font></strong></td>
    </tr>
    <tr align="left"> 
      <td> &nbsp; &nbsp; 
        <select name="frequency">
          <option>All</option>
          <OPTION>Per Annum</OPTION>
          <OPTION>Per Month</OPTION>
          <OPTION>Per Week</OPTION>
          <OPTION>Per Day</OPTION>
          <OPTION>Per Hour</OPTION>
        </select></td>
    </tr>
    <tr align="left"> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr align="left"> 
      <td></td>
      <td>&nbsp;</td>
    </tr>
    <tr align="left"> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2" align="center"><input name="" type="submit" value="Search"></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    
  </table>
</form>
</body>
</html>
