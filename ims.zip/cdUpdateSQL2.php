<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
$done = $_POST["done"];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

?>
</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
	  <table width="119%" height="481" border="0" bgcolor="#66CCFF">
        <tr>
    <td align="center" valign="top"><form action="cdUpdateSQL3.php" method="post" target="_self" enctype="multipart/form-data">
        <table width="100%" border="0">
		<tr> 
                  <td colspan="2" bgcolor="#00CC00"><br>
<strong><font color="#000000" size="4">CD/DVD UPDATE</font></strong><br>
</td>
            
          </tr>
          <tr> 
            <td><?php foreach ($done as $d) 
{


$query3 = "SELECT * FROM cd WHERE id='$d'";
$result3 = mysql_query($query3);
$i = 0;
$name = mysql_result($result3,$i,"name");
$tag = mysql_result($result3,$i,"tag");
$pin = mysql_result($result3,$i,"pin");
$unit = mysql_result($result3,$i,"unit");
$status = mysql_result($result3,$i,"status");
$remarks = mysql_result($result3,$i,"remarks");

?><br></td>
            <td><br></td>
          </tr>
		  <tr> 
            <td><input name="done[]" type="hidden" value="<?php echo $d;?>"></td>
            <td><input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
          </tr>
          <tr> 
                  <td height="120" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>CD/DVD
                    Name</strong></font></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <textarea name="name" cols="30" rows="5" wrap="VIRTUAL" id="name"><?php echo $name; ?></textarea>
                    <br>
                    </strong></font></td>
          </tr>
		  <tr> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>BBL Tag No</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="tag" type="text" value="<?php echo $tag;?>">
                    </strong></font></td>
          </tr>
		  
          <tr> 
                  <td height="137" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>UNIT's</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="unit" type="text" value="<?php echo $unit;?>">
                    </strong></font></td>
          </tr>
          <tr> 
                  <td height="61" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>PIN/Serial No</strong></font></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="pin" type="text" value="<?php echo $pin;?>">
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                    CD/DVD Status</strong></font></td>
                  <td valign="middle"> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input type="radio" name="status" value="a" id="status" <?php if($status =='a') echo 'checked';?>>
                    Available 
                    <input type="radio" name="status" value="n" id="status" <?php if($status =='n') echo 'checked';?>>
                    Not Available <br>
                    </strong></font></td>
          </tr>
          
		  <tr> 
            <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Remarks</strong></font></td>
            <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
			
			<textarea name="remarks" cols="30" rows="5" wrap="VIRTUAL" id="remarks"><?php echo $remarks;?></textarea>
			
                    
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
            <td><?php 
}
mysql_close();
?></br></td>
            <td></br></td>
          </tr>
          <tr> 
            <td></br></td>
            <td></br></td>
          </tr>
          <tr> 
            <td align="center"><input name="submit" type="submit" value="UPDATE"><br>
<br>
</td>
            <td align="center"><input name="" type="reset" value="Reset"><br>
<br>
</td>
          </tr>
        </table>
</form></td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
