<?php 
$db = "ITSbbl";			// Database Name 
$dbhost = "localhost";		// Database Host
$dbuser = $_SESSION['login'];		// Database Username
$dbpass = "";		// Database Password
?>