<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$name = $_POST['name'];
$tInstall = $_POST['tInstall'];
$tLicenses = $_POST['tLicenses'];
$version = $_POST['version'];
$remarks = $_POST['remarks'];

$installDateF = $_POST['installDateF'];
$installDateT = $_POST['installDateT'];
$receivedDateF = $_POST['receivedDateF'];
$receivedDateT = $_POST['receivedDateT'];



if($installDateF == "")
{
$installDateF="%";
}
if($installDateT == "")
{
$installDateT=date('Y-m-d');
}

if($receivedDateF == "")
{
$receivedDateF="%";
}
if($receivedDateT == "")
{
$receivedDateT=date('Y-m-d');
}


if($name == "")
{
$name="%";
}

if($tInstall == "")
{
$tInstall="%";
}
if($tLicenses == "")
{
$tLicenses="%";
}
if($version == "Select Version")
{
$version="%";
}
if($remarks == "")
{
$remarks="%";
}

function replace($replace,$replacewith,$inme)
{
$doit = str_replace ("$replace", "$replacewith", $inme);
return $doit;
}


$name = replace(" ",'%',"$name");
$remarks = replace(" ",'%',"$remarks");


//echo $serial;
$nameR = $name;
$versionR = $version;
$tInstallR = $tInstall;
$tLicensesR = $tLicenses;

$installDateFR = $installDateF;
$installDateTR = $installDateT;
$receivedDateFR = $receivedDateF;
$receivedDateTR = $receivedDateT;
$remarksR = $remarks;


$query = "SELECT * FROM licenses where  name like '%$name%' and tInstall like '$tInstall' and tLicenses like '$tLicenses' 
and version like '$version' and remarks like '%$remarks%' and expire between '$installDateF' and '$installDateT' and issue between '$receivedDateF' and '$receivedDateT'";
//echo $tInstall;


$result = mysql_query($query);
$num = mysql_num_rows($result);
//echo $num;
mysql_close(); 
if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}

?>
<table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="8" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for Licenses---<a href="report/licenses.php?<?php echo 'nameR='.$nameR;?>
&amp;<?php echo 'versionR='.$versionR;?>&amp;<?php echo 'tInstallR='.$tInstallR;?>&amp;<?php echo 'tLicensesR='.$tLicensesR;?>
&amp;<?php echo 'installDateFR='.$installDateFR;?>&amp;<?php echo 'installDateTR='.$installDateTR;?>&amp;<?php echo 'receivedDateFR='.$receivedDateFR;?>&amp;<?php echo 'receivedDateTR='.$receivedDateTR;?>
&amp;<?php echo 'remarksR='.$remarksR;?>" target="_blank">Export report</a> </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
<td width="5%"><font color="#000000"><strong>No</strong></font></td><td width="30%"><font color="#000000"><strong>Product Name</strong></font></td>
<td width="10%"><font color="#000000"><strong>Version</strong></font></td><td width="10%"><font color="#000000"><strong>Total Installations</strong></font></td>
<td width="10%"><font color="#000000"><strong>Total License Acquired</strong></font></td><td width="10%"><font color="#000000"><strong>Issue Date</strong></font></td>
<td width="10%"><font color="#000000"><strong>Expire Date</strong></font></td><td width="15%"><font color="#000000"><strong>Remarks</strong></font></td>
    </tr>
  
</table>
<?php 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$name = mysql_result($result,$i,"name");
$version = mysql_result($result,$i,"version");
$tInstall = mysql_result($result,$i,"tInstall");
$tLicenses = mysql_result($result,$i,"tLicenses");
$receivedDate = mysql_result($result,$i,"issue");
$installDate = mysql_result($result,$i,"expire");
$remarks = mysql_result($result,$i,"remarks");
?> 

      <table width="192%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="5%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="30%"><p><font color="#000000" size="2"><?php echo $name;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $version;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $tInstall;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $tLicenses;?></font></p></td>
          
		 
		   <td width="10%"><p><font color="#000000" size="2"><?php echo $receivedDate;?></font></p></td>
		    <td width="10%"><p><font color="#000000" size="2"><?php echo $installDate;?></font></p></td>
		   
		  <td width="15%"><p><font color="#000000" size="2"><?php echo $remarks;?></font></p></td>
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
