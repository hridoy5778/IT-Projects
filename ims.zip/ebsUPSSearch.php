<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT distinct(location) FROM ebsups order by location";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query2 = "SELECT distinct(backupCapacity) FROM ebsups order by backupCapacity";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
$query3 = "SELECT distinct(backupStatus) FROM ebsups order by backupStatus";
$result3 = mysql_query($query3);
$num3 = mysql_num_rows($result3);
$query4 = "SELECT distinct(warrentyPeriod) FROM ebsups order by warrentyPeriod";
$result4 = mysql_query($query4);
$num4 = mysql_num_rows($result4);

$query5 = "SELECT distinct(warrentyStatus) FROM ebsups order by warrentyStatus";
$result5 = mysql_query($query5);
$num5 = mysql_num_rows($result5);

$query6 = "SELECT distinct(slaStatus) FROM ebsups order by slaStatus";
$result6 = mysql_query($query6);
$num6 = mysql_num_rows($result6);

mysql_close();
?>

</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	<br>
<br>
<br>

	  <table width="130%" height="395" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
        <tr>
          <td height="391" align="center" valign="top"> 
            <form action="ebsUPSSearchSQL.php" method="post" target="_self" enctype="multipart/form-data">
              <table width="110%" border="0">
                <tr bgcolor="#0066FF"> 
                  <td colspan="2"> 
                    <div align="center"><br>
                      <strong><font color="#FFFFFF" size="4">COMPONENTS SEARCH(EBS---UPS)</font></strong><br>
                    </div></td>
                </tr>
                <tr> 
                  <td width="37%" bgcolor="#CCCCCC"><br></td>
                  <td width="63%" bgcolor="#CCCCCC"><br></td>
                </tr>
				<tr> 
                  <td height="43" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>ATM ID</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="atmId" type="text">
                    <br>
                    </strong></font></td>
                </tr>
                
				
				<tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Backup Capacity&nbsp;(Minutes)</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="backupCapacity">
                        <option>Select Capacity</option>
                        <?php
	   $i2=0;
while ($i2 < $num2) 
{
$backupCapacity = mysql_result($result2,$i2,"backupCapacity");
echo "<option>";
echo $backupCapacity;
echo "</option>" ; 
$i2++;
}
?>">
                        
                      </select>
					
					
                    <br>
                    </strong></font></td>
                </tr>
				

                <tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Backup Status</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="backupStatus">
                        <option>Select Status</option>
                        <?php
	   $i3=0;
while ($i3 < $num3) 
{
$backupStatus = mysql_result($result3,$i3,"backupStatus");
echo "<option>";
echo $backupStatus;
echo "</option>" ; 
$i3++;
}
?>">
                        
                      </select>
					
					
                    <br>
                    </strong></font></td>
                </tr>

				
                <tr> 
                  <td height="42" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000"><strong>Installation 
                      Date&nbsp;(yyyy-mm-dd)</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"> 
                    <div align="left"><font color="#000000"><strong><em>From:</em></strong></font>&nbsp; 
                      <input name="entDateF" type="text" size="10" id="entDateF" readonly="true">
                      <img src="images/search_calendar.png" id="calF"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /> &nbsp; <font color="#000000"><strong><em>To:</em></strong></font><em><strong>&nbsp;</strong></em> 
                      <input name="entDateT" type="text" size="10" id="entDateT" readonly="true">
                      <img src="images/search_calendar.png" id="calT"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></div></td>
                </tr>
				
				
                <tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Warrenty Period</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="warrentyPeriod">
                        <option>Select Warrenty Period</option>
                        <?php
	   $i4=0;
while ($i4 < $num4) 
{
$warrentyPeriod = mysql_result($result4,$i4,"warrentyPeriod");
echo "<option>";
echo $warrentyPeriod;
echo "</option>" ; 
$i4++;
}
?>">
                        
                      </select>
					
					
                    <br>
                    </strong></font></td>
                </tr>				

<tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Performance Status</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="location">
<option>Not defined</option>
                        <option>Excellent </option>
                        <option>Moderate</option>
                        <option>Poor</option>
                      </select>
					
					
                    <br>
                    </strong></font></td>
                </tr>


<tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>UPS Location</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="location">
                        <option>Select Location</option>
                        <?php
	   $i=0;
while ($i < $num) 
{
$location = mysql_result($result,$i,"location");
echo "<option>";
echo $location;
echo "</option>" ; 
$i++;
}
?>">
                        
                      </select>
					
					
                    <br>
                    </strong></font></td>
                </tr>
                <tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Warrenty Status</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="warrentyStatus">
                        <option>Select Warrenty Status</option>
                        <?php
	   $i5=0;
while ($i5 < $num5) 
{
$warrentyStatus = mysql_result($result5,$i5,"warrentyStatus");
echo "<option>";
echo $warrentyStatus;
echo "</option>" ; 
$i5++;
}
?>">
                        
                      </select>
					
					
                    <br>
                    </strong></font></td>
                </tr>
				
                <tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>SLA Status</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="slaStatus">
                        <option>Select SLA Status</option>
                        <?php
	   $i6=0;
while ($i6 < $num6) 
{
$slaStatus = mysql_result($result6,$i6,"slaStatus");
echo "<option>";
echo $slaStatus;
echo "</option>" ; 
$i6++;
}
?>">
                        
                      </select>
					
					
                    <br>
                    </strong></font></td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC"> 
                    <div align="center"> 
                      <input name="enterDate" type="hidden" value="<?php echo date('Y-m-d');?>">
                    </div></td>
                  <td bgcolor="#CCCCCC"> 
                    <input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC"></br> 
                    <div align="center"></div></td>
                  <td bgcolor="#CCCCCC"></br></td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC"></br> 
                    <input name="submit" type="submit" value="SEARCH"> 
                    <div align="center"></div></td>
                  <td bgcolor="#CCCCCC"></br> 
                    <input name="Input" type="reset" value="Reset"></td>
                </tr>
              </table>
</form>

</td>
  </tr></table>
	<script type="text/javascript">
Calendar.setup({
inputField : "entDateF",
ifFormat : "%Y-%m-%d",
button : "calF",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "entDateT",
ifFormat : "%Y-%m-%d",
button : "calT",
align : "T1",
singleClick : true
});
</script>
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
