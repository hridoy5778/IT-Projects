<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
    <head xmlns="">
        <title><?php include_once('title.php');?></title>
        <meta content="document" name="resource-type" />
        <meta content="" name="description" />
        <meta content="" name="keywords" />
        <link href="css/template_css.css" type="text/css" rel="stylesheet" />
        <script type="text/javascript" src="js/swfobject.js"></script>
        <script type="text/javascript" src="js/mootools-release-1.11.js">
        </script><script type="text/javascript" src="js/mootools.bgiframe.js"></script>
        <script type="text/javascript" src="js/rokmoomenu.js">
        </script><script type="text/javascript">
	window.addEvent('domready', function() {
		new Rokmoomenu($E('#menu'), {
			bgiframe: false,
			delay: 500,
			animate: {
				props: ['opacity', 'width', 'height'],
				opts: {
					duration:400,
					fps: 100,
					transition: Fx.Transitions.Expo.easeOut
				}
			}
		});
	});
	</script>
</head>
<body xmlns="">
    <div id="menu">
      <ul>
	  
	  
        		<li class="parent"><a href="#"><span>HARDWARE</span></a>
           <ul>
		   
		   <li class="parent"><a href="#"><span>System Admin</span></a>
		   <ul>
		   <li class="parent"><a href="#"><span>Physical Servers</span></a> 
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="sysAdminServerSearch.php"><span>SEARCH</span></a>
				</ul>
				 </li>
			<li class="parent"><a href="#"><span>VM Servers</span></a> 
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="VMsysAdminServerSearch.php"><span>SEARCH</span></a>
				</ul>
				 </li> 
				 
				
				 </ul>
			 
			  
		   
		   
		   
		   <li class="parent"><a href="#"><span>SERVERS</span></a>
			  
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="serverSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
		   
		   <li class="parent"><a href="#"><span>Desktop PC's</span></a>
			  
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="desktopSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
		    <li class="parent"><a href="#"><span>Laptop PC's</span></a>
			  
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="laptopSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
			  <li class="parent"><a href="#"><span>Workstation Name</span></a>
			  
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="workstationSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
			  </ul>
		
        </li>
        
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<li class="parent"><a href="#"><span>CD/DVD Inventory</span></a>
        <ul>
		  <li><a href="cdEntry.php"><span>NEW ENTRY</span></a>
		  <li><a href="cdUpdate.php"><span>EDIT PRODUCT</span></a>
		  <li><a href="cdSearch.php"><span>SEARCH</span></a>
		  
		</ul>
        </li>
		
		
		
		
        <li class="parent"><a href="#"><span>EBS Components</span></a>
		<ul>
			  
			  
			  
			  <li class="parent"><a href="#"><span>EBS--UPS</span></a>
			  
				<ul>
				<li><a href="ebsUPSshowAll.php"><span>View All</span></a>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="ebsUPSSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
			  
			  <li class="parent"><a href="#"><span>EBS--Hardware</span></a>
			  
				<ul>
				<li><a href="ebsHardwareshowAll.php"><span>View All</span></a>
				<li><a href="upsVaultEntry.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="ebsHardwarSearch.php"><span>SEARCH</span></a>
		  
				</ul>
			  </li>
			  
			<li class="parent"><a href="#"><span>EBS--ATM</span></a>
				<ul>
				<li><a href="ebsATMShowAll.php"><span>View All</span></a>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
		  		<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="ebsATMSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
			  
		<li class="parent"><a href="#"><span>EBS--CDM</span></a>
				<ul>
				<li><a href="ebsCDMshowAll.php"><span>View All</span></a>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
		  		<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="ebsCDMSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>	  
		<li class="parent"><a href="#"><span>EBS--POS</span></a>
				<ul>
				<li><a href="ebsPOSshowAll.php"><span>View All</span></a>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
		  		<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="ebsPOSSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>	  
		</ul>
	 </li>
       
	   
	   
	   
	    <li class="parent"><a href="#"><span>Vault's Components</span></a>
		<ul>
			  
<!--  <li class="parent"><a href="#"><span>DC MINI VAULT</span></a>
				<ul>
				<li><a href="dcVaultSearchSQL.php"><span>View All</span></a>
				<li><a href="dcVaultEntry.php"><span>NEW ENTRY</span></a>
		  		<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="dcVaultSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
			  
			  
	<li class="parent"><a href="#"><span>DC UPS ROOM</span></a>
			  
				<ul>
				<li><a href="upsVaultSearchSQL.php"><span>View All</span></a>
				<li><a href="upsVaultEntry.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="upsVaultSearch.php"><span>SEARCH</span></a>
		  
				</ul>
			  </li>
		
		<li class="parent"><a href="#"><span>DR VAULT</span></a>
			  
				<ul>
				<li><a href="drVaultSearchSQL.php"><span>View All</span></a>
				<li><a href="drVaultEntry.php"><span>NEW ENTRY</span></a>
				<li><a href="hsmUpdate.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="drVaultSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>-->
		<li class="parent"><a href="#"><span>Custodian List</span></a>
			  
				<ul>
				<li><a href="underCons.php"><span>View All</span></a>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="custodianSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>	 
		<li class="parent"><a href="#"><span>Software Licenses</span></a>
			  
				<ul>
				<li><a href="licensesSearchAllSQL.php"><span>View All</span></a>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="licensesSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>	   
		<li class="parent"><a href="hsmEntry.php"><span>Advanced Entry</span></a></li>
		<li class="parent"><a href="hsmUpdate.php"><span>EDIT Component's</span></a></li>	  
		<li class="parent"><a href="hsmSearch.php"><span>Advanced Search</span></a></li>
		
		
		
		
		      
		
			  
		</ul>
	 </li>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
				<li class="parent"><a href="#"><span>Network Services</span></a>
           <ul>
		   
		   <li class="parent"><a href="#"><span>Network Devices</span></a>
			  
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="netDeviceSearch.php"><span>SEARCH</span></a>
		  
				</ul>
			  </li>
		   
		   <li class="parent"><a href="#"><span>Internet Users</span></a>
			  
				<ul>
				<li><a href="underCons.php"><span>NEW ENTRY</span></a>
				<li><a href="underCons.php"><span>EDIT ENTRY</span></a>
		  		<li><a href="inetUserSearch.php"><span>SEARCH</span></a>
				</ul>
			  </li>
		   
			  </ul>
		
        </li>
		
       
      
		
		
		
		
		
		
		
		
		
		
		<li class="parent"><a href="#"><span>CLEARANCE</span></a>
        <ul>
		  <li><a href="clearanceEntry.php"><span>NEW ENTRY</span></a>
		   <li><a href="clearanceUpdate.php"><span>EDIT ENTRY</span></a>
		  
		  <li><a href="clearanceSearch.php"><span>SEARCH</span></a></li>
		</ul>
        </li>
		
		
		<li class="parent"><a href="#"><span>MAINTENANCE</span></a>
           <ul>
		   
		 <li class="parent"><a href="#"><span>Password Change</span></a>
			  
				<ul>
				<li><a href="passwordUpdate.php"><span>Edit Password</span></a>
		  
				</ul>
			  </li>  
		   
		   
		   <li class="parent"><a href="#"><span>IT Wing</span></a>
			  
				<ul>
				<li><a href="itWingEntry.php"><span>NEW ENTRY</span></a>
		  
				</ul>
			  </li>
		   
			  <li class="parent"><a href="#"><span>Vault's Product Category</span></a>
			  
				<ul>
				<li><a href="hsmCategoryEntry.php"><span>NEW ENTRY</span></a>
		  
				</ul>
			  </li>
			  
			  <li class="parent"><a href="#"><span>Vault's Product Type</span></a>
			  
				<ul>
				<li><a href="hsmTypeEntry.php"><span>NEW ENTRY</span></a>
		  
				</ul>
			  </li>
			  
			  <li class="parent"><a href="#"><span>Vault's Location</span></a>
			  
				<ul>
				<li><a href="vaultEntry.php"><span>NEW ENTRY</span></a>
		  
				</ul>
			  </li>
			  
			<li class="parent"><a href="#"><span>Service Outlet</span></a>
				<ul>
				<li><a href="solEntry.php"><span>NEW ENTRY</span></a>
		  
				</ul>
			  </li>
		
		      <li class="parent"><a href="#"><span>Employee Grade</span></a>
				<ul>
				<li><a href="gradeEntry.php"><span>NEW ENTRY</span></a>
		  
				</ul>
			  </li>
		
			  <li class="parent"><a href="#"><span>Department</span></a>
				<ul>
				<li><a href="departmentEntry.php"><span>NEW ENTRY</span></a>
		  		
				</ul>
			  </li>
		</ul>
		
        </li>
		
		
      </ul>
    </div>
</body>
</html>