<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM department";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query2 = "SELECT * FROM jobgrade";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
mysql_close();
?>

</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    <br>
    <font color="#FF6600" size="4"><em><strong>CLEARANCE RECORD SEARCHING:</strong></em></font><br>
<br>
<br>
<br>

    <div id="contentCol">
      <table width="120%" border="0" bgcolor="#00CC00">
	  
        <tr>
          <td bgcolor="#FFFFFF"> 
            <form action="clearanceSearchSQL.php" method="post" target="_parent">
	          <table width="100%" border="0">
                <tr bgcolor="#CCCCCC"> 
                  <td><br> </td>
                  <td><br> </td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td valign="top"><font color="#000000"><strong>Employee NAME</strong></font></td>
                  <td> 
                    <input name="name" type="text" size="50"> <br></td>
                </tr>
                
                <tr bgcolor="#CCCCCC"> 
                  <td height="49" valign="top"><font color="#000000"><strong>PIN 
                    Number</strong></font></td>
                  <td> 
                    <input name="pin" type="text" size="50"></td>
                </tr>
                
                <tr bgcolor="#CCCCCC"> 
                  <td height="42" valign="top"> 
                    <div align="left"><font color="#000000"><strong>Entry 
                      Date&nbsp;(yyyy-mm-dd)</strong></font></div></td>
                  <td valign="top"> 
                    <div align="left"><font color="#000000"><strong><em>From:</em></strong></font>&nbsp; 
                      <input name="entDateF" type="text" size="10" id="entDateF" readonly="true">
                      <img src="images/search_calendar.png" id="calF"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /> &nbsp; <font color="#000000"><strong><em>To:</em></strong></font><em><strong>&nbsp;</strong></em> 
                      <input name="entDateT" type="text" size="10" id="entDateT" readonly="true">
                      <img src="images/search_calendar.png" id="calT"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></div>
                    <br> </td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td valign="top"><font color="#000000"><strong>Team ID</strong></font><br> 
                  </td>
                  <td> 
                    <input name="team" type="text" size="50"></td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td valign="top"><font color="#000000"><strong>Employee Grade</strong></font></td>
                  <td> 
                    <select name="grade">
                      <option>Select Job Grade</option>
                      <?php
	   $i=0;
while ($i < $num2) 
{
$gradeName = mysql_result($result2,$i,"gradeName");
echo "<option>";
echo $gradeName;
echo "</option>" ; 
$i++;
}
?>">
                      <option></option>
                    </select> </strong></font><br> </td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td valign="top"><font color="#000000"><strong>Department</strong></font></td>
                  <td> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="dept">
                      <option>Select Department</option>
                      <?php
	   $i=0;
while ($i < $num) 
{
$deptName = mysql_result($result,$i,"deptName");
echo "<option>";
echo $deptName;
echo "</option>" ; 
$i++;
}
?>">
                      <option></option>
                    </select>
                    </strong></font> <br> </td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td><br> </td>
                  <td><br> </td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td colspan="2"> 
                    <input name="btnInsert" type="submit" value="Search Clearance Entry"></td>
                </tr>
              </table>
</form>
<script type="text/javascript">
Calendar.setup({
inputField : "entDateF",
ifFormat : "%Y-%m-%d",
button : "calF",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "entDateT",
ifFormat : "%Y-%m-%d",
button : "calT",
align : "T1",
singleClick : true
});
</script><br>
<br>

</td>
  </tr>
</table></div>
    
    <div class="clear"></div>
  </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>