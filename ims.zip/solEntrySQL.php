<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol"><?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$sol = $_POST['sol'];
$solDescription = $_POST['solDescription'];

$query = "INSERT INTO sol VALUES ('','$sol','$solDescription')";
mysql_query($query);

mysql_close();
?> 
<h3>SOL Info have been Inserted to Database......Thank You.</h3>
<br>
<br>
<br>

<a href="solEntry.php" target="_parent">Bact to SOL Entry Page</a> </div>
    
    <div class="clear"></div>
  </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>













<body>

</body>
</html>
