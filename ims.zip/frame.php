<frameset rows="20%,70%,10%" frameborder="NO" border="0" framespacing="0">
  <frame src="banner.php" name="top" scrolling="no" noresize bordercolor="#6600FF" frameborder="yes">
  <frame src="login.php" name="mid" scrolling="yes" noresize bordercolor="#6633FF" frameborder="yes" >
  <frame src="footer.php" name="bot" scrolling="no" noresize bordercolor="#333399" frameborder="yes" >
  
</frameset><noframes></noframes>