<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT distinct(dept) FROM internetlist";
$result = mysql_query($query);
$num = mysql_num_rows($result);
//$query2 = "SELECT distinct(location) FROM netdevice";
//$result2 = mysql_query($query2);
//$num2 = mysql_num_rows($result2);
mysql_close();
?>

</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
	  <table width="119%" border="0">
        <tr>
          <td align="center" valign="top"> 
            <form action="inetUserSearchSQL.php" method="post" target="_self" enctype="multipart/form-data">
              <table width="100%" border="0">
                <tr bgcolor="#0000FF"> 
                  <td colspan="2"> 
                    <div align="center"><br>
                      <strong><font color="#FFFFFF" size="4">Internet User's Search</font></strong><font color="#FFFFFF"><br>
                      </font> </div></td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC"><font color="#000000"><br>
                    </font></td>
                  <td bgcolor="#CCCCCC"><div align="left"><br>
                    </div></td>
                </tr>
                <tr> 
                  <td height="30" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>User 
                      Name</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><div align="left"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                      <input name="name" type="text" size="30">
                      <br>
                      </strong></font></div></td>
                </tr>
                
                <tr> 
                  <td height="31" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>IP 
                      Address</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><div align="left"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                      <input name="ip" type="text" size="30">
                      <br>
                      </strong></font></div></td>
                </tr>
                <tr> 
                  <td height="27" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>PIN</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><div align="left"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                      <input name="pin" type="text" size="30">
                      <br>
                      </strong></font></div></td>
                </tr>
				
                <tr> 
                  <td height="29" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Department Name</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"> <div align="left"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                      <select name="dept">
                        <option>Select Department</option>
                        <?php
	   $i=0;
while ($i < $num) 
{
$dept = mysql_result($result,$i,"dept");
echo "<option>";
echo $dept;
echo "</option>" ; 
$i++;
}
?>">
                        
                      </select>
                      <br>
                      </strong></font></div></td>
                </tr>
                
                
                <tr> 
                  <td height="42" valign="top" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000"><strong>Entry 
                      Date&nbsp;(yyyy-mm-dd)</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"> <div align="left"><font color="#000000">From:</font>&nbsp; 
                      <input name="entDateF" type="text" size="10" id="entDateF" readonly="true">
                      <img src="images/search_calendar.png" id="calF"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /> &nbsp; <font color="#000000">To:</font>&nbsp; 
                      <input name="entDateT" type="text" size="10" id="entDateT" readonly="true">
                      <img src="images/search_calendar.png" id="calT"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></div></td>
                </tr>
                <tr> 
                  <td bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000"></br></font></div></td>
                  <td bgcolor="#CCCCCC"></br> <div align="left"></div></td>
                </tr>
                <tr> 
                  <td align="center" bgcolor="#CCCCCC"> 
                    <div align="center"><font color="#000000"> 
                      <input name="submit" type="submit" value="SEARCH">
                      <br>
                      <br>
                      </font></div></td>
                  <td align="center" bgcolor="#CCCCCC"> <div align="left"> 
                      <input name="" type="reset" value="Reset">
                      <br>
                      <br>
                    </div></td>
                </tr>
              </table>
</form>
<script type="text/javascript">
Calendar.setup({
inputField : "entDateF",
ifFormat : "%Y-%m-%d",
button : "calF",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "entDateT",
ifFormat : "%Y-%m-%d",
button : "calT",
align : "T1",
singleClick : true
});
</script>


</td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
