<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$atmId = $_POST['atmId'];
$backupCapacity = $_POST['backupCapacity'];
$backupStatus = $_POST['backupStatus'];
$warrentyPeriod = $_POST['warrentyPeriod'];
$warrentyStatus = $_POST['warrentyStatus'];
$slaStatus = $_POST['slaStatus'];
$location = $_POST['location'];
$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}

if($atmId == "")
{
$atmId="%";
}
if($location == "Select Location")
{
$location="%";
}
if($backupCapacity == "Select Capacity")
{
$backupCapacity="%";
}
if($backupStatus == "Select Status")
{
$backupStatus="%";
}
if($warrentyPeriod == "Select Warrenty Period")
{
$warrentyPeriod="%";
}
if($warrentyStatus == "Select Warrenty Status")
{
$warrentyStatus="%";
}
if($slaStatus == "Select SLA Status")
{
$slaStatus="%";
}

$atmIdR = $atmId;
$backupCapacityR = $backupCapacity;
$backupStatusR = $backupStatus;
$warrentyPeriodR = $warrentyPeriod;
$warrentyStatusR = $warrentyStatus;
$slaStatusR = $slaStatus;
$locationR = $location;
$entDateFR = $entDateF;
$entDateTR = $entDateT;
//echo $serial;
//echo $type;
//echo $entDateF;
//echo $entDateT;
//echo $location;
$query = "SELECT * FROM ebsups where  atmId like '$atmId' and backupCapacity like '$backupCapacity' and backupStatus like '$backupStatus' and warrentyPeriod like '$warrentyPeriod' and warrentyStatus like '$warrentyStatus' and slaStatus like '$slaStatus' and location like '%$location%' and installDate between '$entDateF' and '$entDateT' order by atmId asc";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}

?>
<table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="10" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for EBS--UPS 
              --- <a href="report/ebsUPS.php?<?php echo 'atmIdR='.$atmIdR;?>&amp;<?php echo 'backupCapacityR='.$backupCapacityR;?>&amp;<?php echo 'backupStatusR='.$backupStatusR;?>&amp;<?php echo 'entDateFR='.$entDateFR;?>&amp;<?php echo 'entDateTR='.$entDateTR;?>&amp;<?php echo 'warrentyPeriodR='.$warrentyPeriodR;?>&amp;<?php echo 'warrentyStatusR='.$warrentyStatusR;?>&amp;<?php echo 'slaStatusR='.$slaStatusR;?>&amp;<?php echo 'locationR='.$locationR;?>" target="_blank">Export report</a> </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="4%"><font color="#000000"><strong>No</strong></font></td><td width="10%"><font color="#000000"><strong>ATM ID</strong></font></td><td width="10%"><font color="#000000"><strong>Backup Capacity</strong></font></td><td width="8%"><font color="#000000"><strong>Backup Status</strong></font></td><td width="10%"><font color="#000000"><strong>Warrenty Period</strong></font></td><td width="10%"><font color="#000000"><strong>Warrenty Status</strong></font></td><td width="13%"><font color="#000000"><strong>SLA Status</strong></font></td><td width="11%"><font color="#000000"><strong>Location</strong></font></td><td width="12%"><font color="#000000"><strong>Installation Date</strong></font></td><td width="12%"><font color="#000000"><strong>Remarks</strong></font></td>
    </tr>
  
</table>
<?php 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$atmId = mysql_result($result,$i,"atmId");
$backupCapacity = mysql_result($result,$i,"backupCapacity");
$backupStatus = mysql_result($result,$i,"backupStatus");
$warrentyPeriod = mysql_result($result,$i,"warrentyPeriod");
$warrentyStatus = mysql_result($result,$i,"warrentyStatus");
$slaStatus = mysql_result($result,$i,"slaStatus");
$location = mysql_result($result,$i,"location");
$installDate = mysql_result($result,$i,"installDate");
$remarks = mysql_result($result,$i,"remarks");
?> 

      <table width="189%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="4%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="11%"><p><font color="#000000" size="2"><?php echo $atmId;?></font></p></td>
          <td width="11%"><p><font color="#000000" size="2"><?php echo $backupCapacity;?></font></p></td>
          <td width="7%"><p><font color="#000000" size="2"><?php echo $backupStatus;?></font></p></td>
          <td width="11%"><p><font color="#000000" size="2"><?php echo $warrentyPeriod;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $warrentyStatus;?></font></p></td>
          <td width="13%"><p><font color="#000000" size="2"><?php echo $slaStatus;?></font></p></td>
          <td width="12%"><p><font color="#000000" size="2"><?php echo $location;?></font></p></td>
          <td width="12%"><p><font color="#000000" size="2"><?php echo $installDate;?></font></p></td>
		  <td width="9%"><p><font color="#000000" size="2"><?php echo $remarks;?></font></p></td>
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
