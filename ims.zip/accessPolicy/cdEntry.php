<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<script type="text/javascript">
function show_ok()
{
alert("Entry has been completed");
}
</script>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php
if (isset($_REQUEST['submit']))
{
      
      
	  
	  $name = $_POST['name'];
	  

$tag = $_POST['tag'];
//$status = $_POST['status'];
$unit = $_POST['unit'];
$pin = $_POST['pin'];
$status = $_POST['status'];
$remarks = $_POST['remarks'];

	  include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

	$query = "INSERT INTO cd VALUES ('','$name','$tag','$unit','$pin','$remarks','$status')";
$result = mysql_query($query);
$num = mysql_result($result);
if($num == 0)
{
?>
<script type="text/javascript">

alert("Entry has been not been completed, ERROR CODE:007");

</script>
<?php
}
mysql_close(); 

	  
	}
		
	?>	

</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
	  <table width="119%" border="0" bgcolor="#00CC00">
        <tr>
    <td align="center" valign="top"><form action="" method="post" target="_self" enctype="multipart/form-data">
              <table width="100%" border="0">
                <tr bgcolor="#0000FF"> 
                  <td colspan="2"> 
                    <div align="center"><font color="#FFFFFF"><br>
                      <strong><font size="4">CD/DVD Entry</font></strong></font><br>
                    </div></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td><br></td>
                  <td><br></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="120" valign="top"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>CD/DVD 
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <textarea name="name" cols="30" rows="5" wrap="VIRTUAL" id="name"></textarea>
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="42" valign="top"> 
                    <div align="center"><font color="#000000"><strong> 
                      TAG No:<font color="#FF0000"></font></strong></font></div></td>
                  <td valign="top"> <font color="#000000">&nbsp;</font> 
                    <input name="tag" type="text" size="30"> </td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td height="42" valign="top"> 
                    <div align="center"><font color="#000000"><strong> 
                      Unit:<font color="#FF0000"></font></strong></font></div></td>
                  <td valign="top"> <font color="#000000">&nbsp;</font> 
                    <input name="unit" type="text" size="30">&nbsp;[copies] </td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td height="42" valign="top"> 
                    <div align="center"><font color="#000000"><strong> 
                      PIN Code:<font color="#FF0000"></font></strong></font></div></td>
                  <td valign="top"> <font color="#000000">&nbsp;</font> 
                    <input name="pin" type="text" size="30"> </td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td valign="top"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                      CD/DVD Status</strong></font></div></td>
                  <td valign="middle"> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input type="radio" name="status" value="a" id="status">
                    Available 
                    <input type="radio" name="status" value="n" id="status">
                    Not Available <br>
                    </strong></font></td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td height="120" valign="middle"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>CD/DVD 
                      Remarks</strong></font></div></td>
                  <td valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <textarea name="remarks" cols="30" rows="5" wrap="VIRTUAL" id="name"></textarea>
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td> 
                    <input name="enterDate" type="hidden" value="<?php echo date('Y-m-d');?>"></td>
                  <td> 
                    <input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td></br></td>
                  <td></br></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="62" align="center"> 
                    <input name="submit" type="submit" value="ADD ENTRY" onclick="show_ok()">
                    <br> <br> </td>
                  <td align="center"> 
                    <input name="" type="reset" value="Reset">
                    <br> <br> </td>
                </tr>
              </table>
</form></td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
