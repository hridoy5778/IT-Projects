<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$deviceName = $_POST['deviceName'];
$description = $_POST['description'];
$type = $_POST['type'];
$serial = $_POST['serial'];
$ip = $_POST['ip'];
$address = $_POST['address'];
$location = $_POST['location'];
$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}

if($deviceName == "")
{
$deviceName="%";
}
if($description == "")
{
$description="%";
}
if($type == "Select Device Type")
{
$type="%";
}
if($serial == "")
{
$serial="%";
}
if($ip == "")
{
$ip="%";
}
if($address == "")
{
$address="%";
}
if($location == "Select Location")
{
$location="%";
}

$deviceNameR = $deviceName;
$descriptionR = $description;
$typeR = $type;
$serialR = $serial;
$ipR = $ip;
$addressR = $address;
$locationR = $location;
$entDateFR = $entDateF;
$entDateTR = $entDateT;
//echo $serial;
//echo $type;
//echo $entDateF;
//echo $entDateT;
//echo $location;
$query = "SELECT * FROM netdevice where  deviceName like '%$deviceName%' and description like '%$description%' and type like '$type' and serial like '$serial' and ip like '$ip' and address like '%$address%' and location like '$location' and entDate between '$entDateF' and '$entDateT' order by entDate desc";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 
if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}

?>
<table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="9" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for Network Devices 
--- <a href="report/netDevice.php?<?php echo 'deviceNameR='.$deviceNameR;?>&amp;<?php echo 'typeR='.$typeR;?>&amp;<?php echo 'locationR='.$locationR;?>&amp;<?php echo 'entDateFR='.$entDateFR;?>&amp;<?php echo 'entDateTR='.$entDateTR;?>&amp;<?php echo 'descriptionR='.$descriptionR;?>&amp;<?php echo 'serialR='.$serialR;?>&amp;<?php echo 'ipR='.$ipR;?>&amp;<?php echo 'addressR='.$addressR;?>" target="_blank">Export report</a>  </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="3%"><font color="#000000"><strong>No</strong></font></td><td width="15%"><font color="#000000"><strong>Device Name</strong></font></td><td width="15%"><font color="#000000"><strong>Description</strong></font></td><td width="05%"><font color="#000000"><strong>Type</strong></font></td><td width="10%"><font color="#000000"><strong>Serial Code</strong></font></td><td width="10%"><font color="#000000"><strong>IP</strong></font></td><td width="15%"><font color="#000000"><strong>Address</strong></font></td><td width="7%"><font color="#000000"><strong>Location</strong></font></td><td width="10%"><font color="#000000"><strong>Entry Date</strong></font></td>
    </tr>
  
</table>
<?php
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$deviceName = mysql_result($result,$i,"deviceName");
$description = mysql_result($result,$i,"description");
$type = mysql_result($result,$i,"type");
$serial = mysql_result($result,$i,"serial");
$ip = mysql_result($result,$i,"ip");
$address = mysql_result($result,$i,"address");
$location = mysql_result($result,$i,"location");
$entDate = mysql_result($result,$i,"entDate");

?> 

      <table width="188%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="3%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="15%"><p><font color="#000000" size="2"><?php echo $deviceName;?></font></p></td>
          <td width="15%"><p><font color="#000000" size="2"><?php echo $description;?></font></p></td>
          <td width="05%"><p><font color="#000000" size="2"><?php echo $type;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $serial;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $ip;?></font></p></td>
          <td width="15%"><p><font color="#000000" size="2"><?php echo $address;?></font></p></td>
          <td width="7%"><p><font color="#000000" size="2"><?php echo $location;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $entDate;?></font></p></td>
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
