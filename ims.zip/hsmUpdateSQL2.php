<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
$done = $_POST["done"];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query1 = "SELECT * FROM hsmcategory";
$result1 = mysql_query($query1);
$num1 = mysql_num_rows($result1);

$query2 = "SELECT * FROM vault";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);

$query4 = "SELECT * FROM hsmtype";
$result4 = mysql_query($query4);
$num4 = mysql_num_rows($result4);
?>
</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
	  <table width="119%" height="481" border="0" bgcolor="#66CCFF">
        <tr>
    <td align="center" valign="top"><form action="hsmUpdateSQL3.php" method="post" target="_self" enctype="multipart/form-data">
              <table width="100%" border="0">
                <tr bgcolor="#0000FF"> 
                  <td colspan="2"><div align="center"><br>
                      <strong><font color="#FFFFFF" size="4">Vault's Component 
                      UPDATE</font></strong><br>
                    </div></td>
            
          </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td> 
                    <?php foreach ($done as $d) 
{


$query3 = "SELECT * FROM hsm WHERE id='$d'";
$result3 = mysql_query($query3);
$i3 = 0;
$name = mysql_result($result3,$i3,"name");
$type = mysql_result($result3,$i3,"type");
$tag = mysql_result($result3,$i3,"tag");
$category = mysql_result($result3,$i3,"category");
$location = mysql_result($result3,$i3,"location");
$status = mysql_result($result3,$i3,"status");
$ownerName = mysql_result($result3,$i3,"ownerName");
$wing = mysql_result($result3,$i3,"wing");
$entDate = mysql_result($result3,$i3,"entDate");
$remarks = mysql_result($result3,$i3,"remarks");
?>
                    <br></td>
                  <td><br></td>
          </tr>
		        <tr bgcolor="#CCCCCC"> 
                  <td> 
                    <input name="done[]" type="hidden" value="<?php echo $d;?>"></td>
                  <td> 
                    <input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
          </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="120" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                    Name</strong></font></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>
				  <textarea name="name" cols="30" rows="5"><?php echo $name; ?></textarea> 
                    
                    
                    <br>
                    </strong></font></td>
          </tr>
		        <tr bgcolor="#CCCCCC"> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                    Tag No</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="tag" type="text" value="<?php echo $tag;?>">
                    </strong></font></td>
          </tr>
		  <tr bgcolor="#CCCCCC"> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Entry Date</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="entDate" type="text" value="<?php echo $entDate;?>">
                    </strong></font></td>
          </tr>
		  
		        <tr bgcolor="#CCCCCC"> 
                  <td><font color="#000000"><strong>Product Category</strong></font></td>
	              <td> 
                    <select name="category">
	<option><?php echo $category;?></option>
		<?php
	   $i1=0;
while ($i1 < $num1) 
{
$category = mysql_result($result1,$i1,"name");
echo "<option>";
echo $category;
echo "</option>" ; 
$i1++;
}
?>"> </select>
</strong></font></td>
  </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td><font color="#000000"><strong>Vault Location</strong></font></td>
	              <td> 
                    <select name="location">
	<option><?php echo $location;?></option>
		<?php
	   $i2=0;
while ($i2 < $num2) 
{
$location = mysql_result($result2,$i2,"name");
echo "<option>";
echo $location;
echo "</option>" ; 
$i2++;
}
?>"> </select>
</strong></font></td>
  </tr>		  
		  
         
		 <tr bgcolor="#CCCCCC"> 
                  <td><font color="#000000"><strong>Product Type</strong></font></td>
	              <td> 
                    <select name="type">
	<option><?php echo $type;?></option>
		<?php
	   $i4=0;
while ($i4 < $num4) 
{
$type = mysql_result($result4,$i4,"name");
echo "<option>";
echo $type;
echo "</option>" ; 
$i4++;
}
?>"> </select>
</strong></font></td>
  </tr>		  
		 
          
                <tr bgcolor="#CCCCCC"> 
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                    Product Status</strong></font></td>
                  <td valign="middle"> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input type="radio" name="status" value="a" id="status" <?php if($status =='a') echo 'checked';?>>
                    Available 
                    <input type="radio" name="status" value="n" id="status" <?php if($status =='n') echo 'checked';?>>
                    Not Available <br>
                    </strong></font></td>
          </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="137" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Owner's 
                    Name</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="ownerName" type="text" value="<?php echo $ownerName;?>">
                    </strong></font></td>
          </tr>
		        <tr bgcolor="#CCCCCC"> 
                  <td height="61" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Wing 
                    Name</strong></font></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="wing" type="text" value="<?php echo $wing;?>">
                    <br>
                    </strong></font></td>
          </tr>
		        <tr bgcolor="#CCCCCC"> 
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Remarks</strong></font></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <textarea name="remarks" cols="30" rows="5" wrap="VIRTUAL" id="remarks"><?php echo $remarks;?></textarea>
			
                    
                    <br>
                    </strong></font></td>
          </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td> 
                    <?php 
}
mysql_close();
?></br>
                    </td>
                  <td></br></td>
          </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td></br></td>
                  <td></br></td>
          </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td align="center"> 
                    <input name="submit" type="submit" value="UPDATE"><br>
<br>
</td>
                  <td align="center"> 
                    <input name="" type="reset" value="Reset"><br>
<br>
</td>
          </tr>
        </table>
</form></td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
