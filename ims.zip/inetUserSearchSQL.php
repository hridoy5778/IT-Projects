<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$name = $_POST['name'];
$dept = $_POST['dept'];
$pin = $_POST['pin'];

$ip = $_POST['ip'];

$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}

if($name == "")
{
$name="%";
}
if($pin == "")
{
$pin="%";
}

if($dept == "Select Department")
{
$dept="%";
}
if($ip == "")
{
$ip="%";
}


$nameR = $name;
$deptR = $dept;
$pinR = $pin;
//$serialR = $serial;
$ipR = $ip;
$entDateFR = $entDateF;
$entDateTR = $entDateT;
//echo $serial;
//echo $type;
//echo $entDateF;
//echo $entDateT;
//echo $location;
$query = "SELECT * FROM internetlist where  name like '%$name%' and dept like '$dept' 
and pin like '$pin' and ip like '$ip' and entDate between '$entDateF' and '$entDateT'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 
if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}

?>
<table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="9" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for Network Devices 
--- <a href="report/internetUser.php?<?php echo 'nameR='.$nameR;?>&amp;<?php echo 'deptR='.$deptR;?>&amp;<?php echo 'pinR='.$pinR;?>&amp;<?php echo 'entDateFR='.$entDateFR;?>&amp;<?php echo 'entDateTR='.$entDateTR;?>&amp;<?php echo 'ipR='.$ipR;?>" target="_blank">Export report</a>  </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="10%"><font color="#000000"><strong>No</strong></font></td><td width="20%"><font color="#000000"><strong>User Name</strong></font></td><td width="20%"><font color="#000000"><strong>Department</strong></font></td><td width="10%"><font color="#000000"><strong>PIN</strong></font></td><td width="20%"><font color="#000000"><strong>IP Address</strong></font></td><td width="20%"><font color="#000000"><strong>Entry Date</strong></font></td>
    </tr>
  
</table>
<?php
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$name = mysql_result($result,$i,"name");
$dept = mysql_result($result,$i,"dept");
$pin = mysql_result($result,$i,"pin");
//$serial = mysql_result($result,$i,"serial");
$ip = mysql_result($result,$i,"ip");
//$address = mysql_result($result,$i,"address");
//$location = mysql_result($result,$i,"location");
$entDate = mysql_result($result,$i,"entDate");

?> 

      <table width="188%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="10%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="20%"><p><font color="#000000" size="2"><?php echo $name;?></font></p></td>
          <td width="20%"><p><font color="#000000" size="2"><?php echo $dept;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $pin;?></font></p></td>
          
          <td width="20%"><p><font color="#000000" size="2"><?php echo $ip;?></font></p></td>
          
          <td width="20%"><p><font color="#000000" size="2"><?php echo $entDate;?></font></p></td>
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
