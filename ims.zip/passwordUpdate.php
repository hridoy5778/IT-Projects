<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];

?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM admin WHERE username = '$username' AND status = 'l'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
?>
</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
	  <table width="119%" height="481" border="0" bgcolor="#66CCFF">
        <tr>
    <td align="center" valign="top"><form action="passwordUpdateSQL.php" method="post" target="_self" enctype="multipart/form-data">
              <table width="100%" border="0">
                <tr> 
                  <td colspan="2" bgcolor="#00CC00"><br>
                    <strong><font color="#000000" size="4">Password Change</font></strong><br> </td>
                </tr>
                <tr> 
                  <td> 
                    <?php 
$i = 0;
$username = mysql_result($result,$i,"username");
$password = mysql_result($result,$i,"password");


?>
                    <br></td>
                  <td><br></td>
                </tr>
                <tr> 
                  <td><input name="done[]" type="hidden" value="<?php echo $d;?>"></td>
                  <td><input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
                </tr>
                <tr> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>User 
                    Name </strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="username" type="text" value="<?php echo $username;?>" readonly="yes">
                    </strong></font></td>
                </tr>
                <tr> 
                  <td height="137" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Old 
                    Password</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="password" type="text" value="<?php echo $password;?>" readonly="yes">
                    </strong></font></td>
                </tr>
                <tr> 
                  <td height="61" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>New 
                    Password </strong></font></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="passwordNew" type="text">
                    <br>
                    </strong></font></td>
                </tr>
                <tr> 
                  <td> 
                    <?php 

mysql_close();
?></br>
                    </td>
                  <td></br></td>
                </tr>
                <tr> 
                  <td></br></td>
                  <td></br></td>
                </tr>
                <tr> 
                  <td align="center"><input name="submit" type="submit" value="UPDATE"> 
                    <br> <br> </td>
                  <td align="center"><input name="" type="reset" value="Reset"> 
                    <br> <br> </td>
                </tr>
              </table>
</form></td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
