<?php
session_start();
$username = $_POST['username'];
$_SESSION['login']=$username;
$password = $_POST['password'];
$ip=$_SERVER['REMOTE_ADDR'];
$_SESSION['ip']=$ip;
$hostName = GetHostByName($REMOTE_ADDR); 
$dt = date("Fj,Y,g:i a");
include_once('config.php');
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM admin WHERE username = '$username' AND password = '$password' AND status = 'a'";
$result = mysql_query($query);
$num = mysql_num_rows($result);

if($num>0)
{
if($username == 'user')
{
$query3 = "update admin set status = 'a', ip = '$ip', hostName = '$hostName', dt = '$dt' where username = '$username'";
$result3 = mysql_query($query3);
}
if($username != 'user')
{
$query2 = "update admin set status = 'l', ip = '$ip', hostName = '$hostName', dt = '$dt' where username = '$username'";
$result2 = mysql_query($query2);
}
mysql_close();
?>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="css/template.css" type="text/css" />
<title>IT Inventory System</title>
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?></div>
  <div id="container">
    
    <div id="contentCol"><br><br><br><br><br><br><br><br><br><br><br><br><br></div>
    
    <div class="clear"></div>
  </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  <?php }
	else
	{
	?>
</div>
<table>
<tr> 
    <td> 
      
    </td>
  </tr>
  <tr> 
    <td width="100%" align="center"></td>
  </tr>
  <tr> 
    <td align="left" valign="top"><strong><font color="#000000" size="5"><?php 
	$query3 = "SELECT * FROM admin WHERE username = '$username'";
$result3 = mysql_query($query3);
$num3 = mysql_num_rows($result3);
$i = 0;
$ipDb = mysql_result($result3,$i3,"ip");	
$dt = mysql_result($result3,$i3,"dt");	
	?>Wrong User name/Password<br>OR<br>
<br>

	<font color="#FF0000"><?php echo $username; ?></font> already logged in!!<br>
<br>
<br>
Please contact to IT-Security department for assistance, IF required<br>
<br>

      Please try again to <a href="index.php" target="_self">Login</a> 
      <?php 
	  unset($_SESSION['login']);
session_destroy();
mysql_close();
	  }?>
      </font></strong> </td>
  </tr>

</table>
</body>
</html>