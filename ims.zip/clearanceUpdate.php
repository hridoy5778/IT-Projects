<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />



</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
      <table width="100%" border="0">
        <tr>
    <td><form action="clearanceUpdateSQL.php" method="post" target="_parent">
	<table width="100%" border="0">
  
  
  
  
  
  <tr>
                  <td width="45%"><font color="#000000"><strong>Employee PIN Number</strong></font></td>
	<td width="54%"><input name="pin" type="text" size="50"></td>
  </tr>
  
  
  
  <tr>
    <td><br>
</td>
	<td><br>
</td>
  </tr>
  
  
  <tr>
    
	<td><input name="btnInsert" type="submit" value="Search Clearance Entry"></td>
  </tr>
</table>
</form><br>
<br>
<br>
</td>
  </tr>
</table></div>
    
    <div class="clear"></div>
  </div>
  <br>
<br>
<br>
<br>
<br>

  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>