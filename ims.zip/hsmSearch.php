<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM hsmcategory";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query2 = "SELECT * FROM vault";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
$query3 = "SELECT * FROM hsmtype";
$result3 = mysql_query($query3);
$num3 = mysql_num_rows($result3);

mysql_close();
?>

</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?>
</div>
<br>
<br>
<br>

  <div id="container">
    
    <div id="contentCol">
	
	  <table width="119%" height="481" border="0" bgcolor="#FFFFFF">
        <tr>
    <td align="center" valign="top"><form action="hsmSearchSQL.php" method="post" target="_self" enctype="multipart/form-data">
              <table width="100%" border="0">
                <tr bgcolor="#0000FF"> 
                  <td colspan="2"> 
                    <div align="center"><br>
                      <strong><font color="#FFFFFF" size="4">Vault's COMPONENTS 
                      SEARCH</font></strong><font color="#FFFFFF"><br>
                      </font> </div></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td><br></td>
                  <td><br></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="43" valign="top"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="name" type="text" size="30" id="name">
                    <br>
                    </strong></font></td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td height="43" valign="top"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Wing 
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="wing" type="text" size="30" id="name">
                    <br>
                    </strong></font></td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td height="43" valign="top"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Owner
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="ownerName" type="text" size="30" id="name">
                    <br>
                    </strong></font></td>
                </tr>
				<tr bgcolor="#CCCCCC"> 
                  <td height="42" valign="top"> 
                    <div align="center"><font color="#000000"><strong>Entry 
                      Date&nbsp;(yyyy-mm-dd)</strong></font></div></td>
                  <td valign="top"> 
                    <div align="left"><font color="#000000"><strong><em>From:</em></strong></font>&nbsp; 
                      <input name="entDateF" type="text" size="10" id="entDateF" readonly="true">
                      <img src="images/search_calendar.png" id="calF"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /> &nbsp; <font color="#000000"><strong><em>To:</em></strong></font><em><strong>&nbsp;</strong></em> 
                      <input name="entDateT" type="text" size="10" id="entDateT" readonly="true">
                      <img src="images/search_calendar.png" id="calT"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></div></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td valign="top"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                      Product Status</strong></font></div></td>
                  <td valign="middle"> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input type="radio" name="status" value="a" id="status">
                    Available 
                    <input type="radio" name="status" value="n" id="status">
                    Not Available <br>
                    </strong></font></td>
                </tr>
				
<tr bgcolor="#CCCCCC"> 
                  <td height="65" valign="middle"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                      Type</strong></font></div></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="type">
                      <option>Select Type</option>
                      <?php
	   $i=0;
while ($i < $num3) 
{
$name = mysql_result($result3,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?>">
                      
                    </select>
                    <br>
                    </strong></font></td>
                </tr>
				
				
				
                <tr bgcolor="#CCCCCC"> 
                  <td height="65" valign="middle"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                      Category</strong></font></div></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="category">
                      <option>Select Category</option>
                      <?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?>">
                      
                    </select>
                    <br>
                    </strong></font></td>
                </tr>
				
				
                <tr bgcolor="#CCCCCC"> 
                  <td height="45" valign="middle"> 
                    <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Vault 
                      Location</strong></font></div></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="location">
                      <option>Select Location</option>
                      <?php
	   $i=0;
while ($i < $num2) 
{
$name = mysql_result($result2,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?>">
                      
                    </select>
                    <br>
                    </strong></font></td>
                </tr>
                
                <tr bgcolor="#CCCCCC"> 
                  <td> 
                    <div align="center"> 
                      <input name="enterDate" type="hidden" value="<?php echo date('Y-m-d');?>">
                    </div></td>
                  <td> 
                    <input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td></br> 
                    <div align="center"></div></td>
                  <td></br></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td></br> 
                    <div align="center"></div></td>
                  <td></br></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td align="center"> 
                    <div align="center"> 
                      <input name="submit" type="submit" value="SEARCH">
                      <br>
                      <br>
                    </div></td>
                  <td align="center"> 
                    <input name="" type="reset" value="Reset">
                    <br> <br> </td>
                </tr>
              </table>
</form>
<script type="text/javascript">
Calendar.setup({
inputField : "entDateF",
ifFormat : "%Y-%m-%d",
button : "calF",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "entDateT",
ifFormat : "%Y-%m-%d",
button : "calT",
align : "T1",
singleClick : true
});
</script>
</td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
