<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      <table width="184%" border="3">
        <tr bgcolor="#CCCCCC"><td width="3%">&nbsp;&nbsp;</td>
    <td width="22%"><font color="#000000"><strong>CD/DVD Name</strong></font></td><td width="17%"><font color="#000000"><strong>BBL Tag No</strong></font></td><td width="9%"><font color="#000000"><strong>UNIT'S</strong></font></td><td width="14%"><font color="#000000"><strong>Status</strong></font></td><td width="16%"><font color="#000000"><strong>PIN/Serial Key</strong></font></td><td width="19%"><font color="#000000"><strong>Remarks</strong></font></td>
    </tr>
  
</table>
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$name = $_POST['name'];
$tag = $_POST['tag'];
$unit = $_POST['unit'];
$pin = $_POST['pin'];
$remarks = $_POST['remarks'];
$status = $_POST['status'];

if($name == "")
{
$name="%";
}
if($tag == "")
{
$tag="%";
}

if($status == "")
{
$status="%";
}
function replace($replace,$replacewith,$inme)
{
$doit = str_replace ("$replace", "$replacewith", $inme);
return $doit;
}


$name = replace(" ",'%',"$name");


$query = "SELECT * FROM cd where  name like '%$name%' and tag like '%$tag%' and status like '$status'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}
$id = mysql_result($result,$i,"id");
$name = mysql_result($result,$i,"name");
$tag = mysql_result($result,$i,"tag");
$unit = mysql_result($result,$i,"unit");
$pin = mysql_result($result,$i,"pin");
$remarks = mysql_result($result,$i,"remarks");
$status = mysql_result($result,$i,"status");
if($status=='a')
{
$status = 'Available';
$statusColor = '#00FF00';
}
if($status=='n')
{
$status = 'Not Available';
$statusColor = '#FF0000';
}


?> 
<form action="cdUpdateSQL2.php" method="post" enctype="multipart/form-data">
      <table width="184%" border="0">
        <tr bgcolor="<?php echo $rColor; ?>">
		<td width="3%" bgcolor="<?php echo $statusColor; ?>"><input name="done[]" type="radio" value="<?php echo $id;?>"></td>
 <td width="22%"><font color="#000000"><?php echo $name;?></font></td>
          <td width="17%"><font color="#000000">&nbsp;&nbsp;<?php echo $tag;?></font></td>
          <td width="9%"><font color="#000000"><?php echo $unit;?></font></td><td width="14%"><font color="#000000"><?php echo $status;?></font></td><td width="16%"><font color="#000000"><?php echo $pin;?></font></td><td width="19%"><font color="#000000"><?php echo $remarks;?></font>
</td>
    
  </tr>
  <tr><td><br>
<br>
</td></tr>







<?php

$i++; 



}

?>
<tr><td colspan="7"><input name="" type="submit" value="Click to update"></td></tr>
</table>
</form>
 </div>
   
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
