<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$nullCHK = $_POST['nullCHK'];
$posTid = $_POST['posTid'];
$posMid = $_POST['posMid'];
$merchantName = $_POST['merchantName'];
$location = $_POST['location'];
$posType = $_POST['posType'];
$model = $_POST['model'];
$installDateF = $_POST['installDateF'];
$installDateT = $_POST['installDateT'];
$receivedDateF = $_POST['receivedDateF'];
$receivedDateT = $_POST['receivedDateT'];
$vendor = $_POST['vendor'];
//$location = $_POST['location'];
//echo $brand;

if($installDateF == "")
{
$installDateF="%";
}
if($installDateT == "")
{
$installDateT=date('Y-m-d');
}

if($receivedDateF == "")
{
$receivedDateF="%";
}
if($receivedDateT == "")
{
$receivedDateT=date('Y-m-d');
}


if($posTid == "")
{
$posTid="%";
}
if($posMid == "")
{
$posMid="%";
}
if($merchantName == "")
{
$merchantName="%";
}
if($location == "")
{
$location="%";
}
if($posType == "Select POS Type")
{
$posType="%";
}
if($model == "Select Model")
{
$model="%";
}
if($vendor == "Select Vendor")
{
$vendor="%";
}


$posTidR = $posTid;
$posMidR = $posMid;
$merchantNameR = $merchantName;
$locationR = $location;
$posTypeR = $posType;
$modelR = $model;
$vendorR = $vendor;
$installDateFR = $installDateF;
$installDateTR = $installDateT;
$receivedDateFR = $receivedDateF;
$receivedDateTR = $receivedDateT;

//$locationR = $location;
//echo $serial;

$a = isset($nullCHK);
if($a==1)
{
$query = "SELECT * FROM ebspos where  posTid like '$posTid' and posMid like '$posMid' and merchantName like '%$merchantName%' and location like '%$location%' and posType like '$posType' and model like '$model' and vendor like '%$vendor%'";

}
else
{
$a=0;
$query = "SELECT * FROM ebspos where  posTid like '$posTid' and posMid like '$posMid' and merchantName like '%$merchantName%' and location like '%$location%' and posType like '$posType' and model like '$model' and vendor like '%$vendor%' and installDate between '$installDateF' and '$installDateT' and receivedDate between '$receivedDateF' and '$receivedDateT'";
}

$result = mysql_query($query);
$num = mysql_num_rows($result);
//echo $num;
mysql_close(); 
if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use another search conditions</strong></font>');
exit();
}
?>
<table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="12" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for EBS--POS --- <a href="report/ebsPOS.php?<?php echo 'posTidR='.$posTidR;?>&amp;<?php echo 'posMidR='.$posMidR;?>&amp;<?php echo 'merchantNameR='.$merchantNameR;?>&amp;<?php echo 'locationR='.$locationR;?>&amp;<?php echo 'posTypeR='.$posTypeR;?>&amp;<?php echo 'modelR='.$modelR;?>&amp;<?php echo 'installDateFR='.$installDateFR;?>&amp;<?php echo 'installDateTR='.$installDateTR;?>&amp;<?php echo 'receivedDateFR='.$receivedDateFR;?>&amp;<?php echo 'receivedDateTR='.$receivedDateTR;?>&amp;<?php echo 'vendorR='.$vendorR;?>&amp;<?php echo 'a='.$a;?>" target="_blank">Export report</a> </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="3%"><font color="#000000"><strong>No</strong></font></td><td width="7%"><font color="#000000"><strong>POS-TID</strong></font></td>
	<td width="9%"><font color="#000000"><strong>POS-MID</strong></font></td><td width="10%"><font color="#000000"><strong>Merchant Name</strong></font></td>
	<td width="20%"><font color="#000000"><strong>Location Name</strong></font></td><td width="8%"><font color="#000000"><strong>POS Type</strong></font></td>
	<td width="8%"><font color="#000000"><strong>Model Name</strong></font></td><td width="10%"><font color="#000000"><strong>Vendor Name</strong></font></td>
	<td width="5%"><font color="#000000"><strong>S-Tel No</strong></font></td><td width="6%"><font color="#000000"><strong>P-Tel No</strong></font></td>
	<td width="7%"><font color="#000000"><strong>Received Date</strong></font></td><td width="7%"><font color="#000000"><strong>Installation Date</strong></font></td>
    </tr>
  
</table>
<?php 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$posTid = mysql_result($result,$i,"posTid");
$posMid = mysql_result($result,$i,"posMid");
$merchantName = mysql_result($result,$i,"merchantName");
$location = mysql_result($result,$i,"location");
$posType = mysql_result($result,$i,"posType");
$model = mysql_result($result,$i,"model");
$vendor = mysql_result($result,$i,"vendor");
$sTel = mysql_result($result,$i,"sTel");
$pTel = mysql_result($result,$i,"pTel");
$installDate = mysql_result($result,$i,"installDate");
$receivedDate = mysql_result($result,$i,"receivedDate");
//$vendor = mysql_result($result,$i,"vendor");
//$location = mysql_result($result,$i,"location");

?> 

      <table width="188%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="3%"> <p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="7%"> <p><font color="#000000" size="2"><?php echo $posTid;?></font></p></td>
          <td width="9%"> <p><font color="#000000" size="2"><?php echo $posMid;?></font></p></td>
          <td width="10%"> <p><font color="#000000" size="2"><?php echo $merchantName;?></font></p></td>
          <td width="20%"> <p><font color="#000000" size="2"><?php echo $location;?></font></p></td>
          <td width="8%"> <p><font color="#000000" size="2"><?php echo $posType;?></font></p></td>
          <td width="8%"> <p><font color="#000000" size="2"><?php echo $model;?></font></p></td>
          <td width="10%"> <p><font color="#000000" size="2"><?php echo $vendor;?></font></p></td>
          <td width="5%"> <p><font color="#000000" size="2"><?php echo $sTel;?></font></p></td>
          <td width="12%"> <p><font color="#000000" size="2"><?php echo $pTel;?></font></p></td>
          <td width="7%"> <p><font color="#000000" size="2"><?php echo $installDate;?></font></p></td>
          <td width="7%"> <p><font color="#000000" size="2"><?php echo $receivedDate;?></font></p></td>
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>

    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
