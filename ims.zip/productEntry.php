<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM subcategory";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<?php
if (isset($_REQUEST['submit']))
{
      
      move_uploaded_file($_FILES["image"]["tmp_name"],
      "./images/hardware/" . $_FILES["image"]["name"]);
      
      
	  $ppic = $_FILES["image"]["name"];
	  
	  $pname = $_POST['pname'];
	  
$pdes = $_POST['pdes'];

$status = $_POST['status'];
$pquantity = $_POST['pquantity'];
$pcategory = $_POST['pcategory'];
$subcategory = $_POST['subcategory'];

	  include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

	$query = "INSERT INTO product VALUES ('','$pname','$pdes','$ppic','$status','$pquantity','$pcategory','$subcategory')";
mysql_query($query);

mysql_close();  
	  
	}
		
	?>	
</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
	  <table width="100%" height="481" border="0" bgcolor="#66CCFF">
        <tr>
    <td align="center" valign="top"><form action="" method="post" target="_self" enctype="multipart/form-data">
        <table width="100%" border="0">
          <tr> 
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                    Name</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="pname" type="text" id="pname">
                    <br>
                    </strong></font></td>
          </tr>
		  <tr> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                    Category</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="pcategory" type="text" id="pcategory" value="HARDWARE" readonly="true">
                    <br>
                    </strong></font></td>
          </tr>
		  <tr> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Sub Category</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="subcategory">
	<option>Select Sub Category</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$CatName = mysql_result($result,$i,"CatName");
echo "<option>";
echo $CatName;
echo "</option>" ; 
$i++;
}
?>"> </select>
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td height="188" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                    Description</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <textarea name="pdes" cols="" rows="8"></textarea>
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                    picture</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="image" type="file" id="ppic">
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                    Product Status</strong></font></td>
                  <td valign="middle"> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input type="radio" name="status" value="a" id="status">
                    Available 
                    <input type="radio" name="status" value="n" id="status">
                    Not Available <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td height="41" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                    Product Quantity</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input name="pquantity" type="text" id="pquantity">
                    </strong></font></td>
          </tr>
          <tr> 
            <td></br></td>
            <td></br></td>
          </tr>
          <tr> 
            <td></br></td>
            <td></br></td>
          </tr>
          <tr> 
            <td align="center"><input name="submit" type="submit" value="Submit"><br>
<br>
</td>
            <td align="center"><input name="" type="reset" value="Reset"><br>
<br>
</td>
          </tr>
        </table>
</form></td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
