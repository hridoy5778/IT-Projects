<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM department order by deptName";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query2 = "SELECT * FROM jobgrade";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
mysql_close();
?>
<script type="text/javascript">
function validate_required(field,alerttxt)
{
with (field)
{
if (value==null||value=="")
  {alert(alerttxt);return false}
else {return true}
}
}


function validate_form(thisform)
{
with (thisform)
{
if (validate_required(name,"Name must be filled out!")==false)
  {name.focus();return false}
 if (validate_required(pin,"PIN must be filled out!")==false)
  {pin.focus();return false}
if (validate_required(team,"TEAM must be filled out!")==false)
  {team.focus();return false}

}
}
</script>
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    <br>
<br>
<br>
<br>

    <div id="contentCol">
<form action="clearanceSQL.php" onsubmit="return validate_form(this)" method="post" target="_parent">
	    <table width="100%" border="0">
          <tr bgcolor="#0066FF"> 
            <td colspan="2"><div align="center">
                <p><font color="#FFFFFF"><strong>Clearance Entry</strong></font></p>
                </div>
            </td>
	
  </tr>
          <tr bgcolor="#CCCCCC"> 
            <td><font color="#000000"><strong>Employee NAME</strong></font><br>
</td>
	        <td> 
              <input name="name" type="text" size="50"></td>
  </tr>
          
  
          <tr bgcolor="#CCCCCC"> 
            <td><font color="#000000"><strong>PIN Number</strong></font><br>
</td>
	        <td> 
              <input name="pin" type="text" size="50"></td>
  </tr>
          
  
          <tr bgcolor="#CCCCCC"> 
            <td><font color="#000000"><strong>Clearance Date</strong></font><br>
</td>
	        <td> 
              <input name="clDate" type="text" size="25" id="clDate" readonly="true">
                      <img src="images/search_calendar.png" id="calF"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" />
	
	
	
	
	</td>
  </tr>
  
          <tr bgcolor="#CCCCCC"> 
            <td><font color="#000000"><strong>Team ID</strong></font><br>
</td>
	        <td> 
              <input name="team" type="text" size="50"></td>
  </tr>
  <tr bgcolor="#CCCCCC"> 
            <td><font color="#000000"><strong>Department</strong></font><br>
</td>
	        <td> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
              <select name="dept">
	<option>Select Department</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$deptName = mysql_result($result,$i,"deptName");
echo "<option>";
echo $deptName;
echo "</option>" ; 
$i++;
}
?>"> </select>
</strong></font>
	</td>
  </tr>
  
          <tr bgcolor="#CCCCCC"> 
            <td><font color="#000000"><strong>Month</strong></font><br>
</td>
	        <td> 
              <select name="month">
	<option>Select Month</option>
  <option>January</option>
  <option>February</option>
  <option>March</option>
  <option>April</option>
  <option>May</option>
  <option>June</option>
  <option>July</option>
  <option>August</option>
  <option>September</option>
  <option>October</option>
  <option>November</option>
  <option>December</option>
</select></td>
  </tr>
  <tr bgcolor="#CCCCCC"> 
            <td><font color="#000000"><strong>Employee Grade</strong></font><br>
</td>
	        <td> 
              <select name="grade">
	<option>Select Job Grade</option>
		<?php
	   $i=0;
while ($i < $num2) 
{
$gradeName = mysql_result($result2,$i,"gradeName");
echo "<option>";
echo $gradeName;
echo "</option>" ; 
$i++;
}
?>"> </select>
</strong></font></td>
  </tr>
          <tr bgcolor="#CCCCCC"> 
            <td><input name="btnInsert" type="submit" value="ADD Clearance Entry">
              <br>
</td>
	        <td><br>
</td>
  </tr>
  
  
  
</table>
</form>
<script type="text/javascript">
Calendar.setup({
inputField : "clDate",
ifFormat : "%Y-%m-%d",
button : "calF",
align : "T1",
singleClick : true
});
</script>

<br>
<br>
<br>
</div>
    
    <div class="clear"></div>
  </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>