// JavaScript Document
function jobmgm(){
  if(document.getElementById('jobmgm').style.display == 'none'){
  document.getElementById('jobmgm').style.display = '';
  }else if(document.getElementById('jobmgm').style.display == ''){
  document.getElementById('jobmgm').style.display = 'none';
  }
}

function jobmgm1(){
  if(document.getElementById('jobmgm1').style.display == 'none'){
  document.getElementById('jobmgm1').style.display = '';
  }else if(document.getElementById('jobmgm1').style.display == ''){
  document.getElementById('jobmgm1').style.display = 'none';
  }
}

function jobmgm1a(){
  if(document.getElementById('jobmgm1a').style.display == 'none'){
  document.getElementById('jobmgm1a').style.display = '';
  }else if(document.getElementById('jobmgm1a').style.display == ''){
  document.getElementById('jobmgm1a').style.display = 'none';
  }
}

function jobmgm1b(){
  if(document.getElementById('jobmgm1b').style.display == 'none'){
  document.getElementById('jobmgm1b').style.display = '';
  }else if(document.getElementById('jobmgm1b').style.display == ''){
  document.getElementById('jobmgm1b').style.display = 'none';
  }
}

function jobmgm1c(){
  if(document.getElementById('jobmgm1c').style.display == 'none'){
  document.getElementById('jobmgm1c').style.display = '';
  }else if(document.getElementById('jobmgm1c').style.display == ''){
  document.getElementById('jobmgm1c').style.display = 'none';
  }
}

function jobmgm1d(){
  if(document.getElementById('jobmgm1d').style.display == 'none'){
  document.getElementById('jobmgm1d').style.display = '';
  }else if(document.getElementById('jobmgm1d').style.display == ''){
  document.getElementById('jobmgm1d').style.display = 'none';
  }
}


function jobmgm2(){
  if(document.getElementById('jobmgm2').style.display == 'none'){
  document.getElementById('jobmgm2').style.display = '';
  }else if(document.getElementById('jobmgm2').style.display == ''){
  document.getElementById('jobmgm2').style.display = 'none';
  }
}

function jobmgm3(){
  if(document.getElementById('jobmgm3').style.display == 'none'){
  document.getElementById('jobmgm3').style.display = '';
  }else if(document.getElementById('jobmgm3').style.display == ''){
  document.getElementById('jobmgm3').style.display = 'none';
  }
}

function jobmgm4(){
  if(document.getElementById('jobmgm4').style.display == 'none'){
  document.getElementById('jobmgm4').style.display = '';
  }else if(document.getElementById('jobmgm4').style.display == ''){
  document.getElementById('jobmgm4').style.display = 'none';
  }
}

function jobmgm5(){
  if(document.getElementById('jobmgm5').style.display == 'none'){
  document.getElementById('jobmgm5').style.display = '';
  }else if(document.getElementById('jobmgm5').style.display == ''){
  document.getElementById('jobmgm5').style.display = 'none';
  }
}

function jobmgm6(){
  if(document.getElementById('jobmgm6').style.display == 'none'){
  document.getElementById('jobmgm6').style.display = '';
  }else if(document.getElementById('jobmgm6').style.display == ''){
  document.getElementById('jobmgm6').style.display = 'none';
  }
}
function jobmgm7(){
  if(document.getElementById('jobmgm7').style.display == 'none'){
  document.getElementById('jobmgm7').style.display = '';
  }else if(document.getElementById('jobmgm7').style.display == ''){
  document.getElementById('jobmgm7').style.display = 'none';
  }
}
function jobmgm8(){
  if(document.getElementById('jobmgm8').style.display == 'none'){
  document.getElementById('jobmgm8').style.display = '';
  }else if(document.getElementById('jobmgm8').style.display == ''){
  document.getElementById('jobmgm8').style.display = 'none';
  }
}
function jobmgm9(){
  if(document.getElementById('jobmgm9').style.display == 'none'){
  document.getElementById('jobmgm9').style.display = '';
  }else if(document.getElementById('jobmgm9').style.display == ''){
  document.getElementById('jobmgm9').style.display = 'none';
  }
}