<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$nullCHK = $_POST['nullCHK'];
$cdmId = $_POST['cdmId'];
$location = $_POST['location'];
$vendor = $_POST['vendor'];
$ip = $_POST['ip'];

$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}

if($cdmId == "")
{
$cdmId="%";
}
if($location == "Select Location")
{
$location="%";
}
if($vendor == "Select Vendor")
{
$vendor="%";
}

if($ip == "")
{
$ip="%";
}


$cdmIdR = $cdmId;

$vendorR = $vendor;
$ipR = $ip;
$locationR = $location;
$entDateFR = $entDateF;
$entDateTR = $entDateT;
//echo $cdmIdR;
//echo $vendorR;
//echo $entDateF;
//echo $entDateT;
//echo $location;

$a = isset($nullCHK);
if($a==1)
{
$query = "SELECT * FROM ebscdm where  cdmId like '$cdmId' and location like '$location' and vendor like '$vendor' and ip like '$ip'";
}
else
{
$a=0;
$query = "SELECT * FROM ebscdm where  cdmId like '$cdmId' and location like '$location' and vendor like '$vendor' and ip like '$ip' and deliveryDate between '$entDateF' and '$entDateT'";

}




$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      <table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="7" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for EBS--CDM --- <a href="report/ebsCDM.php?<?php echo 'cdmIdR='.$cdmIdR;?>&amp;<?php echo 'vendorR='.$vendorR;?>&amp;<?php echo 'ipR='.$ipR;?>&amp;<?php echo 'locationR='.$locationR;?>&amp;<?php echo 'installDateFR='.$installDateFR;?>&amp;<?php echo 'entDateFR='.$entDateFR;?>&amp;<?php echo 'entDateTR='.$entDateTR;?>&amp;<?php echo 'a='.$a;?>" target="_blank">Export report</a> </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="5%"><font color="#000000"><strong>No</strong></font></td><td width="5%"><font color="#000000"><strong>CDM Serial</strong></font></td><td width="20%"><font color="#000000"><strong>CDM Location</strong></font></td><td width="20%"><font color="#000000"><strong>Vendor Name</strong></font></td><td width="10%"><font color="#000000"><strong>IP Address</strong></font></td><td width="20%"><font color="#000000"><strong>Delivery Date</strong></font></td><td width="20%"><font color="#000000"><strong>Remarks</strong></font></td>
    </tr>
  
</table>
	
	
<?php 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$cdmId = mysql_result($result,$i,"cdmId");
$location = mysql_result($result,$i,"location");
$vendor = mysql_result($result,$i,"vendor");
$ip = mysql_result($result,$i,"ip");
$remarks = mysql_result($result,$i,"remarks");
//$location = mysql_result($result,$i,"location");
$deliveryDate = mysql_result($result,$i,"deliveryDate");

?> 

      <table width="188%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="5%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="5%"><p><font color="#000000" size="2"><?php echo $cdmId;?></font></p></td>
          <td width="20%"><p><font color="#000000" size="2"><?php echo $location;?></font></p></td>
          <td width="20%"><p><font color="#000000" size="2"><?php echo $vendor;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $ip;?></font></p></td>
          <td width="20%"><p><font color="#000000" size="2"><?php echo $deliveryDate;?></font></p></td>
          
          <td width="20%"><p><font color="#000000" size="2"><?php echo $remarks;?></font></p></td>
         
		 
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
