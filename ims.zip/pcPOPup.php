<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$id = $_REQUEST['id'];
$query = "select * from pc where id = '$id'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$i=0;
$buildingBranch = mysql_result($result,$i,"buildingBranch");
$department = mysql_result($result,$i,"department");
$pcUserName = mysql_result($result,$i,"pcUserName");
$cluster = mysql_result($result,$i,"cluster");
$cpuBrand = mysql_result($result,$i,"cpuBrand");
$cpuModel = mysql_result($result,$i,"cpuModel");
$cpuSerial = mysql_result($result,$i,"cpuSerial");
$cpuTag = mysql_result($result,$i,"cpuTag");
$processor = mysql_result($result,$i,"processor");
$ram = mysql_result($result,$i,"ram");
$hdd = mysql_result($result,$i,"hdd");
$cpuStatus = mysql_result($result,$i,"cpuStatus");
$ip = mysql_result($result,$i,"ip");
$pcDomainName = mysql_result($result,$i,"pcDomainName");
$os = mysql_result($result,$i,"os");
$monitorBrand = mysql_result($result,$i,"monitorBrand");
$monitorModel = mysql_result($result,$i,"monitorModel");
$screenSize = mysql_result($result,$i,"screenSize");
$monitorSerial = mysql_result($result,$i,"monitorSerial");
$monitorTag = mysql_result($result,$i,"monitorTag");
$monitorStatus = mysql_result($result,$i,"monitorStatus");
$upsBrand = mysql_result($result,$i,"upsBrand");
$upsSerial = mysql_result($result,$i,"upsSerial");
$upsTag = mysql_result($result,$i,"upsTag");
$upsStatus = mysql_result($result,$i,"upsStatus");
$ramSerial = mysql_result($result,$i,"ramSerial");

//echo $num;
mysql_close(); 
?>
</head>

<body>
<table width="60%" border="3">
  <tr bgcolor="#3399FF"> 
    <td colspan="2"><div align="center"><strong><font size="5"><em>Details PC 
        Information</em></font></strong></div></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td width="45%" bgcolor="#0099FF">Building/Branch</td>
    <td width="55%"><?php echo $buildingBranch;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Department</td>
    <td><?php echo $department;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Person Name</td>
    <td><?php echo $pcUserName;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Cluster </td>
    <td><?php echo $cluster;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Host Name</td>
    <td bgcolor="#00CCFF"><?php echo $pcDomainName;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">IP Address</td>
    <td><?php echo $ip;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Operating System</td>
    <td><?php echo $os;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">CPU Brand</td>
    <td bgcolor="#0099FF"><?php echo $cpuBrand;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">CPU Model</td>
    <td><?php echo $cpuModel;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">CPU Serial</td>
    <td><?php echo $cpuSerial;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Processor</td>
    <td><?php echo $processor;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">CPU Tag</td>
    <td><?php echo $cpuTag;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">RAM</td>
    <td><?php echo $ram;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">RAM Serial</td>
    <td><?php echo $ramSerial;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Hard Disk</td>
    <td><?php echo $hdd;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">CPU Status</td>
    <td><?php echo $cpuStatus;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td>Monitor Brand</td>
    <td bgcolor="#66FFCC"><?php echo $monitorBrand;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td>Monitor Model</td>
    <td bgcolor="#66FFCC"><?php echo $monitorModel;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td bgcolor="#33FFFF">Screen SIze</td>
    <td bgcolor="#66FFCC"><?php echo $screenSize;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td>Monitor Serial</td>
    <td bgcolor="#66FFCC"><?php echo $monitorSerial;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td>Monitor Tag</td>
    <td bgcolor="#66FFCC"><?php echo $monitorTag;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td>Monitor Status</td>
    <td bgcolor="#66FFCC"><?php echo $monitorStatus;?></td>
  </tr>
  <tr bgcolor="#66FFCC"> 
    <td>UPS Brand</td>
    <td bgcolor="#33FFFF"><?php echo $upsBrand;?></td>
  </tr>
  <tr bgcolor="#66FFCC"> 
    <td>UPS Serial</td>
    <td bgcolor="#33FFFF"><?php echo $upsSerial;?></td>
  </tr>
  <tr bgcolor="#66FFCC"> 
    <td>UPS Tag</td>
    <td bgcolor="#33FFFF"><?php echo $upsTag;?></td>
  </tr>
  <tr bgcolor="#66FFCC"> 
    <td>UPS Status</td>
    <td bgcolor="#33FFFF"><?php echo $upsStatus;?></td>
  </tr>
</table>

</body>
</html>
