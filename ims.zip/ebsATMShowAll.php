<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$atmId = "";
$ip = "";
$gateway = "";
$vendor = "Select Vendor";
$brand = "Select Brand";
$model = "Select Model";
$installDateF = "";
$installDateT = "";
$receivedDateF = "";
$receivedDateT = "";
$city = "Select City Name";
$location = "Select Location Name";
//echo $brand;

if($installDateF == "")
{
$installDateF="%";
}
if($installDateT == "")
{
$installDateT=date('Y-m-d');
}

if($receivedDateF == "")
{
$receivedDateF="%";
}
if($receivedDateT == "")
{
$receivedDateT=date('Y-m-d');
}


if($atmId == "")
{
$atmId="%";
}
if($location == "Select Location Name")
{
$location="%";
}
if($ip == "")
{
$ip="%";
}
if($gateway == "")
{
$gateway="%";
}
if($vendor == "Select Vendor")
{
$vendor="%";
}
if($brand == "Select Brand")
{
$brand="%";
}
if($model == "Select Model")
{
$model="%";
}
if($city == "Select City Name")
{
$city="%";
}

$atmIdR = $atmId;
$ipR = $ip;
$gatewayR = $gateway;
$vendorR = $vendor;
$brandR = $brand;
$modelR = $model;
$installDateFR = $installDateF;
$installDateTR = $installDateT;
$receivedDateFR = $receivedDateF;
$receivedDateTR = $receivedDateT;
$cityR = $city;
$locationR = $location;
//echo $serial;
//echo $installDateF;
//echo $installDateT;
//echo $brand;
//echo $location;
//echo $receivedDateT;
$query = "SELECT * FROM ebsatm where  atmId like '$atmId' and ip like '$ip' and gateway like '$gateway' and vendor like '$vendor' and brand like '$brand' and model like '$model' and location like '%$location%' and city like '%$city%'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
//echo $num;
mysql_close(); 
?>
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      <table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="13" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for EBS--ATM---<a href="report/ebsATM.php?<?php echo 'atmIdR='.$atmIdR;?>&amp;<?php echo 'ipR='.$ipR;?>&amp;<?php echo 'gatewayR='.$gatewayR;?>&amp;<?php echo 'vendorR='.$vendorR;?>&amp;<?php echo 'brandR='.$brandR;?>&amp;<?php echo 'modelR='.$modelR;?>&amp;<?php echo 'installDateFR='.$installDateFR;?>&amp;<?php echo 'installDateTR='.$installDateTR;?>&amp;<?php echo 'receivedDateFR='.$receivedDateFR;?>&amp;<?php echo 'receivedDateTR='.$receivedDateTR;?>&amp;<?php echo 'locationR='.$locationR;?>&amp;<?php echo 'cityR='.$cityR;?>" target="_blank">Export report</a> </em></strong></font></div></td>
          </td>
    </tr>	  
	  
        <tr bgcolor="#CCCCCC">
    <td width="4%"><font color="#000000"><strong>No</strong></font></td><td width="5%"><font color="#000000"><strong>ATM ID</strong></font></td><td width="8%"><font color="#000000"><strong>IP Address</strong></font></td><td width="8%"><font color="#000000"><strong>Gateway</strong></font></td><td width="5%"><font color="#000000"><strong>Vendor Name</strong></font></td><td width="10%"><font color="#000000"><strong>Brand Name</strong></font></td><td width="9%"><font color="#000000"><strong>Model Name</strong></font></td><td width="9%"><font color="#000000"><strong>Received Date</strong></font></td><td width="12%"><font color="#000000"><strong>Installation Date</strong></font></td><td width="6%"><font color="#000000"><strong>City</strong></font></td><td width="8%"><font color="#000000"><strong>Location</strong></font></td><td width="8%"><font color="#000000"><strong>Address</strong></font></td><td width="8%"><font color="#000000"><strong>Remarks</strong></font></td>
    </tr>
  
</table>
	
	
<?php 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$atmId = mysql_result($result,$i,"atmId");
$ip = mysql_result($result,$i,"ip");
$gateway = mysql_result($result,$i,"gateway");
$vendor = mysql_result($result,$i,"vendor");
$brand = mysql_result($result,$i,"brand");
$model = mysql_result($result,$i,"model");
$installDate = mysql_result($result,$i,"installDate");
$receivedDate = mysql_result($result,$i,"receivedDate");
$city = mysql_result($result,$i,"city");
$location = mysql_result($result,$i,"location");
$address = mysql_result($result,$i,"address");
$remarks = mysql_result($result,$i,"remarks");
?> 

      <table width="188%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="4%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="5%"><p><font color="#000000" size="2"><?php echo $atmId;?></font></p></td>
          <td width="8%"><p><font color="#000000" size="2"><?php echo $ip;?></font></p></td>
          <td width="8%"><p><font color="#000000" size="2"><?php echo $gateway;?></font></p></td>
          <td width="5%"><p><font color="#000000" size="2"><?php echo $vendor;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $brand;?></font></p></td>
          <td width="9%"><p><font color="#000000" size="2"><?php echo $model;?></font></p></td>
		  <td width="9%"><p><font color="#000000" size="2"><?php echo $installDate;?></font></p></td>
		   <td width="12%"><p><font color="#000000" size="2"><?php echo $receivedDate;?></font></p></td>
		    <td width="6%"><p><font color="#000000" size="2"><?php echo $city;?></font></p></td>
          <td width="8%"><p><font color="#000000" size="2"><?php echo $location;?></font></p></td>
          <td width="8%"><p><font color="#000000" size="2"><?php echo $address;?></font></p></td>
		  <td width="8%"><p><font color="#000000" size="2"><?php echo $remarks;?></font></p></td>
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>

    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
