<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];

 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

function replace($replace,$replacewith,$inme)
{
$doit = str_replace ("$replace", "$replacewith", $inme);
return $doit;
}

$name = $_POST['name'];
$type = $_POST['type'];
$wing = $_POST['wing'];
$ownerName = $_POST['ownerName'];
$category = $_POST['category'];
$location = $_POST['location'];
$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];
$status = $_POST['status'];
if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}
//echo $entDateF;
//echo $entDateT;
if($name == "")
{
$name="%";
}
if($name != "")
{
$name = replace(" ",'%',"$name");
}
if($wing == "")
{
$wing="%";
}
if($wing != "")
{
$wing = replace(" ",'%',"$wing");
}
if($ownerName == "")
{
$ownerName="%";
}
if($ownerName != "")
{
$ownerName = replace(" ",'%',"$ownerName");
}
if($category == "Select Category")
{
$category="%";
}
if($type == "Select Type")
{
$type="%";
}
if($location == "Select Location")
{
$location="%";
}
if($status == "")
{
$status="%";
}




$typeR = $type;
$nameR = $name;
$ownerNameR = $ownerName;
$wingR = $wing;
$categoryR = $category;
$locationR = $location;
$entDateFR = $entDateF;
$entDateTR = $entDateT;
$statusR = $status;


$query = "SELECT * FROM hsm where  name like '%$name%' and category like '$category' and ownerName like '%$ownerName%' and location like '$location' and status like '$status' and entDate between '$entDateF' and '$entDateT' and wing like '%$wing%'and type like '$type'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
if($num != 0)
{
echo "Query probs";
}

mysql_close(); 
?>

<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    <?php 
	if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}
	
	?>
    <div id="contentCol">
	
      <table width="189%" border="3">
	  <tr bgcolor="#CCCCCC">
          <td height="36" colspan="10" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for Vault's Components 
              --- <a href="report/Vault.php?<?php echo 'nameR='.$nameR;?>&amp;<?php echo 'ownerNameR='.$ownerNameR;?>&amp;<?php echo 'wingR='.$wingR;?>&amp;<?php echo 'categoryR='.$categoryR;?>&amp;<?php echo 'locationR='.$locationR;?>&amp;<?php echo 'entDateFR='.$entDateFR;?>&amp;<?php echo 'entDateTR='.$entDateTR;?>&amp;<?php echo 'statusR='.$statusR;?>&amp;<?php echo 'typeR='.$typeR;?>" target="_blank">Export report</a> </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="3%"><font color="#000000"><strong>No</strong></font></td><td width="26%"><font color="#000000"><strong>Product Name</strong></font></td><td width="10%"><font color="#000000"><strong>Product Type</strong></font></td>
	<td width="5%"><font color="#000000"><strong>Tag No</strong></font></td><td width="15%"><font color="#000000"><strong>CATEGORY</strong></font></td><td width="15%"><font color="#000000"><strong>Vault Location</strong></font></td><td width="8%"><font color="#000000"><strong>Status</strong></font></td>
	<td width="6%"><font color="#000000"><strong>Owner Name</strong></font></td><td width="5%"><font color="#000000"><strong>Wing</strong></font></td><td width="10%"><font color="#000000"><strong>Entry Date</strong></font></td>
    </tr>
  
</table>
	
	

<?php 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}
$type = mysql_result($result,$i,"type");
$name = mysql_result($result,$i,"name");
$tag = mysql_result($result,$i,"tag");
$category = mysql_result($result,$i,"category");
$location = mysql_result($result,$i,"location");
$status = mysql_result($result,$i,"status");
$ownerName = mysql_result($result,$i,"ownerName");
$wing = mysql_result($result,$i,"wing");
if($status=='a')
{
$status = 'Available';
}
if($status=='n')
{
$status = 'Not Available';
}
$entDate = mysql_result($result,$i,"entDate");

?> 

      <table width="188%" border="4">
        <tr bgcolor="<?php echo $rColor; ?>">
<td width="3%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $i+1;?></font></td>
 <td width="26%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $name;?></font></td>
 <td width="10%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $type;?></font></td>
 <td width="5%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $tag;?></font></td>
          <td width="15%"><font color="#000000" size="2">&nbsp;&nbsp;<?php echo $category;?></font></td>
          <td width="15%"><font color="#000000" size="2"><?php echo $location;?></font></td>
		  <td width="8%"><font color="#000000" size="2"><?php echo $status;?></font></td>
		  <td width="6%"><font color="#000000" size="2"><?php echo $ownerName;?></font></td>
		  <td width="5%"><font color="#000000" size="2"><?php echo $wing;?></font></td>
		  <td width="10%"><font color="#000000" size="2"><?php echo $entDate;?></font></td>
		  
    
  </tr>
  
</table>






<?php

$i++; 



}

?>

 </div>
   
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
