<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


function replace($replace,$replacewith,$inme)
{
$doit = str_replace ("$replace", "$replacewith", $inme);
return $doit;
}

$name = $_POST['name'];
$tag = $_POST['tag'];
$type = $_POST['type'];
$wing = $_POST['wing'];
$ownerName = $_POST['ownerName'];
$category = $_POST['category'];
$location = $_POST['location'];
$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];
$status = $_POST['status'];
$remarks = $_POST['remarks'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}
//echo $entDateF;
//echo $entDateT;
if($name == "")
{
$name="%";
}
if($name != "")
{
$name = replace(" ",'%',"$name");
}
if($wing == "")
{
$wing="%";
}
if($wing != "")
{
$wing = replace(" ",'%',"$wing");
}
if($ownerName == "")
{
$ownerName="%";
}
if($ownerName != "")
{
$ownerName = replace(" ",'%',"$ownerName");
}
if($category == "Select Category")
{
$category="%";
}
if($tag == "")
{
$tag="%";
}
if($type == "Select Type")
{
$type="%";
}
if($location == "Select Location")
{
$location="%";
}
if($status == "")
{
$status="%";
}
if($remarks == "")
{
$remarks="%";
}
if($remarks != "")
{
$remarks = replace(" ",'%',"$remarks");
}
$query = "SELECT * FROM hsm where  name like '%$name%' and category like '$category' and ownerName like '%$ownerName%' and location like '$location' and remarks like '$remarks' and status like '$status' and entDate between '$entDateF' and '$entDateT' and wing like '%$wing%' and type like '$type' and tag like '$tag'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 
?>
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    <?php 
	if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}
	
	?>
    <div id="contentCol">
	
      <table width="186%" border="3">
        <tr bgcolor="#CCCCCC">
    <td width="3%"><font color="#000000"><strong></strong></font></td><td width="21%"><font color="#000000"><strong>Product Name</strong></font></td><td width="10%"><font color="#000000"><strong>Product Type</strong></font></td>
	<td width="5%"><font color="#000000"><strong>Tag No</strong></font></td><td width="15%"><font color="#000000"><strong>CATEGORY</strong></font></td><td width="15%"><font color="#000000"><strong>Vault Location</strong></font></td><td width="8%"><font color="#000000"><strong>Status</strong></font></td>
	<td width="6%"><font color="#000000"><strong>Owner Name</strong></font></td><td width="5%"><font color="#000000"><strong>Wing</strong></font></td><td width="10%"><font color="#000000"><strong>Entry Date</strong></font></td><td width="5%"><font color="#000000"><strong>Remarks</strong></font></td>
    </tr>
  
</table>
	
	<?php 

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}
$id = mysql_result($result,$i,"id");
$name = mysql_result($result,$i,"name");
$tag = mysql_result($result,$i,"tag");
$type = mysql_result($result,$i,"type");
$category = mysql_result($result,$i,"category");
$location = mysql_result($result,$i,"location");
$status = mysql_result($result,$i,"status");
$ownerName = mysql_result($result,$i,"ownerName");
$wing = mysql_result($result,$i,"wing");
$remarks = mysql_result($result,$i,"remarks");
$entDate = mysql_result($result,$i,"entDate");
if($status=='a')
{
$status = 'Available';
$statusColor = '#00FF00';
}
if($status=='n')
{
$status = 'Not Available';
$statusColor = '#FF0000';
}

?> 
<form action="hsmUpdateSQL2.php" method="post" enctype="multipart/form-data">
      <table width="188%" border="4">
        <tr bgcolor="<?php echo $rColor; ?>">
<td width="3%" bgcolor="<?php echo $statusColor; ?>"><input name="done[]" type="radio" value="<?php echo $id;?>"></td>
 <td width="21%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $name;?></font></td>
 <td width="10%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $type;?></font></td>
 <td width="5%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $tag;?></font></td>
          <td width="15%"><font color="#000000" size="2">&nbsp;&nbsp;<?php echo $category;?></font></td>
          <td width="15%"><font color="#000000" size="2"><?php echo $location;?></font></td>
		  <td width="8%"><font color="#000000" size="2"><?php echo $status;?></font></td>
		  <td width="6%"><font color="#000000" size="2"><?php echo $ownerName;?></font></td>
		  <td width="5%"><font color="#000000" size="2"><?php echo $wing;?></font></td>
		  <td width="10%"><font color="#000000" size="2"><?php echo $entDate;?></font></td>
		  <td width="5%"><font color="#000000" size="2"><?php echo $remarks;?></font></td>
		  
    
  </tr>
  
</table>







<?php

$i++; 



}

?>
<input name="" type="submit" value="Click to update">

</form>
 </div>
   
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
