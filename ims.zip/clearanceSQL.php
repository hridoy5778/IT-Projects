<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol"><?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$name = $_POST['name'];
$dept = $_POST['dept'];
$team = $_POST['team'];
$pin = $_POST['pin'];
$grade = $_POST['grade'];
$clDate = $_POST['clDate'];
$month = $_POST['month'];

$querySearch = "select * from clearance where pin = '$pin'";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
echo $num;
if($num > 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Record already existed.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another pin number</strong></font><br>
<br>
<br>
<a href="clearanceEntry.php" target="_parent">Bact to Clearance Entry Page</a>');
exit();
}

$query = "INSERT INTO clearance VALUES ('','$name','$dept','$team','$pin','$grade','$clDate','$month','','','','')";
mysql_query($query);

mysql_close();
?> 
<h3>Clearance Info have been Inserted to Database......Thank You.</h3>
<br>
<br>
<br>

<a href="clearanceEntry.php" target="_parent">Bact to Clearance Entry Page</a> </div>
    
    <div class="clear"></div>
  </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>













<body>

</body>
</html>
