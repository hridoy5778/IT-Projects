<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<hr><br>
<?php 
include("config.php");

mysql_connect($dbhost,$dbuser,$dbpass);

@mysql_select_db($db) or die( "Unable to select database");

$query="CREATE TABLE Category (
CatId int NOT NULL AUTO_INCREMENT  ,
CatName varchar(255) NOT NULL , 
CatDescription text NULL,
PRIMARY KEY(CatId) 
)";

mysql_query($query);
mysql_close();

echo("Category Table has been created ! Thank u .");
?>
<hr><br>


</body>
</html>