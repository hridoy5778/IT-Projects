<?php
echo '<img src="./images/2.gif" border="0" alt="Banner Image" height="159" width="525">';
?>
<br>
<br>
