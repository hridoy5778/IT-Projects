<?php
echo "All Rights Reserved @ IT-Security, BRAC BANK LIMITED";
?>