<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM department";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query2 = "SELECT * FROM jobgrade";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
mysql_close();
?>
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");




$pin = $_POST['pin'];

$query3 = "SELECT * FROM clearance where pin ='$pin'";

$result3 = mysql_query($query3);
$num3 = mysql_num_rows($result3);
echo $num3;
mysql_close(); 
$i3=0;




$name3 = mysql_result($result3,$i3,"name");
$dept3 = mysql_result($result3,$i3,"dept");
$pin3 = mysql_result($result3,$i3,"pin");
$grade3 = mysql_result($result3,$i3,"grade");
$team3 = mysql_result($result3,$i3,"team");
$clDate3 = mysql_result($result3,$i3,"clDate");
$month3 = mysql_result($result3,$i3,"month");

?> 

<table width="100%" border="0">
  <tr>
    <td><form action="clearanceUpdateSQL2.php" method="post" target="_parent">
	<table width="100%" border="0">
  
  <tr>
    <td><font color="#000000"><strong>Employee NAME</strong></font></td>
	<td><input name="name" type="text" size="50" value="<?php echo $name3;?>"></td>
  </tr>
  <tr>
    <td><font color="#000000"><strong>Department</strong></font></td>
	<td>
	<font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="dept">
	<option><?php echo $dept3;?></option>
		<?php
	   $i=0;
while ($i < $num) 
{
$deptName = mysql_result($result,$i,"deptName");
echo "<option>";
echo $deptName;
echo "</option>" ; 
$i++;
}
?>"> </select>
</strong></font>
	</td>
  </tr>
  
  <tr>
    <td><font color="#000000"><strong>Month</strong></font></td>
	<td>
	<select name="month">
	<option><?php echo $month3;?></option>
  <option>January</option>
  <option>February</option>
  <option>March</option>
  <option>April</option>
  <option>May</option>
  <option>June</option>
  <option>July</option>
  <option>August</option>
  <option>September</option>
  <option>October</option>
  <option>November</option>
  <option>December</option>
</select></td>
  </tr>
  
  <tr>
    <td><font color="#000000"><strong>PIN Number</strong></font></td>
	<td><input name="pin" type="text" size="50" value="<?php echo $pin3;?>"></td>
  </tr>
  <tr>
    <td><font color="#000000"><strong>Employee Grade</strong></font></td>
	<td>
	<select name="grade">
	<option><?php echo $grade3;?></option>
		<?php
	   $i=0;
while ($i < $num2) 
{
$gradeName = mysql_result($result2,$i,"gradeName");
echo "<option>";
echo $gradeName;
echo "</option>" ; 
$i++;
}
?>"> </select>
</strong></font></td>
  </tr>
  
   <tr>
    <td><font color="#000000"><strong>Clearance Date</strong></font></td>
	<td><input name="clDate" type="text" size="50" value="<?php echo $clDate3;?>"></td>
  </tr>
  
   <tr>
    <td><font color="#000000"><strong>Team ID</strong></font></td>
	<td><input name="team" type="text" size="50" value="<?php echo $team3;?>"></td>
  </tr>
  
  
  
  
  <tr>
    
	<td><input name="btnInsert" type="submit" value="Update Clearance Entry"></td>
  </tr>
</table>
</form><br>
<br>
<br>
</td>
  </tr>
</table>












     
 
 
 
          








 </div>
   
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>













<body>

</body>
</html>
