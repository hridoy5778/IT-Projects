<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$hostname = $_POST['hostname'];
$sol = $_POST['sol'];
$deptBR = $_POST['deptBR'];
$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}

if($hostname == "")
{
$hostname="%";
}
if($sol == "Select SOL")
{
$sol="%";
}
if($deptBR == "Select Dept/BR")
{
$deptBR="%";
}
$hostnameR = $hostname;
$solR = $sol;
$deptBRR = $deptBR;
$entDateFR = $entDateF;
$entDateTR = $entDateT;

$query = "SELECT * FROM pcname where  hostname like '%$hostname%' and sol like '$sol' and deptBR like '$deptBR' and entDate between '$entDateF' and '$entDateT' order by entDate";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 
if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use another search conditions</strong></font>');
exit();
}
?>
<table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="7" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for Workstations 
              Name--- <a href="report/workStation.php?<?php echo 'hostnameR='.$hostnameR;?>&amp;<?php echo 'solR='.$solR;?>&amp;<?php echo 'deptBRR='.$deptBRR;?>&amp;<?php echo 'entDateFR='.$entDateFR;?>&amp;<?php echo 'entDateTR='.$entDateTR;?>" target="_blank">Export 
              report</a> </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="3%"><font color="#000000"><strong>No</strong></font></td><td width="22%"><font color="#000000"><strong>Workstation Name</strong></font></td><td width="8%"><font color="#000000"><strong>SOL</strong></font></td><td width="21%"><font color="#000000"><strong>Department / Branch</strong></font></td><td width="11%"><font color="#000000"><strong>Entry Date</strong></font></td><td width="14%"><font color="#000000"><strong>Requested By</strong></font></td><td width="21%"><font color="#000000"><strong>Created By</strong></font></td>
    </tr>
  
</table>
<?php 
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$hostname = mysql_result($result,$i,"hostname");
$sol = mysql_result($result,$i,"sol");
$deptBR = mysql_result($result,$i,"deptBR");
$requestB = mysql_result($result,$i,"requestB");
$createB = mysql_result($result,$i,"createB");
$entDate = mysql_result($result,$i,"entDate");

?> 

      <table width="188%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>">
<td width="3%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $i+1; ?></font></td>
 <td width="22%"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $hostname;?></font></td>
          <td width="9%"><font color="#000000" size="2"><?php echo $sol;?></font></td>
          <td width="21%"><font color="#000000" size="2"><?php echo $deptBR;?></font></td>
		  <td width="11%"><font color="#000000" size="2"><?php echo $entDate;?></font></td>
		  <td width="14%"><font color="#000000" size="2"><?php echo $requestB;?></font></td>
		  <td width="20%"><font color="#000000" size="2"><?php echo $createB;?></font></td>
    
  </tr>
  
</table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
