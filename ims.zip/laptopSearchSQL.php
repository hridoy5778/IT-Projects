<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      
	
	<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$hostNameCHK = $_POST['hostNameCHK'];
$name = $_POST['name'];
$lanId = $_POST['lanId'];
$ip = $_POST['ip'];
$hostName = $_POST['hostName'];
$buildingBranch = $_POST['buildingBranch'];
$serial = $_POST['serial'];
$tag = $_POST['tag'];
$location = $_POST['location'];
$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}
if($name == "")
{
$name="%";
}
if($lanId == "")
{
$lanId="%";
}
if($ip == "")
{
$ip="%";
}
if($hostName == "")
{
$hostName="%";
}
if($location == "Select Location")
{
$location="%";
}
function replace($replace,$replacewith,$inme)
{
$doit = str_replace ("$replace", "$replacewith", $inme);
return $doit;
}


$name = replace(" ",'%',"$name");

$a = isset($hostNameCHK);
if($a==1)
{
$query = "SELECT * FROM laptop where  name like '%$name%' and lanId like '$lanId' and ip like '$ip' 
and hostName not like 'L-%' and location like '$location' and entDate between '$entDateF' and '$entDateT'";

}
else
{
$a=0;
$query = "SELECT * FROM laptop where  name like '%$name%' and lanId like '$lanId' and ip like '$ip' 
and hostName like '$hostName%' and location like '$location' and entDate between '$entDateF' and '$entDateT'";
}

$name = $name;
$lanId = $lanId;
$ip = $ip;
$hostName = $hostName;
$location = $location;


$entDateF = $entDateF;
$entDateT = $entDateT;
//echo $x;
//echo $type;
//echo $entDateF;
//echo $entDateT;
//echo $location;
$query = $query;

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 
if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}

?>
<table width="189%" border="3" cellspacing="2">
<tr bgcolor="#CCCCCC">
          <td height="36" colspan="11" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for Laptop's 
--- <a href="report/laptop.php?<?php echo 'name='.$name;?>&amp;<?php echo 'lanId='.$lanId;?>&amp;<?php echo 'ip='.$ip;?>&amp;<?php echo 'hostName='.$hostName;?>&amp;<?php echo 'location='.$location;?>&amp;<?php echo 'a='.$a;?>&amp;<?php echo 'entDateF='.$entDateF;?>&amp;<?php echo 'entDateT='.$entDateT;?>" target="_blank">Export report</a>  </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="5%"><font color="#000000"><strong>No</strong></font></td>
	<td width="15%"><font color="#000000"><strong>Laptop Name</strong></font></td>
	<td width="20%"><font color="#000000"><strong>Lan ID</strong></font></td>
	<td width="10%"><font color="#000000"><strong>IP Address</strong></font></td>
	<td width="15%"><font color="#000000"><strong>Host Name</strong></font></td>
	<td width="15%"><font color="#000000"><strong>Location</strong></font></td>
	<td width="10%"><font color="#000000"><strong>Entry Date</strong></font></td>
	<td width="10%"><font color="#000000"><strong>Details</strong></font></td>
	
    </tr>
  
</table>
<?php
$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$name = mysql_result($result,$i,"name");
$lanId = mysql_result($result,$i,"lanId");
$ip = mysql_result($result,$i,"ip");
$hostName = mysql_result($result,$i,"hostName");
$location = mysql_result($result,$i,"location");
//$cluster = mysql_result($result,$i,"cluster");

$entDate = mysql_result($result,$i,"entDate");

?> 

      <table width="188%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="5%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="15%"><p><font color="#000000" size="2"><?php echo $name;?></font></p></td>
          <td width="20%"><p><font color="#000000" size="2"><?php echo $lanId;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $ip;?></font></p></td>
          <td width="15%"><p><font color="#000000" size="2"><?php echo $hostName;?></font></p></td>
          <td width="15%"><p><font color="#000000" size="2"><?php echo $location;?></font></p></td>
		  <td width="10%"><p><font color="#000000" size="2"><?php echo $entDate;?></font></p></td>
          <td width="10%" bgcolor="#CCCCCC">
<p><font color="#000000" size="2"><a href="#" onClick="window.open('laptopPOPup.php?id=<?php echo mysql_result($result,$i,'id');  ?>','','height=600,width=450,scrollbars=yes,toolbar=yes')"><strong><font color="#0000FF">Details</font></strong></a></p></td>
          </tr>
      </table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
