<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT distinct(sol) FROM pcname";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query2 = "SELECT distinct(deptBR) FROM pcname";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
mysql_close();
?>
<?php
if (isset($_REQUEST['submit']))
{
      
      move_uploaded_file($_FILES["image"]["tmp_name"],
      "./images/hsm/" . $_FILES["image"]["name"]);
      
      
	  $ppic = $_FILES["image"]["name"];
	  
	  $name = $_POST['name'];
	  

$location = $_POST['location'];
$status = $_POST['status'];
$unit = $_POST['unit'];
$category = $_POST['category'];
$entDate = $_POST['entDate'];


	  include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

	$query = "INSERT INTO hsm VALUES ('','$name','$location','$category','$unit','$ppic','$status','$entDate')";
mysql_query($query);

mysql_close();  
	  
	}
		
	?>	
</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
	  <table width="100%" height="481" border="0" bgcolor="#66CCFF">
        <tr>
    <td align="center" valign="top"><form action="" method="post" target="_self" enctype="multipart/form-data">
        <table width="100%" border="0">
		<tr> 
                  <td colspan="2" bgcolor="#00CC00"><br>
                    <strong><font color="#000000" size="4">Workstation Name Entry</font></strong><br>
</td>
            
          </tr>
          <tr> 
            <td><br></td>
            <td><br></td>
          </tr>
          <tr> 
                  <td height="120" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Workstation 
                    Name</strong></font></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="hostname" type="text" size="35">
                    <br>
                    </strong></font></td>
          </tr>
		  <tr> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Workstation's SOL</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="sol">
	<option>Select SOL</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$sol = mysql_result($result,$i,"sol");
echo "<option>";
echo $sol;
echo "</option>" ; 
$i++;
}
?>"> </select>
                    <br>
                    </strong></font></td>
          </tr>
		  <tr> 
                  <td height="65" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Department / Branch</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="deptBR">
	<option>Select Dept/Branch</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$deptBR = mysql_result($result,$i,"deptBR");
echo "<option>";
echo $deptBR;
echo "</option>" ; 
$i++;
}
?>"> </select>
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td height="188" valign="middle"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Vault Location</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="location" type="text" value="DC MINI VAULT" readonly="true">
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Product 
                    picture</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="image" type="file" id="ppic">
                    <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                    Product Status</strong></font></td>
                  <td valign="middle"> <font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input type="radio" name="status" value="a" id="status">
                    Available 
                    <input type="radio" name="status" value="n" id="status">
                    Not Available <br>
                    </strong></font></td>
          </tr>
          <tr> 
                  <td height="41" valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong><br>
                    Product Units</strong></font></td>
                  <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <br>
                    <input name="unit" type="text" id="unit">
                    (pcs/copies) </strong></font></td>
          </tr>
		  <tr> 
            <td><input name="entDate" type="hidden" value="<?php echo date('Y-m-d');?>"></td>
            <td><input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
          </tr>
          <tr> 
            <td></br></td>
            <td></br></td>
          </tr>
          <tr> 
            <td></br></td>
            <td></br></td>
          </tr>
          <tr> 
            <td align="center"><input name="submit" type="submit" value="Submit"><br>
<br>
</td>
            <td align="center"><input name="" type="reset" value="Reset"><br>
<br>
</td>
          </tr>
        </table>
</form></td>
  </tr></table>
	
	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
