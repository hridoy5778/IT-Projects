<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$serial = $_POST['serial'];
$name = $_POST['name'];
$mac = $_POST['mac'];
$ip = $_POST['ip'];
$location = $_POST['location'];
$entDateF = $_POST['entDateF'];
$entDateT = $_POST['entDateT'];

if($entDateF == "")
{
$entDateF="%";
}
if($entDateT == "")
{
$entDateT=date('Y-m-d');
}

if($serial == "")
{
$serial="%";
}
if($location == "")
{
$location="%";
}
if($name == "")
{
$name="%";
}
if($mac == "")
{
$mac="%";
}
if($ip == "")
{
$ip="%";
}


$serialR = $serial;
$nameR = $name;
$macR = $mac;
$ipR = $ip;
$locationR = $location;
$entDateFR = $entDateF;
$entDateTR = $entDateT;
//echo $serial;
//echo $type;
//echo $entDateF;
//echo $entDateT;
//echo $location;
$query = "SELECT * FROM ebshardware where  serial like '$serial' and name like '%$name%' and mac like '$mac' and ip like '%$ip%' and location like '$location'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 
?>
<html>
<head>

<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
</head>

<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
	
      <table width="189%" border="3" cellspacing="2">
	  <tr bgcolor="#CCCCCC">
          <td height="36" colspan="8" bgcolor="#00CCFF">
<div align="center"><font color="#FF0000"><strong><em>Reports for EBS--Hardware--- <a href="report/ebsHardware.php?<?php echo 'serialR='.$serialR;?>&amp;<?php echo 'nameR='.$nameR;?>&amp;<?php echo 'macR='.$macR;?>&amp;<?php echo 'entDateFR='.$entDateFR;?>&amp;<?php echo 'entDateTR='.$entDateTR;?>&amp;<?php echo 'ipR='.$ipR;?>&amp;<?php echo 'locationR='.$locationR;?>" target="_blank">Export report</a> </em></strong></font></div></td>
          </td>
    </tr>
        <tr bgcolor="#CCCCCC">
    <td width="7%"><font color="#000000"><strong>No</strong></font></td><td width="14%"><font color="#000000"><strong>Hardware Serial</strong></font></td><td width="14%"><font color="#000000"><strong>Hardware Name</strong></font></td><td width="10%"><font color="#000000"><strong>Description</strong></font></td><td width="12%"><font color="#000000"><strong>MAC</strong></font></td><td width="12%"><font color="#000000"><strong>IP</strong></font></td><td width="18%"><font color="#000000"><strong>Location</strong></font></td><td width="13%"><font color="#000000"><strong>Entry Date</strong></font></td>
    </tr>
  
</table>
	
	<?php 

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$serial = mysql_result($result,$i,"serial");
$name = mysql_result($result,$i,"name");
$mac = mysql_result($result,$i,"mac");
$ip = mysql_result($result,$i,"ip");
$description = mysql_result($result,$i,"description");
$location = mysql_result($result,$i,"location");
$entDate = mysql_result($result,$i,"entDate");

?> 

      <table width="189%" border="4" cellspacing="2">
        <tr bgcolor="<?php echo $rColor; ?>"> 
          <td width="7%"><p><font color="#000000" size="2"><?php echo $i+1; ?></font></p></td>
          <td width="14%"><p><font color="#000000" size="2"><?php echo $serial;?></font></p></td>
          <td width="14%"><p><font color="#000000" size="2"><?php echo $name;?></font></p></td>
          <td width="10%"><p><font color="#000000" size="2"><?php echo $description;?></font></p></td>
          <td width="13%"><p><font color="#000000" size="2"><?php echo $mac;?></font></p></td>
          <td width="15%"><p><font color="#000000" size="2"><?php echo $ip;?></font></p></td>
          
          <td width="14%"><p><font color="#000000" size="2"><?php echo $location;?></font></p></td>
          <td width="13%"><p><font color="#000000" size="2"><?php echo $entDate;?></font></p></td>
		 
        </tr>
      </table>






<?php

$i++; 



}

?>

 </div>
 
    <div class="clear"></div>
	 </div>
  <div id="footer"><?php include_once('footer.php');?></div>
  
</div>

</body>
</html>
