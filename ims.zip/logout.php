<?php 
$username = $_SESSION['login'];
include_once('config.php');
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query2 = "update admin set status = 'a' where username = '$username'";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
echo $num2;
mysql_close();
?>