<?php
echo "IT Inventory System, Brac Bank Limited";
?>