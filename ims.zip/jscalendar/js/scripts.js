function filemgm(){
  if(document.getElementById('filemgm').style.display == 'none'){
  document.getElementById('filemgm').style.display = '';
  }else if(document.getElementById('filemgm').style.display == ''){
  document.getElementById('filemgm').style.display = 'none';
  }
}
function visamgm(){
  if(document.getElementById('visamgm').style.display == 'none'){
  document.getElementById('visamgm').style.display = '';
  }else if(document.getElementById('visamgm').style.display == ''){
  document.getElementById('visamgm').style.display = 'none';
  }
}

function pspmgm(){
  if(document.getElementById('pspmgm').style.display == 'none'){
  document.getElementById('pspmgm').style.display = '';
  }else if(document.getElementById('pspmgm').style.display == ''){
  document.getElementById('pspmgm').style.display = 'none';
  }
}

function statusmgm(){
  if(document.getElementById('statusmgm').style.display == 'none'){
  document.getElementById('statusmgm').style.display = '';
  }else if(document.getElementById('statusmgm').style.display == ''){
  document.getElementById('statusmgm').style.display = 'none';
  }
}
function pstatusmgm(){
  if(document.getElementById('pstatusmgm').style.display == 'none'){
  document.getElementById('pstatusmgm').style.display = '';
  }else if(document.getElementById('pstatusmgm').style.display == ''){
  document.getElementById('pstatusmgm').style.display = 'none';
  }
}

function jobmgm(){
  if(document.getElementById('jobmgm').style.display == 'none'){
  document.getElementById('jobmgm').style.display = '';
  }else if(document.getElementById('jobmgm').style.display == ''){
  document.getElementById('jobmgm').style.display = 'none';
  }
  }
  
  function jobmgm2(){
  if(document.getElementById('jobmgm2').style.display == 'none'){
  document.getElementById('jobmgm2').style.display = '';
  }else if(document.getElementById('jobmgm2').style.display == ''){
  document.getElementById('jobmgm2').style.display = 'none';
  }
  }
  
