<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$id = $_REQUEST['id'];
$query = "select * from laptop where id = '$id'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$i=0;
$name = mysql_result($result,$i,"name");
$lanId = mysql_result($result,$i,"lanId");
$deptPost = mysql_result($result,$i,"deptPost");
$brand = mysql_result($result,$i,"brand");
$ip = mysql_result($result,$i,"ip");
$hostName = mysql_result($result,$i,"hostName");
$location = mysql_result($result,$i,"location");
$model = mysql_result($result,$i,"model");
$machineType = mysql_result($result,$i,"machineType");
$serial = mysql_result($result,$i,"serial");
$tag = mysql_result($result,$i,"tag");
$cpu = mysql_result($result,$i,"cpu");
$ram = mysql_result($result,$i,"ram");
$hdd = mysql_result($result,$i,"hdd");
$status = mysql_result($result,$i,"status");
$os = mysql_result($result,$i,"os");
$sophos = mysql_result($result,$i,"sophos");

$entDate = mysql_result($result,$i,"entDate");

//echo $num;
mysql_close(); 
?>
</head>

<body>
<table width="60%" border="3">
  <tr bgcolor="#3399FF"> 
    <td colspan="2"><div align="center"><strong><font size="5"><em>Details Laptop 
        Information</em></font></strong></div></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td width="47%" bgcolor="#0099FF">Laptop User Name</td>
    <td width="53%"><?php echo $name;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Lan ID</td>
    <td><?php echo $lanId;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Department & Designation</td>
    <td><?php echo $deptPost;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Laptop Brand </td>
    <td><?php echo $brand;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">IP Address</td>
    <td bgcolor="#00CCFF"><?php echo $ip;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Host Name</td>
    <td><?php echo $hostName;?></td>
  </tr>
  <tr bgcolor="#00CCFF"> 
    <td bgcolor="#0099FF">Location</td>
    <td><?php echo $location;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Model</td>
    <td><?php echo $model;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Machine Type</td>
    <td bgcolor="#0099FF"><?php echo $machineType;?></td>
  </tr>
  
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">CPU Serial</td>
    <td><?php echo $serial;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">CPU Tag</td>
    <td><?php echo $tag;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Processor</td>
    <td><?php echo $cpu;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">RAM</td>
    <td><?php echo $ram;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Hard Disk</td>
    <td><?php echo $hdd;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Laptop Status</td>
    <td><?php echo $status;?></td>
  </tr>
  <tr bgcolor="#0099FF"> 
    <td bgcolor="#00CCFF">Operating System</td>
    <td><?php echo $os;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td>Sophos Installed</td>
    <td bgcolor="#66FFCC"><?php echo $sophos;?></td>
  </tr>
  <tr bgcolor="#33FFFF"> 
    <td>Entry Date</td>
    <td bgcolor="#66FFCC"><?php echo $entDate;?></td>
  </tr>
  
  
</table>

</body>
</html>
