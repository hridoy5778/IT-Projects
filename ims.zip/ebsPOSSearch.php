<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/template.css" type="text/css" />
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT distinct(posType) FROM ebspos order by posType";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query2 = "SELECT distinct(model) FROM ebspos order by model";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);
$query3 = "SELECT distinct(vendor) FROM ebspos order by vendor";
$result3 = mysql_query($query3);
$num3 = mysql_num_rows($result3);
//$query4 = "SELECT distinct(city) FROM ebsatm order by city";
//$result4 = mysql_query($query4);
//$num4 = mysql_num_rows($result4);

//$query5 = "SELECT distinct(location) FROM ebsatm order by location";
//$result5 = mysql_query($query5);
//$num5 = mysql_num_rows($result5);

//$query6 = "SELECT distinct(slaStatus) FROM ebsups order by slaStatus";
//$result6 = mysql_query($query6);
//$num6 = mysql_num_rows($result6);

mysql_close();
?>

</head>


<body>
<div align="right"><strong><font color="#000000" size="3" face="Arial, Helvetica, sans-serif">Welcome</font><font color="#000000" size="4" face="Arial, Helvetica, sans-serif">&nbsp;</font><font size="4" face="Arial, Helvetica, sans-serif">&nbsp;<font color="#000000"><?php echo $username;?></font>&nbsp;&nbsp;<a href="index.php" target="_self"><font color="#333333">Logout</font></a></font></strong></div>

<br>
<div id="wrap">
  <div align="center"><?php include_once('banner.php');?></div>
  <div id="menu"><?php include_once('menu.php');?><br>
</div>
  <div id="container">
    
    <div id="contentCol">
<table width="130%" height="395" border="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
        <tr>
          <td height="391" align="center" valign="top"> 
            <form action="ebsPOSSearchSQL.php" method="post" target="_self" enctype="multipart/form-data">
              <table width="110%" border="0">
                <tr bgcolor="#0066FF"> 
                  <td colspan="2"> <div align="center"><br>
                      <strong><font color="#FFFFFF" size="4">COMPONENTS SEARCH(EBS---POS)</font></strong><br>
                    </div></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td width="37%"><br></td>
                  <td width="63%"><br></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="43" valign="top"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>POS 
                      TID</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="posTid" type="text" size="30">
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="43" valign="top"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>POS 
                      MID</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="posMid" type="text" size="30">
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="43" valign="top"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Merchant 
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <input name="merchantName" type="text" size="30">
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="43" valign="top"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Location 
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <textarea name="location" cols="30" rows="6" wrap="VIRTUAL"></textarea>
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="45" valign="top"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>POS 
                      Type</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="posType">
                      <option>Select POS Type</option>
                      <?php
	   $i=0;
while ($i < $num) 
{
$posType = mysql_result($result,$i,"posType");
echo "<option>";
echo $posType;
echo "</option>" ; 
$i++;
}
?>">
                      
                    </select>
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="45" valign="top"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Brand 
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="model">
                      <option>Select Model</option>
                      <?php
	   $i2=0;
while ($i2 < $num2) 
{
$model = mysql_result($result2,$i2,"model");
echo "<option>";
echo $model;
echo "</option>" ; 
$i2++;
}
?>">
                      
                    </select>
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="45" valign="top"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Model 
                      Name</strong></font></div></td>
                  <td valign="top"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="vendor">
                      <option>Select Vendor</option>
                      <?php
	   $i3=0;
while ($i3 < $num3) 
{
$vendor = mysql_result($result3,$i3,"vendor");
echo "<option>";
echo $vendor;
echo "</option>" ; 
$i3++;
}
?>">
                      
                    </select>
                    <br>
                    </strong></font></td>
                </tr>
                <tr> 
                  <td height="45" valign="top" bgcolor="#CCCCCC"> <div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Performance 
                      Status</strong></font></div></td>
                  <td valign="top" bgcolor="#CCCCCC"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                    <select name="performance">
                      <option>Not defined</option>
                      <option>Excellent </option>
                      <option>Moderate</option>
                      <option>Poor</option>
                    </select>
                    <br>
                    </strong></font></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="42" valign="top"> <div align="center"><font color="#000000"><strong>Received 
                      Date&nbsp;(yyyy-mm-dd)</strong></font></div></td>
                  <td valign="top"> <div align="left"><font color="#000000"><strong><em>From:</em></strong></font>&nbsp; 
                      <input name="receivedDateF" type="text" size="10" id="receivedDateF" readonly="true">
                      <img src="images/search_calendar.png" id="calRECVf"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /> &nbsp; <font color="#000000"><strong><em>To:</em></strong></font><em><strong>&nbsp;</strong></em> 
                      <input name="receivedDateT" type="text" size="10" id="receivedDateT" readonly="true">
                      <img src="images/search_calendar.png" id="calRECVt"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></div></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td height="42" valign="top"> <div align="center"><font color="#000000"><strong>Installation 
                      Date&nbsp;(yyyy-mm-dd)</strong></font></div></td>
                  <td valign="top"> <div align="left"><font color="#000000"><strong><em>From:</em></strong></font>&nbsp; 
                      <input name="installDateF" type="text" size="10" id="installDateF" readonly="true">
                      <img src="images/search_calendar.png" id="calF"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /> &nbsp; <font color="#000000"><strong><em>To:</em></strong></font><em><strong>&nbsp;</strong></em> 
                      <input name="installDateT" type="text" size="10" id="installDateT" readonly="true">
                      <img src="images/search_calendar.png" id="calT"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></div></td>
                </tr>
                <tr bgcolor="#CCCCCC">
                  <td>&nbsp;</td>
                  <td><div align="left"><font color="#000000" face="Arial, Helvetica, sans-serif"><strong> 
                     
                      <input name="nullCHK" type="checkbox" value="" checked>
                      <font color="#FF0000">Include Null Dates</font> </strong></font></div></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td> <div align="center"> 
                      <input name="enterDate" type="hidden" value="<?php echo date('Y-m-d');?>">
                    </div></td>
                  <td> <input name="enterPerson" type="hidden" value="<?php echo $username;?>"></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td></br> <div align="center"></div></td>
                  <td></br></td>
                </tr>
                <tr bgcolor="#CCCCCC"> 
                  <td></br> <input name="submit" type="submit" value="SEARCH"> 
                    <div align="center"></div></td>
                  <td></br> <input name="Input" type="reset" value="Reset"></td>
                </tr>
              </table>
</form>

</td>
  </tr></table>
	<script type="text/javascript">
Calendar.setup({
inputField : "receivedDateF",
ifFormat : "%Y-%m-%d",
button : "calRECVf",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "receivedDateT",
ifFormat : "%Y-%m-%d",
button : "calRECVt",
align : "T1",
singleClick : true
});
</script>


<script type="text/javascript">
Calendar.setup({
inputField : "installDateF",
ifFormat : "%Y-%m-%d",
button : "calF",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "installDateT",
ifFormat : "%Y-%m-%d",
button : "calT",
align : "T1",
singleClick : true
});
</script>

	</div>
    
    <div class="clear">
      <p>&nbsp;</p>
    </div>
  </div>
  
  
</div>
<div id="footer"><?php include_once('footer.php');?></div>
</body>
</html>
