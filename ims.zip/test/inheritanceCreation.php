<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php
include_once('mainClass.php');
class Another extends Something { 
var $y; 
function setY($v) { 
// Methods start in lowercase then use uppercase initials to 
// separate words in the method name example getValueOfArea() 
$this->y=$v; 
} 

function getY() { 
return $this->y; 

}
} 

$obj2=new Another; 
$obj2->setX(6); 
$obj2->setY(7); 

$seeX2=$obj2->getX(); 
echo $seeX2;
echo "<br>";

$seeY2=$obj2->getY(); 
echo $seeY2;


?>
</body>
</html>
