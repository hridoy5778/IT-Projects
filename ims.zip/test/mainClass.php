<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 

class Something { 
// In OOP classes are usually named starting with a cap letter. 
var $x; 

function setX($v) { 
// Methods start in lowercase then use lowercase to separate 
// words in the method name example getValueOfArea() 
$this->x=$v+10; 

} 

function getX() { 
return $this->x; 
}


 
} 

?> 

</body>
</html>
