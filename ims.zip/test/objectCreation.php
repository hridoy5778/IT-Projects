<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include_once('mainClass.php');
$obj=new Something; 
//Then you can use member functions like: 
$obj->setX(20); 
$see=$obj->getX(); 
echo $see;
echo "<br>";
$obj2=new Something; 
//Then you can use member functions like: 
$obj2->setX(40); 
$see2=$obj2->getX(); 
echo $see2;

?>
</body>
</html>
