<?php 
$db = "compliance2018";			// Database Name 
$dbhost = "localhost";		// Database Host
$dbuser = root;		// Database Username
$dbpass = "";		// Database Password
?>