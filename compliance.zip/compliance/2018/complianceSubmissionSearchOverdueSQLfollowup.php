<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$brn = $_POST['brn'];
$type = $_POST['type'];

//echo $brn;

if($brn == "1")
{
$brn="1";
}
$Dadd = $brn;
$today=date('Y-m-d');



$temp = date('Y-m-d', strtotime($today. ' + '.$Dadd. 'days'));





//echo $today;

//echo $brn;echo $brn;echo $brn;


//echo $temp;



$query = "SELECT * FROM brcom where cD ='$temp' and type = '$type'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
//echo $num;
mysql_close(); 

?>

<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center">
Overdue Compliance Submissions report after due date (Branch Wise)<br>

<?php 
	if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}
?>
</td>
  </tr>
  <tr> 
  <td colspan="6" align="left">
  <table width="100%" align="left">
        <tr> 
         <td width="5%" bgcolor="#CCCCCC">Serial</td>
          <td width="15%" bgcolor="#CCCCCC">Audit Type</td>
          <td width="15%" bgcolor="#CCCCCC">Branch Name</td>
          <td width="15%" bgcolor="#CCCCCC">Compliance Sequence</td>
          <td width="15%" bgcolor="#CCCCCC">Submission Due Date</td>
          <td width="15%" bgcolor="#CCCCCC">Submission Date</td>
           
         
  </tr>
  </table></td></tr>
  
<?php

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}
$sL = $i+1;
$type = mysql_result($result,$i,"type");
$brn = mysql_result($result,$i,"brn");
$compSeq = mysql_result($result,$i,"compSeq");
$cD = mysql_result($result,$i,"cD");
$cS = mysql_result($result,$i,"cS");

?> 
<tr><td width="100%">



</td></tr>
      <table border="0" cellspacing="3" width="100%">
        <tr bgcolor="<?php echo $rColor; ?>">
        <td width="5%"><font color="#000000"><?php echo $sL;?></font></td>
 <td width="15%"><font color="#000000"><?php echo $type;?></font></td>
          <td width="15%"><font color="#000000"><?php echo $brn;?></font></td>
          
		  <td width="15%"><font color="#000000"><?php echo $compSeq;?></font></td>
		  <td width="15%"><strong><font color="#000000"><?php echo substr($cD,8,9).'-'.substr($cD,5,3).substr($cD,0,4);?></font></strong></td>
          <td width="15%"><font color="#000000"><?php echo $cS;?></font></td>
          
          
    
  </tr>
  
</table>






<?php

$i++; 



}

?>  
  
  
  
  
</table>
</body>
</html>
