<?php 
$db = "compliance2019";			// Database Name 
$dbhost = "localhost";		// Database Host
$dbuser = root;		// Database Username
$dbpass = "";		// Database Password
?>