<html>
<head>

<title><?php include_once('header.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$type = $_POST['type'];


$brn = $_POST['brn'];

$compSeq = $_POST['compSeq'];

$cD = $_POST['cD'];
$cS = $_POST['cS'];
$rD = $_POST['rD'];
$CrD = $_POST['CrD'];
$aBd = $_POST['aBd'];
$grade = $_POST['grade'];
$bbRate = $_POST['bbRate'];
$nAudit = $_POST['nAudit'];

//echo $type;
//echo $brn;
//echo $compSeq;

$querySearch = "SELECT * FROM `brcom` WHERE type = '$type' and brn = '$brn' and compSeq = '$compSeq'";
//$querySearch = "SELECT out FROM brreport WHERE out='$out'";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num >0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Compliance Information already entered .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter new Compliance records</strong></font><br>
<br>
<br>
<a href="complianceSeqEntry.php" target="_parent">Bact to Compliance Record Entry (Branch) Page</a>');
exit();
}
//$name = $type." on ".$brn;
$query = "INSERT INTO brcom VALUES ('','$type','$brn','$compSeq','$cD','$cS','','$rD','$aBd','$grade','$bbRate','$nAudit','$CrD','br')";
mysql_query($query);

mysql_close();

//move_uploaded_file($_FILES["inv"]["tmp_name"],"report/branch/summary/".$_FILES["inv"]["name"]);
      //echo "Stored in: " . "image/" . $_FILES["cv"]["name"];
      
      //echo "file has been uploaded"."<br/>"."<br/>";
	  //$tmp = $_FILES["cv"]["name"];
	  //echo $tmp;
?> 
<h3>Compliance Record has been entered......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="complianceSeqEntry.php" target="_parent">Bact to Compliance Record Entry (Branch) Page</a> </div>
</body>
</html>













<body>

</body>
</html>
