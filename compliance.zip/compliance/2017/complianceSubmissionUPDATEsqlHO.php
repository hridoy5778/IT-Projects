<html>
<head>

<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brn = $_POST['brn'];
$type = $_POST['type'];
$compSeq = $_POST['compSeq'];
$cD = $_POST['cD'];
$cS = $_POST['cS'];

//$diff=0;





//$date1=date_create($cS);
//$date2=date_create($cD);
//$diff=dateDifference($cS,$cD);

//$diff=date_diff($cS,$cD);




//echo $inv;
//echo $out;

$querySearch = "UPDATE brcom SET cS='$cS', delay=DATEDIFF('$cS','$cD')
WHERE brn='$brn' and type='$type' and compSeq='$compSeq'";

//$querySearch = "SELECT out FROM brreport WHERE out='$out'";
$result = mysql_query($querySearch);
//$num = mysql_num_rows($result);


mysql_close();


?> 
<h3>Compliance Records have been updated......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="complianceSubmissionEntryHO.php" target="_parent">Bact to Compliance Records Update (Division) Page</a> </div>
</body>
</html>













