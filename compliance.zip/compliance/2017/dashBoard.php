<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$today=date('Y-m-d');




//echo $num;
//mysql_close(); 

?>

<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
@import url(./jscalendar/calendar-win2k-1.css);.c {color: #808080;}
.ddc {
	color: #0F0;
}
.ddc strong {
	color: #008000;
}
.bb {
	color: #0080C0;
}
.cx {
	color: #00F;
}
</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
</head>

<body>
<table width="100%" border="0"> <!--main frame start -->
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center" bgcolor="#FF0000">
      <h1><strong class="c">ICCD Compliance Dash Board</strong><br></h1>
    <h3><strong class="cx">AS ON <span class="cx"><?php echo substr($today,8,9).'-'.substr($today,5,3).substr($today,0,4);?></span></strong><br></h3></td>
  </tr>
 <tr>
   <td width="100"> <!--container start (Column) -->
  <table width="100%" border="10">  <!--container start (table) -->
  
  
   <tr> <!--container start (row) -->
  <td width="20%" bgcolor="#CCCCCC"> 
  
  <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Audited Branches</strong></div></td>
    </tr>
  <tr>
    <td width="50%" ><div align="center"><strong>RBIA</strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php 
	$query = "SELECT COUNT(DISTINCT (brn)) AS rac FROM audit WHERE type='RBIA' AND flag='br'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"rac"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>ISS</strong></div></td>
    <td width="50%"><div align="center"><strong><?php 
	$query = "SELECT COUNT(DISTINCT (brn)) AS iac FROM audit WHERE type='ISS' AND flag='br'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"iac"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>
<!--Un Audited start -->

 <td width="20%" bgcolor="#CCCCCC"> 
  
  <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Un-Audited Branches</strong></div></td>
    </tr>
  <tr>
    <td width="50%"><div align="center"><strong>RBIA</strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php 
	$query = "SELECT COUNT(DISTINCT (name)) AS a FROM branch WHERE name NOT IN (SELECT brn FROM audit WHERE type = 'RBIA')";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>ISS</strong></div></td>
    <td width="50%"><div align="center"><strong><?php 
	$query = "SELECT COUNT(DISTINCT (name)) AS a FROM branch WHERE name NOT IN (SELECT brn FROM audit WHERE type = 'ISS')";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>


<!--Un audited end -->
<td width="20%" bgcolor="#CCCCCC">
 <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Report Sending Status</strong></div></td>
    </tr>
  <tr>
   <td width="50%"><div align="center"><strong>RBIA</strong></div></td>
    <td width="50%"><div align="center"><strong><?php 
	$query = "SELECT COUNT(DISTINCT (brn)) AS a FROM brcom WHERE type='RBIA'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>ISS</strong></div></td>
    <td width="50%"><div align="center"><strong><?php 
	$query = "SELECT COUNT(DISTINCT (brn)) AS a FROM brcom
WHERE type='ISS'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>
<td width="20%" bgcolor="#CCCCCC">
 <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Compliance Received Status</strong></div></td>
    </tr>
 <tr>
   <td width="50%"><div align="center"><strong>RBIA</strong></div></td>
    <td width="50%"><div align="center"><strong><?php 
	$query = "SELECT COUNT(DISTINCT (brn)) AS a FROM brcom
WHERE type='RBIA' AND cS NOT LIKE '0000-00-00'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
   <td width="50%"><div align="center"><strong>ISS</strong></div></td>
    <td width="50%"><div align="center"><strong><?php 
	$query = "SELECT COUNT(DISTINCT (brn)) AS a FROM brcom
WHERE type='ISS' AND cS NOT LIKE '0000-00-00'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>
<td width="20%" bgcolor="#CCCCCC">
 <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Compliance Overdue Status</strong></div></td>
    </tr>
 <tr>
   <td width="50%"><div align="center"><strong>RBIA</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT COUNT(DISTINCT(brn)) AS a FROM brcom where type = 'RBIA' and cD <='$today' and cS ='0000-00-00'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
   <td width="50%"><div align="center"><strong>ISS</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT COUNT(DISTINCT(brn)) AS a FROM brcom where type = 'ISS' and cD <='$today' and cS ='0000-00-00'
";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>
</tr>  <!--1st Row of container end -->
</table> <!--container end (table) -->

<!--2nd ROW start with New table -->
<table width="100%">
<tr>


  <td width="25%" bgcolor="#FFFFFF"z> 
  
  <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>General Banking Risk</strong></div></td>
    </tr>
  <tr>
    <td width="50%"><div align="center"><strong>HIGH</strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(highRiskObs) AS a FROM observations WHERE auditArea = 'General Banking'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>MEDIUM</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(MediumRiskObs) AS a FROM observations WHERE auditArea = 'General Banking'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>LOW</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(LowRiskObs) AS a FROM observations WHERE auditArea = 'General Banking'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>
<td width="25%" bgcolor="#FFFFFF">
 <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Credit Risk</strong></div></td>
    </tr>
   <tr>
    <td width="50%"><div align="center"><strong>HIGH</strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(highRiskObs) AS a FROM observations WHERE auditArea = 'Credit Risk'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>MEDIUM</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(MediumRiskObs) AS a FROM observations WHERE auditArea = 'Credit Risk'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>LOW</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(LowRiskObs) AS a FROM observations WHERE auditArea = 'Credit Risk'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>
<td width="25%" bgcolor="#FFFFFF">
 <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Trade Finance Risk</strong></div></td>
    </tr>
 <tr>
    <td width="50%"><div align="center"><strong>HIGH</strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(highRiskObs) AS a FROM observations WHERE auditArea = 'Trade Finance'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>MEDIUM</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(MediumRiskObs) AS a FROM observations WHERE auditArea = 'Trade Finance'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>LOW</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(LowRiskObs) AS a FROM observations WHERE auditArea = 'Trade Finance'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>
<td width="25%" bgcolor="#FFFFFF">
 <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>Information Systems Risk</strong></div></td>
    </tr>
   <tr>
    <td width="50%"><div align="center"><strong>HIGH</strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(highRiskObs) AS a FROM observations WHERE auditArea = 'Information Systems'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>MEDIUM</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(MediumRiskObs) AS a FROM observations WHERE auditArea = 'Information Systems'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
  <tr>
    <td width="50%"><div align="center"><strong>LOW</strong></div></td>
    <td width="50%"><div align="center"><strong><?php
$today=date('Y-m-d'); 
	$query = "SELECT SUM(LowRiskObs) AS a FROM observations WHERE auditArea = 'Information Systems'";

$result = mysql_query($query);
$num = mysql_num_rows($result); $i=0;$data =  mysql_result($result,$i,"a"); echo $data;?></strong></div></td>
  </tr>
</table>
</td>



</tr>
</table> <!--2nd ROW end with New table -->

<table width="100%"> <!--3rd ROW start with New table -->

<tr>

<td width="25%" bgcolor="#CCCCCC"> 
  
  <table width="100%" border="25" cellspacing="5" bordercolor="#FF0000" bgcolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>TOP 10 HIGH Risks Branches</strong></div></td>
    </tr>
    <tr>
    <td width="50%"><div align="center"><strong>Branch Name</strong></div></td>
    <td width="50%"><div align="center"><strong>Un-rectified Observations</strong></strong></div></td>
  </tr>
  <?php 
  
 $today=date('Y-m-d'); 
	$query = "SELECT brName, SUM( totalObservations ) AS a
FROM observations
GROUP BY brName
ORDER BY SUM(totalObservations) DESC LIMIT 10";

$result = mysql_query($query);
$num = mysql_num_rows($result);

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$brn = mysql_result($result,$i,"brName");
$a = mysql_result($result,$i,"a");

?> 
  <tr>
    <td width="50%"><div align="center"><strong><?php echo $brn?></strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php echo $a;?></strong></div></td>
  </tr>
  <?php 
  $i++; 
}?>
</table>
</td>



<td width="25%" bgcolor="#CCCCCC"> 
  
  <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>TOP 10 GB Risks Branches</strong></div></td>
    </tr>
    <tr>
    <td width="50%"><div align="center"><strong>Branch Name</strong></div></td>
    <td width="50%"><div align="center"><strong>Un-rectified Observations</strong></div></td>
  </tr>
  <?php 
  
 $today=date('Y-m-d'); 
	$query = "SELECT brName, auditArea,SUM( totalObservations ) AS a
FROM observations
WHERE auditArea = 'General Banking' GROUP BY brName
ORDER BY SUM(totalObservations) DESC LIMIT 10";

$result = mysql_query($query);
$num = mysql_num_rows($result);

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$brn = mysql_result($result,$i,"brName");
$a = mysql_result($result,$i,"a");

?> 
  <tr>
    <td width="50%"><div align="center"><strong><?php echo $brn?></strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php echo $a;?></strong></div></td>
  </tr>
  <?php 
  $i++; 
}?>
</table>
</td>

<td width="25%" bgcolor="#CCCCCC"> 
  
  <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>TOP 10 Credit Risks Branches</strong></div></td>
    </tr>
    <tr>
    <td width="50%"><div align="center"><strong>Branch Name</strong></div></td>
    <td width="50%"><div align="center"><strong>Un-rectified Observations</strong></strong></div></td>
  </tr>
  <?php 
  
 $today=date('Y-m-d'); 
	$query = "SELECT brName, auditArea,SUM( totalObservations ) AS a
FROM observations
WHERE auditArea = 'Credit Risk' GROUP BY brName
ORDER BY SUM(totalObservations) DESC LIMIT 10";

$result = mysql_query($query);
$num = mysql_num_rows($result);

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$brn = mysql_result($result,$i,"brName");
$a = mysql_result($result,$i,"a");

?> 
  <tr>
    <td width="50%"><div align="center"><strong><?php echo $brn?></strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php echo $a;?></strong></div></td>
  </tr>
  <?php 
  $i++; 
}?>
</table>
</td>


<td width="25%" bgcolor="#CCCCCC"> 
  
  <table width="100%" border="10" cellspacing="5" bordercolor="#FF0000">
  <tr>
    <td colspan="2" class="ddc"><div align="center"><strong>TOP 10 Trade Finance Risks Branches</strong></div></td>
    </tr>
    <tr>
    <td width="50%"><div align="center"><strong>Branch Name</strong></div></td>
    <td width="50%"><div align="center"><strong>Un-rectified Observations</strong></strong></div></td>
  </tr>
  <?php 
  
 $today=date('Y-m-d'); 
	$query = "SELECT brName, auditArea,SUM( totalObservations ) AS a
FROM observations
WHERE auditArea = 'Trade Finance' GROUP BY brName
ORDER BY SUM(totalObservations) DESC LIMIT 10";

$result = mysql_query($query);
$num = mysql_num_rows($result);

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$brn = mysql_result($result,$i,"brName");
$a = mysql_result($result,$i,"a");

?> 
  <tr>
    <td width="50%"><div align="center"><strong><?php echo $brn?></strong></div></td>
    <td width="50%"><div align="center"><strong></strong><?php echo $a;?></strong></div></td>
  </tr>
  <?php 
  $i++; 
}?>
</table>
</td>





</tr>

</table> <!--3rd ROW end with New table -->













































































































  </tr></td><!--container end (Column) -->
  </table>  <!--main frame end -->
</body>
</html>
