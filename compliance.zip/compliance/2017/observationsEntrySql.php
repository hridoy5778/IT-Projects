<html>
<head>

<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brn = $_POST['brn'];
//$aua = $_POST['aua'];
$gb = $_POST['gb'];
$cr = $_POST['cr'];
$tf = $_POST['tf'];


$GBhro = $_POST['GBhro'];
$CRhro = $_POST['CRhro'];
$TFhro = $_POST['TFhro'];

$GBmro = $_POST['GBmro'];
$CRmro = $_POST['CRmro'];
$TFmro = $_POST['TFmro'];


$GBlro = $_POST['GBlro'];
$CRlro = $_POST['CRlro'];
$TFlro = $_POST['TFlro'];


$ria = $_POST['ria'];



$sGB = $GBhro + $GBmro + $GBlro;
$sCR = $CRhro + $CRmro + $CRlro;
$sTF = $TFhro + $TFmro + $TFlro;
$tooGB = $sGB;
$tooCR = $sCR;
$tooTF = $sTF;



//echo $inv;
//echo $out;

$querySearch = "SELECT * FROM `observations` WHERE brName = '$brn' and riskArea = 'RBIA'";

//$querySearch = "SELECT out FROM brreport WHERE out='$out'";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num >0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Observations Information already entered .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter new Observations Information</strong></font><br>
<br>
<br>
<a href="observationEntry.php" target="_parent">Bact to Audit Observations Entry (Branch) Page</a>');
exit();
}
//$name = $type." on ".$brn;
$query1 = "INSERT INTO observations VALUES ('$brn','$gb','RBIA','$GBhro','$GBmro','$GBlro','$tooGB')";
mysql_query($query1);
$query2 = "INSERT INTO observations VALUES ('$brn','$cr','RBIA','$CRhro','$CRmro','$CRlro','$tooCR')";
mysql_query($query2);
$query3 = "INSERT INTO observations VALUES ('$brn','$tf','RBIA','$TFhro','$TFmro','$TFlro','$tooTF')";
mysql_query($query3);


$query7 = "INSERT INTO temp VALUES ('$brn','RBIA','$gb','HIGH','$GBhro')";                                       
mysql_query($query7);
$query77 = "INSERT INTO temp VALUES ('$brn','RBIA','$cr','HIGH','$CRhro')"; 
mysql_query($query77);
$query777 = "INSERT INTO temp VALUES ('$brn','RBIA','$tf','HIGH','$TFhro')"; 
mysql_query($query777);


$query8 = "INSERT INTO temp VALUES ('$brn','RBIA','$gb','MEDIUM','$GBmro')";                                       
mysql_query($query8);
$query88 = "INSERT INTO temp VALUES ('$brn','RBIA','$cr','MEDIUM','$CRmro')";                                        
mysql_query($query88);
$query888 = "INSERT INTO temp VALUES ('$brn','RBIA','$tf','MEDIUM','$TFmro')";                                        
mysql_query($query88);

$query9 = "INSERT INTO temp VALUES ('$brn','RBIA','$gb','LOW','$GBlro')";                                        
mysql_query($query9);
$query99 = "INSERT INTO temp VALUES ('$brn','RBIA','$cr','LOW','$CRlro')";                                        
mysql_query($query99);
$query999 = "INSERT INTO temp VALUES ('$brn','RBIA','$tf','LOW','$TFlro')";                                        
mysql_query($query999);










$entDateT=date('Y-m-d');
$query4 = "INSERT INTO observationsbase VALUES ('$brn','$gb','RBIA','$GBhro','$GBmro','$GBlro','$tooGB','$entDateT')";
mysql_query($query4);
$query5 = "INSERT INTO observationsbase VALUES ('$brn','$cr','RBIA','$CRhro','$CRmro','$CRlro','$tooCR','$entDateT')";
mysql_query($query5);
$query6 = "INSERT INTO observationsbase VALUES ('$brn','$tf','RBIA','$TFhro','$TFmro','$TFlro','$tooTF','$entDateT')";
mysql_query($query6);
mysql_close();

//move_uploaded_file($_FILES["inv"]["tmp_name"],"report/branch/summary/".$_FILES["inv"]["name"]);
      //echo "Stored in: " . "image/" . $_FILES["cv"]["name"];
      
      //echo "file has been uploaded"."<br/>"."<br/>";
	  //$tmp = $_FILES["cv"]["name"];
	  //echo $tmp;
?> 
<h3>Observations Information have been entered......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="observationEntry.php" target="_parent">Bact to Observations Record Entry (Branch) Page</a> </div>
</body>
</html>













<body>

</body>
</html>
