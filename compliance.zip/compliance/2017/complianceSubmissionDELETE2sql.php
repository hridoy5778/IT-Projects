<html>
<head>

<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brnPrev = $_POST['brnPrev'];
$brn = $_POST['brn'];
$type = $_POST['type'];
$compSeq = $_POST['compSeq'];
$cD = $_POST['cD'];
$cS = $_POST['cS'];
$rD = $_POST['rD'];
$CrD = $_POST['CrD'];
$aBd = $_POST['aBd'];
$nAudit = $_POST['nAudit'];
$grade = $_POST['grade'];

//echo $nAudit;
//$diff=0;

//echo $CrD;



//$date1=date_create($cS);
//$date2=date_create($cD);
//$diff=dateDifference($cS,$cD);

//$diff=date_diff($cS,$cD);




//echo $cD;
//echo $cS;
//$queryEntry = "INSERT INTO timeextend VALUES ('','$type','$brn','$compSeq','$cD','$nAudit')";
//$queryEntry2 = "INSERT INTO timeextend VALUES ('','$type','$brn','$compSeq','$cS','$nAudit','$cR')";
$querySearch = "UPDATE brcom SET brn='$brn', cD='$cD', cS='$cS', rD='$rD', aBd='$aBd', grade='$grade', nAudit='$nAudit', followupDate='$CrD' WHERE (type LIKE '$type' AND brn LIKE '$brnPrev' AND compSeq='$compSeq')";
//$result1 = mysql_query($queryEntry);
//$result2 = mysql_query($queryEntry2);
//$querySearch = "SELECT out FROM brreport WHERE out='$out'";
$result = mysql_query($querySearch);
//$num = mysql_num_rows($result);
//echo $num;

mysql_close();


?> 
<h3>Compliance Records have been updated......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="complianceSeqEntry.php" target="_parent">Bact to Compliance Records Entry (Branch) Page</a> </div>
</body>
</html>













