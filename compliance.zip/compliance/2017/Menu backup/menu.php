<dl class="dropdown">
  <dt id="one-ddheader" onmouseover="ddMenu('one',1)" onmouseout="ddMenu('one',-1)">Branch</dt>
  <dd id="one-ddcontent" onmouseover="cancelHide('one')" onmouseout="ddMenu('one',-1)">
    <ul>
    <li><a href="auditEntry.php" class="underline">Audit Entry</a></li>
      <li><a href="observationEntry.php" class="underline">RBIA Observations Entry</a></li>
      
      <li><a href="complianceEntry.php" class="underline">RBIA Observations Update</a></li>
      <li><a href="ISSobservationEntry.php" class="underline">ISS Observations Entry</a></li>
      <li><a href="ISScomplianceEntry.php" class="underline">ISS Observations Update</a></li>
      <li><a href="complianceSeqEntry.php" class="underline">Compliance Sent</a></li>
      <li><a href="complianceSubmissionEntry.php" class="underline">Compliance Receive</a></li>

    </ul>
  </dd>
</dl>

<dl class="dropdown">
  <dt id="two-ddheader" onmouseover="ddMenu('two',1)" onmouseout="ddMenu('two',-1)">Head Office</dt>
  <dd id="two-ddcontent" onmouseover="cancelHide('two')" onmouseout="ddMenu('two',-1)">
    <ul>
      <li><a href="auditEntryHO.php" class="underline">Audit Entry</a></li>
      <li><a href="complianceSeqEntryHO.php" class="underline">Compliance Sent</a></li>
      <li><a href="complianceSubmissionEntryHO.php" class="underline">Compliance Receive</a></li>
       <li><a href="complianceSubmissionSearchBranchwiseHO.php" class="underline">Compliance Matrix</a></li>
      <li><a href="auditListHO.php" class="underline">Audit Listing</a></li>
      <li><a href="complianceSubmissionSearchOverdueHO.php" class="underline">Overdue Submission List</a></li>
    </ul>
  </dd>
</dl>




<dl class="dropdown">
  <dt id="four-ddheader" onmouseover="ddMenu('four',1)" onmouseout="ddMenu('four',-1)">Reports</dt>
  <dd id="four-ddcontent" onmouseover="cancelHide('four')" onmouseout="ddMenu('four',-1)">
    <ul>
    <li><a href="dashBoard.php" class="underline">Compliance DashBoard</a></li>
    <li><a href="complianceSearchBranchwise.php" class="underline">Observations Matrix</a></li>
    <li><a href="complianceSubmissionSearchBranchwise.php" class="underline">Compliance Matrix</a></li>
   
    <li><a href="reportList.php" class="underline">Report Listing</a></li>
    <li><a href="auditList.php" class="underline">Audit Listing</a></li>
     
    <li><a href="unAuditList.php" class="underline">Un-Audited Records</a></li>
     <li><a href="complianceImproveBranchwise.php" class="underline">Branch Compliance Improvement</a></li>
      <li><a href="timeExtensionHistory.php" class="underline">Time Extension History</a></li>
      
      <li><a href="ComplianceSubmittedList.php" class="underline">ComplianceSubmittedList</a></li>
      <li><a href="complianceSubmissionSearchLate.php" class="underline">DelaySubmissionList</a></li>
      <li><a href="complianceSubmissionSearchOverdue.php" class="underline">Overdue Submission List</a></li>
      
    </ul>
  </dd>
</dl>

<dl class="dropdown">
  <dt id="five-ddheader" onmouseover="ddMenu('five',1)" onmouseout="ddMenu('five',-1)">Maintenance</dt>
  <dd id="five-ddcontent" onmouseover="cancelHide('five')" onmouseout="ddMenu('five',-1)">
    <ul>
      
      <li><a href="passwordUpdate.php" class="underline">Change Password</a></li>
      <li><a href="complianceSubmissionEntryDELETE.php" class="underline">Compliance Time Extension</a></li>
      <li><a href="complianceEntryD.php" class="underline">RBIA Observations Delete</a></li>
      <li><a href="complianceSubmissionEntryDELETE2.php" class="underline">Branch Compliance Edit</a></li>
      <li><a href="complianceSubmissionDelete1.php" class="underline">Branch Compliance Delete</a></li>
      <li><a href="complianceSubmissionEntryDELETE2HO.php" class="underline">HO Compliance Edit</a></li>
    </ul>
  </dd>
</dl>


<div style="clear:both" />