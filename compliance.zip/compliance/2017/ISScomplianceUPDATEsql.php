<html>
<head>

<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brn = $_POST['brn'];
$aua = $_POST['aua'];




$hro = $_POST['hro'];
$mro = $_POST['mro'];
$lro = $_POST['lro'];

$s = $hro + $mro + $lro;
$too = $s;




//echo $inv;
//echo $out;

$querySearch = "UPDATE observations SET highRiskObs='$hro', MediumRiskObs='$mro', lowRiskObs='$lro', totalObservations='$too'
WHERE brName='$brn' and auditArea='$aua'";

//$querySearch = "SELECT out FROM brreport WHERE out='$out'";
$result = mysql_query($querySearch);
//$num = mysql_num_rows($result);





$querySearch1 = "UPDATE temp SET obs='$hro'
WHERE br='$brn' and auditArea='$aua' and riskLevel='HIGH'";
$result1 = mysql_query($querySearch1);

$querySearch2 = "UPDATE temp SET obs='$mro'
WHERE br='$brn' and auditArea='$aua' and riskLevel='MEDIUM'";
$result2 = mysql_query($querySearch2);

$querySearch3 = "UPDATE temp SET obs='$lro'
WHERE br='$brn' and auditArea='$aua' and riskLevel='LOW'";
$result3 = mysql_query($querySearch3);




mysql_close();


?> 
<h3>Non-complied Information have been updated......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="complianceEntry.php" target="_parent">Bact to Non-Complied Observations Entry (Branch) Page</a> </div>
</body>
</html>













