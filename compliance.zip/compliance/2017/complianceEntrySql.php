
<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brn = $_POST['brn'];
//$aua = $_POST['aua'];


if ($brn == "Select Branch" or $aua == "Select Audit Area")
{
echo ('<font color="#0000FF" size="4" face="Arial, Helv"etica, sans-serif"><strong>Search Criteria not matched .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter new search criteria</strong></font><br>
<br>
<br>
<a href="observationEntry.php" target="_parent">Back to Compliance Status Entry (Branch) Page</a>');
exit();
}
$querySearch = "SELECT * FROM `observations` WHERE brName = '$brn' and riskArea = 'RBIA'";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
if($num >0)
{
$GBhro = mysql_result($result,$i,"highRiskObs");
$GBmro = mysql_result($result,$i,"MediumRiskObs");
$GBlro = mysql_result($result,$i,"lowRiskObs");
$tooGB = mysql_result($result,$i,"totalObservations");

$CRhro = mysql_result($result,$i+1,"highRiskObs");
$CRmro = mysql_result($result,$i+1,"MediumRiskObs");
$CRlro = mysql_result($result,$i+1,"lowRiskObs");
$tooCR = mysql_result($result,$i+1,"totalObservations");

$TFhro = mysql_result($result,$i+2,"highRiskObs");
$TFmro = mysql_result($result,$i+2,"MediumRiskObs");
$TFlro = mysql_result($result,$i+2,"lowRiskObs");
$tooTF = mysql_result($result,$i+2,"totalObservations");
?> 
</head>

<body>


<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
      <font color="#FF0000" face="Arial, Helvetica, sans-serif"><strong><em>Non-Complied Observations Update (Branch)</em></strong></font><br>
<br>
</td></tr>
  <tr> 
    <td width="100%" align="center"><form name="form1" method="post" action="complianceUPDATEsql.php" enctype="multipart/form-data">
        <table width="50%" border="13">
		
          
         <tr> 
            <td width="35%"><strong>Branch Name</strong></td>
            <td width="65%" align="center"> <strong><input name="brn"  value= "<?php echo $brn;?>" type="text" size="20" readonly></strong></td>
          </tr>
		  
		  <tr> 
            <td width="35%"><strong>Audit Area</strong></td>
            <td width="65%"><table width="322" border="5">
  <tr>
    <td><input name="gb" type="text" size="17" value="General Banking" readonly></td>
    <td><input name="cr" type="text" size="17" value="Credit Risk" readonly></td>
    <td><input name="tf" type="text" size="17" value="Trade Finance" readonly></td>
  </tr>
</table>
 </td>
          </tr>
		 

		 
		 
		 
		 
          <tr> 
            <td width="35%"><strong>High Risk Observations</strong><br></td>
            <td width="65%"><table width="200" border="5" cellspacing="10">
  <tr>
    <td><input name="GBhro" type="text" size="15" value="<?php echo $GBhro; ?>"></td>
    <td><input name="CRhro" type="text" size="15" value="<?php echo $CRhro; ?>"></td>
    <td><input name="TFhro" type="text" size="15" value="<?php echo $TFhro; ?>"></td>
  </tr>
</table> </td>
          </tr>
          
          
          
          
          
          
          
		  <tr> 
            <td width="35%"><strong>Medium Risk Observations </strong><br></td>
            <td width="65%"><table width="200" border="5" cellspacing="10">
  <tr>
    <td><input name="GBmro" type="text" size="15" value="<?php echo $GBmro; ?>"></td>
    <td><input name="CRmro" type="text" size="15" value="<?php echo $CRmro; ?>"></td>
    <td><input name="TFmro" type="text" size="15" value="<?php echo $TFmro; ?>"></td>
  </tr>
</table> </td>
          </tr>
		  <tr> 
            <td width="35%"><strong>Low Risk Observations</strong><br></td>
            <td width="65%"> <table width="200" border="5" cellspacing="10">
  <tr>
    <td><input name="GBlro" type="text" size="15" value="<?php echo $GBlro; ?>"></td>
    <td><input name="CRlro" type="text" size="15" value="<?php echo $CRlro; ?>"></td>
    <td><input name="TFlro" type="text" size="15" value="<?php echo $TFlro; ?>"></td>
  </tr>
</table></td>
          </tr>
          
           <tr> 
            <td><input name="submit" type="submit" value="Update Status"></td>
            <td><input name="" type="reset" value="Reset"></td>
          </tr>
          
        </table></form>
</body>
</html>
<?php 
} else
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Compliance Information not entered .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter Update Compliance Information</strong></font><br>
<br>
<br>
<a href="observationEntry.php" target="_parent">Bact to Non-Complied Observations Entry (Branch) Page</a>');

}
?>