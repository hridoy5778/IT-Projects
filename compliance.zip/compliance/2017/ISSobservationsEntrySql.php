<html>
<head>

<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brn = $_POST['brn'];
$aua = $_POST['aua'];

$ria = $_POST['ria'];


$hro = $_POST['hro'];
$mro = $_POST['mro'];
$lro = $_POST['lro'];
$s = $hro + $mro + $lro;

$too = $s;


//echo $inv;
//echo $out;

$querySearch = "SELECT * FROM `observations` WHERE brName = '$brn' and auditArea = '$aua' and riskArea = '$ria'";

//$querySearch = "SELECT out FROM brreport WHERE out='$out'";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num >0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Observations Information already entered .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter new Observations Information</strong></font><br>
<br>
<br>
<a href="ISSobservationEntry.php" target="_parent">Bact to Audit Observations Entry (Branch) Page</a>');
exit();
}
//$name = $type." on ".$brn;
$query = "INSERT INTO observations VALUES ('$brn','$aua','ISS','$hro','$mro','$lro','$too')";
mysql_query($query);
$entDateT=date('Y-m-d');
$query2 = "INSERT INTO observationsbase VALUES ('$brn','$aua','ISS','$hro','$mro','$lro','$too','$entDateT')";
mysql_query($query2);
$query7 = "INSERT INTO temp VALUES ('$brn','ISS','$aua','HIGH','$hro')";                                       
mysql_query($query7);
$query77 = "INSERT INTO temp VALUES ('$brn','ISS','$aua','MEDIUM','$mro')"; 
mysql_query($query77);
$query777 = "INSERT INTO temp VALUES ('$brn','ISS','$aua','LOW','$lro')"; 
mysql_query($query777);
mysql_close();

//move_uploaded_file($_FILES["inv"]["tmp_name"],"report/branch/summary/".$_FILES["inv"]["name"]);
      //echo "Stored in: " . "image/" . $_FILES["cv"]["name"];
      
      //echo "file has been uploaded"."<br/>"."<br/>";
	  //$tmp = $_FILES["cv"]["name"];
	  //echo $tmp;
?> 
<h3>Observations Information have been entered......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="ISSobservationEntry.php" target="_parent">Bact to Observations Record Entry (Branch) Page</a> </div>
</body>
</html>













<body>

</body>
</html>
