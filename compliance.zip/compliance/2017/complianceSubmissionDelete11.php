<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$query1 = "SELECT name FROM branch order by name";
$result1 = mysql_query($query1);
$num1 = mysql_num_rows($result1);

$type = $_POST['type'];


$brn = $_POST['brn'];

$compSeq = $_POST['compSeq'];
$brnPrev = $brn;
//echo $out;


if ($brn == "Select Branch" && $compSeq == "Select Seq Number")
{
echo ('<font color="#0000FF" size="4" face="Arial, Helv"etica, sans-serif"><strong>Search Criteria not matched .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter new search criteria</strong></font><br>
<br>
<br>
<a href="complianceSubmissionEntry.php" target="_parent">Back to Compliance Records Update (Branch) Page</a>');
exit();
}
//echo $out;
$querySearch = "SELECT * FROM `brcom` WHERE type = '$type' and brn = '$brn' and compSeq = '$compSeq'";
//echo $out;
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num >0)
{
$id = mysql_result($result,$i,"id");	
$rD = mysql_result($result,$i,"rD");	
$followupDate = mysql_result($result,$i,"followupDate");
$aBd = mysql_result($result,$i,"aBd");
$type = mysql_result($result,$i,"type");
$grade = mysql_result($result,$i,"grade");
$brn = mysql_result($result,$i,"brn");
$compSeq = mysql_result($result,$i,"compSeq");
$cD = mysql_result($result,$i,"cD");
$cS = mysql_result($result,$i,"cS");
$nAudit = mysql_result($result,$i,"nAudit");
?> 
</head>

<body>
<table width="100%" border="0">

  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
      <font color="#FF0000" face="Arial, Helvetica, sans-serif"><strong><em>Compliance Records Edit (Branch)</em></strong></font><br>
<br>
</td></tr>
  <tr> 
    <td width="100%" align="center"><form name="form1" method="post" action="complianceSubmissionDelete111.php" enctype="multipart/form-data">
    
   <table width="50%" border="13">
        
        
         <tr> 
            <td width="35%">Branch Name</td>
            <td width="65%"><input name="brnPrev" value= "<?php echo $brnPrev;?>" type="text" size="40" readonly> </td>
          </tr>    
        
        
		
          <tr> 
            <td width="35%">Branch Grade</td>
            <td width="65%"><input name="grade" value= "<?php echo $grade;?>" type="text" size="40"> </td>
          </tr>
           <tr> 
            <td width="35%">Audit Type</td>
            <td width="65%">
            <input name="type" value= "<?php echo $type;?>" type="text" size="40" readonly>
            </td>
          </tr>
          <tr> 
            <td width="35%">Compliance Sequence Number <br></td>
            <td width="65%"><input name="compSeq" value= "<?php echo $compSeq;?>" type="text" size="40" readonly> </td>
          </tr>
           <tr> 
            <td width="35%">Number of Audit</td>
            <td width="65%"><input name="nAudit" value= "<?php echo $nAudit;?>" type="text" size="40"> </td>
          </tr>
		  <tr> 
            <td width="35%">Audit Base Date<br></td>
            <td width="65%"><input name="aBd" value= "<?php echo $aBd;?>" type="text" size="40" id="aBd"> <img src="images/search_calendar.png" id="calaBd"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
		 
		 
          
           <tr> 
            <td width="35%">Audit Report Date <br></td>
            <td width="65%"><input name="rD" value= "<?php echo $rD;?>" type="text" size="40" id="rD"> <img src="images/search_calendar.png" id="calrD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
           <tr> 
            <td width="35%">Compliance Report Date <br></td>
            <td width="65%"><input name="CrD" value= "<?php echo $followupDate;?>" type="text" size="40" id="CrD"> <img src="images/search_calendar.png" id="calCrD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
		  <tr> 
            <td width="35%">Compliance Due Date <br></td>
            <td width="65%"><input name="cD" value= "<?php echo $cD;?>" type="text" size="40" id="cD"> <img src="images/search_calendar.png" id="calcD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
          
          <tr> 
            <td>Compliance Submission Date</td>
            <td> <input name="cS" type="text" size="40" id="cS" value= "<?php echo $cS;?>"> 
              <img src="images/search_calendar.png" id="calcS"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
          
          
     <tr> 
            <td width="35%"></td>
            <td width="65%"><input name="brnPrev" value= "<?php echo $id;?>" type="text" size="40" hidden> </td>
          </tr> 
           
          
		 
          
         
          
           <tr> 
            <td><input name="submit" type="submit" value="DELETE RECORD"></td>
            <td><input name="" type="reset" value="Reset"></td>
          </tr>
          
           </table>
          <script type="text/javascript">
Calendar.setup({
inputField : "cS",
ifFormat : "%Y-%m-%d",
button : "calcS",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "aBd",
ifFormat : "%Y-%m-%d",
button : "calaBd",
align : "T1",
singleClick : true
});
</script>
      <script type="text/javascript">
Calendar.setup({
inputField : "rD",
ifFormat : "%Y-%m-%d",
button : "calrD",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "CrD",
ifFormat : "%Y-%m-%d",
button : "calCrD",
align : "T1",
singleClick : true
});
</script>
      <script type="text/javascript">
Calendar.setup({
inputField : "cD",
ifFormat : "%Y-%m-%d",
button : "calcD",
align : "T1",
singleClick : true
});
</script>

          </tr>
          </form>
        </table>
        
</body>
</html>
<?php 
} else
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Compliance Information not entered .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter Update Compliance Information</strong></font><br>
<br>
<br>
<a href="complianceSeqEntry.php" target="_parent">Bact to Compliance Record Entry (Branch) Page</a>');

}
?>