<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$type = $_POST['type'];


$brn = $_POST['brn'];

$compSeq = $_POST['compSeq'];

//echo $out;


if ($brn == "Select Branch" && $compSeq == "Select Seq Number")
{
echo ('<font color="#0000FF" size="4" face="Arial, Helv"etica, sans-serif"><strong>Search Criteria not matched .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter new search criteria</strong></font><br>
<br>
<br>
<a href="complianceSubmissionEntryR.php" target="_parent">Back to Compliance Records Followup (Branch) Page</a>');
exit();
}
//echo $out;
$querySearch = "SELECT * FROM `brcom` WHERE type = '$type' and brn = '$brn'";
//echo $out;
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num >0)
{
$type = mysql_result($result,$i,"type");
$brn = mysql_result($result,$i,"brn");
$compSeq = mysql_result($result,$i,"compSeq");
$cD = mysql_result($result,$i,"cD");
$rD = mysql_result($result,$i,"rD");
$aBd = mysql_result($result,$i,"aBd");
$grade = mysql_result($result,$i,"grade");
$bbRate = mysql_result($result,$i,"bbRate");
$nAudit = mysql_result($result,$i,"nAudit");
$cS = mysql_result($result,$i,"cS");
?> 
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
      <font color="#FF0000" face="Arial, Helvetica, sans-serif"><strong><em>Compliance Submissions Update (Branch)</em></strong></font><br>
<br>
</td></tr>
  <tr> 
    <td width="100%" align="center"><form name="form1" method="post" action="complianceSeqEntrySqlR.php" enctype="multipart/form-data">
        <table width="50%" border="13">
		<tr> 
            <td width="35%">Branch Name <br></td>
            <td width="65%"><input name="brn"  value= "<?php echo $brn;?>" type="text" size="40" readonly> </td>
          </tr>
		  <tr> 
            <td width="35%">Audit Type<br></td>
            <td width="65%"><input name="type" value= "<?php echo $type;?>" type="text" size="60" readonly> </td>
          </tr>
		 
		 <tr> 
            <td width="35%">Compliance Sequence Number</td>
            <td width="65%">
            
            <select name="compSeq">
                <option>Select Seq Number</option>
                
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
                <option>9</option>
                
                </select>
            
             </td>
          </tr>
		  <tr> 
            <td>Compliance Due Date</td>
            <td> <input name="cD" type="text" size="40" id="cD" readonly="true"> 
              <img src="images/search_calendar.png" id="calcD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
		 <tr> 
            <td>Audit Report Date</td>
            <td> <input name="rD" type="text" size="40" value="<?php echo $rD;?>" id="rD" readonly="true"> 
             </td>
          </tr>
           <tr> 
            <td>Audit Base Date</td>
            <td> <input name="aBd" type="text" size="40" value="<?php echo $aBd;?>" id="aBd" readonly="true"> 
              </td>
          </tr>
          <tr> 
            <td width="35%">Branch Grade</td>
            <td width="65%">  <input name="grade" type="text" size="40" value="<?php echo $grade;?>" readonly="true"> 
             </td>
          </tr>
          
           <tr> 
            <td width="35%">Bangladesh Bank Risk Rating</td>
            <td width="65%"><input name="bbRate" type="text" value="<?php echo $bbRate;?>" readonly> out of 300</td>
          </tr>
          
          <tr> 
            <td width="35%">Number of Audit</td>
            <td width="65%"><input name="nAudit" type="text" value="<?php echo $nAudit;?>"></td>
          </tr>
          <tr> 
            <td>Compliance Report Date</td>
            <td> <input name="CrD" type="text" size="40" id="CrD" readonly="true"> 
              <img src="images/search_calendar.png" id="calCrD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
           <tr> 
            <td><input name="submit" type="submit" value="Followup Entry"></td>
            <td><input name="" type="reset" value="Reset"></td>
          </tr>
          <script type="text/javascript">
Calendar.setup({
inputField : "cD",
ifFormat : "%Y-%m-%d",
button : "calcD",
align : "T1",
singleClick : true
});
</script>

<script type="text/javascript">
Calendar.setup({
inputField : "CrD",
ifFormat : "%Y-%m-%d",
button : "calCrD",
align : "T1",
singleClick : true
});
</script>
          
          </form>
        </table>
</body>
</html>
<?php 
} else
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Compliance Information not entered .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter Update Compliance Information</strong></font><br>
<br>
<br>
<a href="complianceSeqEntry.php" target="_parent">Bact to Compliance Record Entry (Branch) Page</a>');

}
?>