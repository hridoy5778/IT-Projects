<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brn = $_POST['brn'];
$aua = $_POST['aua'];


if ($brn == "Select Branch" or $aua == "Select Audit Area")
{
echo ('<font color="#0000FF" size="4" face="Arial, Helv"etica, sans-serif"><strong>Search Criteria not matched .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter new search criteria</strong></font><br>
<br>
<br>
<a href="observationEntry.php" target="_parent">Back to Compliance Status Entry (Branch) Page</a>');
exit();
}
$querySearch = "SELECT * FROM `observations` WHERE brName = '$brn' and auditArea = '$aua'";


$result = mysql_query($querySearch);
$num = mysql_num_rows($result);

if($num >0)
{
$hro = mysql_result($result,$i,"highRiskObs");
$mro = mysql_result($result,$i,"mediumRiskObs");
$lro = mysql_result($result,$i,"lowRiskObs");
$too = mysql_result($result,$i,"totalObservations");
?> 
</head>

<body>


<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
      <font color="#FF0000" face="Arial, Helvetica, sans-serif"><strong><em>Non-Complied Observations Update (Branch)</em></strong></font><br>
<br>
</td></tr>
  <tr> 
    <td width="100%" align="center"><form name="form1" method="post" action="ISScomplianceUPDATEsql.php" enctype="multipart/form-data">
        <table width="50%" border="13">
		<tr> 
            <td width="35%">Branch Name <br></td>
            <td width="65%"><input name="brn"  value= "<?php echo $brn;?>" type="text" size="40" readonly> </td>
          </tr>
		  <tr> 
            <td width="35%">Audit Area <br></td>
            <td width="65%"><input name="aua" value= "<?php echo $aua;?>" type="text" size="40" readonly> </td>
          </tr>
		 
		 <tr> 
            <td width="35%">High Risk Observations <br></td>
            <td width="65%"><input name="hro" value= "<?php echo $hro;?>" type="text" size="40"> </td>
          </tr>
		  <tr> 
            <td width="35%">Medium Risk Observations <br></td>
            <td width="65%"><input name="mro" value= "<?php echo $mro;?>" type="text" size="40"> </td>
          </tr>
		  <tr> 
            <td width="35%">Low Risk Observations <br></td>
            <td width="65%"><input name="lro" value= "<?php echo $lro;?>" type="text" size="40"> </td>
          </tr>
          
         
          
           <tr> 
            <td><input name="submit" type="submit" value="Update Status"></td>
            <td><input name="" type="reset" value="Reset"></td>
          </tr>
          </tr>
        </table></form>
</body>
</html>
<?php 
} else
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Compliance Information not entered .</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please enter Update Compliance Information</strong></font><br>
<br>
<br>
<a href="observationEntry.php" target="_parent">Bact to Non-Complied Observations Entry (Branch) Page</a>');

}
?>