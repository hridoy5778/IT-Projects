<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
<?php 

include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT name FROM branch order by name";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();

?> 
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
      <font color="#FF0000" face="Arial, Helvetica, sans-serif"><strong><em>Time Extension History 
      Search (Branch wise)</em></strong></font><br>
<br>
</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><form name="form1" method="post" action="timeExtensionHistorySQL.php" enctype="multipart/form-data">
        <table width="50%" border="13">
          <tr> 
            <td width="35%">Audit Type</td>
            <td width="65%">
            
            <select name="type">
                <option>RBIA</option>
                <option>ISS</option>
                </select>
            
             </td>
          </tr>
         
          <tr> 
            <td width="35%">Branch Name</td>
            <td width="65%"><select name="brn">
                <option>Select Branch</option>
                <?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?>">
                </select> </td>
          </tr>
          
                
          
         
         
          <tr> 
            <td><input name="submit" type="submit" value="Search"></td>
            <td><input name="" type="reset" value="Reset"></td>
          </tr>
          
        </table>
      </form>
     
</td>
  </tr>
  <tr><td colspan="2" align="center"><br>
<br>
<br><br>
<br>

<?php include_once('footer.php');?></td></tr>
</table>


</body>
</html>
