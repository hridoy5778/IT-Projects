<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20%"></td>
    <td width="75%">
    
    <?php
$favcolor = $_SESSION['role'];

switch ($favcolor) {
    case "C":
        include_once('menuC.php');
        break;
    case "IS":
        include_once('menuIS.php');
        break;
    
    default:
        include_once('menu.php');
}
?> 
    
    
    </td>
    <td width="5%"><a href="../index.php">Logout</a></td>
  </tr>
</table>