<html>
<head>

<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$brn = $_POST['brn'];
//$aua = $_POST['aua'];
$gb = $_POST['gb'];
$cr = $_POST['cr'];
$tf = $_POST['tf'];


$GBhro = $_POST['GBhro'];
$CRhro = $_POST['CRhro'];
$TFhro = $_POST['TFhro'];

$GBmro = $_POST['GBmro'];
$CRmro = $_POST['CRmro'];
$TFmro = $_POST['TFmro'];


$GBlro = $_POST['GBlro'];
$CRlro = $_POST['CRlro'];
$TFlro = $_POST['TFlro'];


$sGB = $GBhro + $GBmro + $GBlro;
$sCR = $CRhro + $CRmro + $CRlro;
$sTF = $TFhro + $TFmro + $TFlro;
$tooGB = $sGB;
$tooCR = $sCR;
$tooTF = $sTF;

//$brn = $_POST['brn'];
//$aua = $_POST['aua'];
//$hro = $_POST['hro'];
//$mro = $_POST['mro'];
//$lro = $_POST['lro'];
//$s = $hro + $mro + $lro;
//$too = $s;
//echo $inv;
//echo $out;

$querySearch = "UPDATE observations SET highRiskObs='$GBhro', MediumRiskObs='$GBmro', lowRiskObs='$GBlro', totalObservations='$tooGB'
WHERE brName='$brn' and auditArea='$gb'";
$result = mysql_query($querySearch);

$querySearch1 = "UPDATE observations SET highRiskObs='$CRhro', MediumRiskObs='$CRmro', lowRiskObs='$CRlro', totalObservations='$tooCR'
WHERE brName='$brn' and auditArea='$cr'";
$result1 = mysql_query($querySearch1);

$querySearch2 = "UPDATE observations SET highRiskObs='$TFhro', MediumRiskObs='$TFmro', lowRiskObs='$TFlro', totalObservations='$tooTF'
WHERE brName='$brn' and auditArea='$tf'";
$result2 = mysql_query($querySearch2);


$querySearch = "UPDATE temp SET obs='$GBhro'
WHERE br='$brn' and auditArea='$gb'";
$result = mysql_query($querySearch);

$querySearch = "UPDATE temp SET obs='$CRhro'
WHERE br='$brn' and auditArea='$cr'";
$result = mysql_query($querySearch);

$querySearch = "UPDATE temp SET obs='$TFhro'
WHERE br='$brn' and auditArea='$tf'";
$result = mysql_query($querySearch);




$querySearch = "UPDATE temp SET obs='$GBmro'
WHERE br='$brn' and auditArea='$gb'";
$result = mysql_query($querySearch);

$querySearch = "UPDATE temp SET obs='$CRmro'
WHERE br='$brn' and auditArea='$cr'";
$result = mysql_query($querySearch);

$querySearch = "UPDATE temp SET obs='$TFmro'
WHERE br='$brn' and auditArea='$tf'";
$result = mysql_query($querySearch);



$querySearch = "UPDATE temp SET obs='$GBlro'
WHERE br='$brn' and auditArea='$gb'";
$result = mysql_query($querySearch);

$querySearch = "UPDATE temp SET obs='$CRlro'
WHERE br='$brn' and auditArea='$cr'";
$result = mysql_query($querySearch);

$querySearch = "UPDATE temp SET obs='$TFlro'
WHERE br='$brn' and auditArea='$tf'";

//$querySearch = "SELECT out FROM brreport WHERE out='$out'";

//$num = mysql_num_rows($result);


mysql_close();


?> 
<h3>Non-complied Information have been updated......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="complianceEntry.php" target="_parent">Bact to Non-Complied Observations Entry (Branch) Page</a> </div>
</body>
</html>













