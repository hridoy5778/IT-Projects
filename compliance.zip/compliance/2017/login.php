<?php
session_start();
$year = $_POST['year'];
$_SESSION['year']=$year;
$username = $_GET['username'];
$_SESSION['login']=$username;
$password = $_GET['password'];
$ip=$_SERVER['REMOTE_ADDR'];
$_SESSION['ip']=$ip;
$hostName = GetHostByName($REMOTE_ADDR); 
$dt = date("Fj,Y,g:i a");
include_once('config.php');
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
$result = mysql_query($query);
$num = mysql_num_rows($result);

if($num>0)
{
$query3 = "update admin set ip = '$ip', hostName = '$hostName', dt = '$dt' where username = '$username'";
$result3 = mysql_query($query3);
$role = mysql_result($result,$i,"role");
$_SESSION['role']=$role;
//echo $role;
mysql_close();
?>
<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"></td>
  </tr>
  <tr> 
    <td width="100%" align="center">
    
   
    
    <br> <br>
   </td>
  </tr>

<?php }
	else
	{
	?>
Please try again to <a href="../index.php" target="_self">Login</a> <br>
<br>
For assistance: Contact ICC division
      <?php 
	  unset($_SESSION['login']);
session_destroy();
mysql_close();
	  }?>
<tr> 
    <td width="100%" align="center"><br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php include_once('footer.php');?></td>
  </tr>
</table>

</body>
</html>
