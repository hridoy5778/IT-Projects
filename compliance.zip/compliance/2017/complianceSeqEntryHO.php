<html>
<head>
<title><?php include_once('titlebar.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
<?php 

include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT name FROM division order by name";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();

?> 
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/UCBL_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
      <font color="#FF0000" face="Arial, Helvetica, sans-serif"><strong><em>Compliance Record 
      Entry (Division)</em></strong></font><br>
<br>
</td>
  </tr>
  <tr> 
    <td width="100%" align="center"><form name="form1" method="post" action="complianceSeqEntrySqlHO.php" enctype="multipart/form-data">
        <table width="50%" border="13">
           <tr> 
            <td width="35%">Audit Type</td>
            <td width="65%">
            
            <select name="type">
                <option>RBIA</option>
                <option>ISS</option>
                </select>
            
             </td>
          </tr>
          
          <tr> 
            <td width="35%">Division Name</td>
            <td width="65%"><select name="brn">
                <option>Select Division</option>
                <?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?>">
                </select> </td>
          </tr>
          
          
          <tr> 
            <td width="35%">Number of Audit</td>
            <td width="65%"><input name="nAudit" type="text"></td>
          </tr>
          
          
          
           <tr> 
            <td width="35%">Compliance Sequence Number</td>
            <td width="65%">
            
            <select name="compSeq">
                <option>Select Seq Number</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
                <option>9</option>
                
                </select>
            
             </td>
          </tr>
         
          
          <tr> 
            <td>Audit Report Date</td>
            <td> <input name="rD" type="text" size="40" id="rD" readonly="true"> 
              <img src="images/search_calendar.png" id="calrD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
          <tr> 
            <td>Compliance Report Date</td>
            <td> <input name="CrD" type="text" size="40" id="CrD" readonly="true"> 
              <img src="images/search_calendar.png" id="calCrD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
          <tr> 
            <td>Audit Base Date</td>
            <td> <input name="aBd" type="text" size="40" id="aBd" readonly="true"> 
              <img src="images/search_calendar.png" id="calaBd"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
          
          <tr> 
            <td>Compliance Due Date</td>
            <td> <input name="cD" type="text" size="40" id="cD" readonly="true"> 
              <img src="images/search_calendar.png" id="calcD"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
          </tr>
          
         
          <tr> 
            <td><input name="submit" type="submit" value="ADD ENTRY"></td>
            <td><input name="" type="reset" value="Reset"></td>
          </tr>
          
        </table>
      </form>
      <script type="text/javascript">
Calendar.setup({
inputField : "aBd",
ifFormat : "%Y-%m-%d",
button : "calaBd",
align : "T1",
singleClick : true
});
</script>
      <script type="text/javascript">
Calendar.setup({
inputField : "rD",
ifFormat : "%Y-%m-%d",
button : "calrD",
align : "T1",
singleClick : true
});
</script>
<script type="text/javascript">
Calendar.setup({
inputField : "CrD",
ifFormat : "%Y-%m-%d",
button : "calCrD",
align : "T1",
singleClick : true
});
</script>
      <script type="text/javascript">
Calendar.setup({
inputField : "cD",
ifFormat : "%Y-%m-%d",
button : "calcD",
align : "T1",
singleClick : true
});
</script>

</td>
  </tr>
  <tr><td colspan="2" align="center"><br>
<br>
<br><br>
<br>

<?php include_once('footer.php');?></td></tr>
</table>


</body>
</html>
