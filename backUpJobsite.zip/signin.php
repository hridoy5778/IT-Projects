<?php
session_start();
if(isset($_SESSION['login']))
{
unset($_SESSION['login']);
session_destroy();
}


?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td align="right" valign="top"></td>
  </tr>
  <tr align="center" bgcolor="#3333CC"> 
    <td height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
	  <td width="11%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><a href="/admin/" target="_self">Admin 
      Panel</a></font></strong></td>
  </tr>
  <tr> 
    <td align="center" colspan="2"> 
      <?php include_once('menu.php'); ?>
    </td>
  </tr>
  <tr> 
    <td colspan="2"><table width="100%" border="2" cellspacing="10">
        <tr> 
          <td><form action="signin2.php" method="post" target="_self">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td colspan="2">For Recruiters</td>
                </tr>
                <tr> 
                  <td>Email</td>
                  <td><input name="email" type="text"></td>
                </tr>
                <tr> 
                  <td>Password</td>
                  <td><input name="pin" type="password"></td>
                </tr>
                <tr> 
                  <td><input name="" type="hidden" value=""></td>
                  <td><input name="" type="hidden" value=""></td>
                </tr>
                <tr align="left" valign="top"> 
                  <td colspan="2"> <input name="Input" type="submit" value="Sign In"> 
                  </td>
                </tr>
                <tr> 
                  <td colspan="2" align="right"><a href="employeerReg.php" target="_self">New 
                    Registration</a></td>
                </tr>
              </table>
            </form>
            <form action="forgetPass.php" method="post" target="_self">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td colspan="2">Forgotten Pin Code?? Please write your email 
                    below and click the submit button</td>
                </tr>
				<tr> 
                  <td>Email Address</td>
                  <td><input name="email" type="text"></td>
                </tr>
                <tr> 
                  <td><input name="" type="submit" value="Submit"></td>
                  <td>&nbsp;</td>
                </tr>
              </table>
            </form></td>
          <td><form action="signin2.php" method="post" target="_self">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td colspan="2">For Job Seekers</td>
                </tr>
                <tr> 
                  <td>Email</td>
                  <td><input name="email" type="text"></td>
                </tr>
                <tr> 
                  <td>Pin Code</td>
                  <td><input name="pin" type="password"></td>
                </tr>
                <?php if(isset($_REQUEST['maincategory'])) {?>
                <tr> 
                  <td><input name="maincategory" type="hidden" value="<?php echo $_REQUEST['maincategory'];?>"></td>
                  <td><input name="subcategory" type="hidden" value="<?php echo $_REQUEST['subcategory'];?>"></td>
                </tr>
                <tr> 
                  <td><input name="city" type="hidden" value="<?php echo $_REQUEST['city'];?>"></td>
                  <td><input name="type" type="hidden" value="<?php echo $_REQUEST['type'];?>"></td>
                </tr>
                <tr> 
                  <td><input name="frequency" type="hidden" value="<?php echo $_REQUEST['frequency'];?>"></td>
                  <td><input name="post" type="hidden" value="<?php echo $_REQUEST['post'];?>"></td>
                </tr>
                <tr> 
                  <td><input name="description" type="hidden" value="<?php echo $_REQUEST['description'];?>"></td>
                  <td><input name="rop" type="hidden" value="<?php echo $_REQUEST['rop'];?>"> 
                    <?php }?>
                  </td>
                </tr>
                <tr> 
                  <td align="left" valign="top"> <input name="" type="submit" value="Sign In"> 
                  </td>
                  <td></td>
                </tr>
                <tr> 
                  <td colspan="2" align="right"><a href="seekerReg.php" target="_self">New 
                    Registration</a></td>
                </tr>
              </table>
            </form>
            <form action="forgetPass.php" method="post" target="_self">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td colspan="2">Forgotten Pin Code?? Please write your email 
                    below and click the submit button</td>
                </tr>
				<tr> 
                  <td>Email Address</td>
                  <td><input name="email" type="text"></td>
                </tr>
                <tr> 
                  <td><input name="" type="submit" value="Submit"></td>
                  <td>&nbsp;</td>
                </tr>
              </table>
            </form></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>
