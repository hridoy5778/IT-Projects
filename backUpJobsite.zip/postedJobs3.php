<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}

$id = $_REQUEST['id'];
$email = $_REQUEST['email'];
$name = $_REQUEST['name'];
$city = $_REQUEST['city'];
$vacancy = $_REQUEST['vacancy'];
$salary = $_REQUEST['salary'];
$frequency = $_REQUEST['frequency'];
$type = $_REQUEST['type'];
$description = $_REQUEST['description'];
$maincategory = $_REQUEST['maincategory'];
$subcategory = $_REQUEST['subcategory'];
$postcode = $_REQUEST['postcode'];
$status = $_REQUEST['status'];
$up = $_REQUEST['up'];
$del = $_REQUEST['del'];
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>

  <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
    <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?></td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td colspan="2" height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
	<?php include_once('Employeermenu.htm'); ?>
	<tr><td></td><td><?php include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
if($up!='')
{
$query = "UPDATE job SET name ='$name',description ='$description',type ='$type',frequency ='$frequency',city ='$city',salary ='$salary',vacancy ='$vacancy',subcategory ='$subcategory',maincategory ='$maincategory',postcode ='$postcode',status ='$status' WHERE id='$id'";
mysql_query($query);
mysql_close();
}
if($del!='')
{
$query = "DELETE FROM job WHERE id='$id'";
mysql_query($query);
mysql_close();
}


?>
</td>
</tr>
<tr><td></td><td>Operation Completed</td></tr>    
  </table>

</body>
</html>
