<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:login.php');
exit();
}
$employeer = $_SESSION['login'];
$jobref = $_POST['refid'];
if($jobref=='All')
{
$jobref='%';
}
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM applications WHERE employeer='$employeer' AND jobref LIKE '$jobref'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="100%" border="0">
 <tr> 
    <td align="right" valign="top" colspan="3"></td>
  </tr>
  
  <tr> 
    <td width="16%" align="right" valign="top">&nbsp;</td>
    <td width="78%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
    <td width="6%"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr> 
    <td colspan="3" align="center"></td>
  </tr>
  <?php include('Employeermenu.htm'); ?>
  <tr> 
    <td colspan="3" align="center"></td>
  </tr>
  <tr> 
    <td align="center" valign="top"></td>
    <td align="center" valign="top">
	<?php 
	if($num>0){
	$i=0;
while ($i < $num) 
{
$jobref = mysql_result($result,$i,"jobref");
$employeer = mysql_result($result,$i,"employeer");
$seeker = mysql_result($result,$i,"seeker");
	?>
	<form action="" method="post" target="_self"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>Employeer's Email</td>
    <td>&nbsp;</td>
    <td><input name="employeer" type="text" value="<?php echo $employeer;?>" readonly="true"></td>
  </tr>
  <tr>
    <td>Job's Ref: Id</td>
    <td>&nbsp;</td>
    <td><input name="jobref" type="text" value="<?php echo $jobref;?>" readonly="true"></td>
  </tr>
  <tr>
    <td>Applicant's Email</td>
    <td>&nbsp;</td>
    <td><input name="seeker" type="text" value="<?php echo $seeker;?>" readonly="true"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><a href="searchcv3.php?email=<?php echo $seeker;?>" target="_blank">View Details</a></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table></form><?php $i++; }} else{?>
</td>
    <td align="center" valign="top"></td>
  </tr>
  
  
  
  
  <tr> 
    <td>None has been applied ..<?php }?></td>
  </tr>
</table>

</body>
</html>
