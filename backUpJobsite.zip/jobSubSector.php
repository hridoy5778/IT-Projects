<?php session_start();?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
$category = $_REQUEST['category'];
?>
</head>

<body>
<table width="100%" border="0">
<?php 
if(!isset($_SESSION['login']))
{?>
  <tr>
    <td align="right" valign="top" colspan="3"><a href="signin.php" target="_self">SignIn/Register</a></td>
  </tr><?php } else {?>
  <tr>
    <td width="16%" align="right" valign="top">&nbsp;</td>
	<td width="78%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="6%"><a href="signin.php" target="_self">Logout</a></td>
  </tr><?php }?>
  <tr>
    <td colspan="3" align="center">Banner</td>
  </tr>
  <tr><td width="100%" align="center" colspan="3"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="center" valign="top" width="23%"><?php include_once('searchjob.php');?></td>
	<td align="center" valign="top">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" align="center"><H2>Browse jobs by specialist role</H2><br>
<br>
To view the individual jobs for each role, please click 
on the role title.<br>
<?php 
	include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM jobsubcategory WHERE category='$category'";
$result = mysql_query($query);
$num = mysql_numrows($result);
mysql_close();
if($num>0)
{
$i=0;
$flag = 0;
while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$name = mysql_result($result,$i,"name");
$all = '%';
?>

<a href="showJob.php?maincategory=<?php echo $category;?>&subcategory=<?php echo $name;?>&city=<?php echo $all;?>&type=<?php echo $all;?>&frequency=<?php echo $all;?>&post=<?php echo $all;?>&rop=<?php echo $all;?>&description=<?php echo $all;?>" target="_self"><?php echo $name;?></a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php
$flag = $flag+1;
if($flag ==2)
{
echo ('<br/>');
$flag =0;
}
$i++;
}
}
else
{
echo "Sorry No job available";
}
?> 
</td>
  </tr>
</table>
	
	
	
	</td>
	<td align="center" valign="top">Right Pane</td>
  </tr>
  
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
