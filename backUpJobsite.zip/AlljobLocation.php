<?php session_start();?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
<table width="100%" border="0" bgcolor="#CCFFFF">
  <?php 
if(!isset($_SESSION['login']))
{?>
  <tr> 
    <td align="right" valign="top" colspan="3" bgcolor="#3333CC"><a href="signin.php" target="_self"><font face="Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">SignIn/Register</strong></font></font></a></td>
  </tr>
  <?php } else {?>
  <tr> 
    <td width="20%" align="right" valign="top">&nbsp;</td>
    <td width="61%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
    <td width="19%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <?php }?>
  <tr align="center" bgcolor="#3333CC"> 
    <td height="40%" colspan="3" valign="top" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr> 
    <td align="center" colspan="3" bgcolor="#3333CC"><?php include_once('menu.php'); ?></td>
  </tr>
  <tr> 
    <td width="20%" valign="top"><?php include_once('searchjob.php');?>
       </td>
	<td width="61%" bgcolor="#CCFFFF" valign="top"> 
      <?php include_once('AlljobLocationMini.php');?><br>
    </td>
    <td width="19%" bgcolor="#CCFFFF" valign="top"><img src="image/Nigeriamap.gif" width="241" height="400"></td>
  </tr>
  
  
  <tr> 
    <td width="20%" valign="top"></td>
	<td width="60%" bgcolor="#CCFFFF" align="center" bgcolor="#00FFCC" valign="top"></td>
    <td valign="top" width="20%"></td>
  
    
  </tr>
</table>
</body>
</html>
