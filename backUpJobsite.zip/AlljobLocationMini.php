<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">


</head>

<body>
<table width="100%" border="0" bgcolor="#CCFFFF">
<tr>
    <td align="center" valign="top"></td>
	<td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
          <td height="86" align="left" valign="top"><font color="#330099" face="Arial, Helvetica, sans-serif"><strong>Browse 
            jobs by location</strong></font><br><br>
<br>

            <?php 
	include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM city";
$result = mysql_query($query);
$num = mysql_numrows($result);
mysql_close();
$i=0;
$flag = 0;
while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$city = mysql_result($result,$i,"name");
$all = '%';
?>
            <strong><font color="#330099" face="Arial, Helvetica, sans-serif"><a href="showJob.php?maincategory=<?php echo $all;?>&subcategory=<?php echo $all;?>&city=<?php echo $city;?>&type=<?php echo $all;?>&frequency=<?php echo $all;?>&post=<?php echo $all;?>&rop=<?php echo $all;?>" target="_self"><?php echo $city;?></a></font></strong> 
            <?php
$flag = $flag+1;
if($flag ==1)
{
echo ('<br/><br/>');
$flag =0;
}
$i++;
}
?>
<br><br>
<br>
</td>
  </tr>
</table>
</td>

	<td align="center" valign="top" colspan="3"></td>
  </tr>
 </table>
</body>
</html>
