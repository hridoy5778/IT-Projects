<?php 
$db = "ecommerce1";
$dbhost = "213.171.219.98";		
$dbuser = "babar";
$dbpass = "kitchen";
?>
