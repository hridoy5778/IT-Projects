<?php session_start();?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#CCFFFF">
  <?php 
if(!isset($_SESSION['login']))
{?>
  <tr> 
    <td align="right" valign="top" colspan="3" bgcolor="#3333CC"><a href="signin.php" target="_self"><font face="Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF">SignIn/Register</strong></font></font></a></td>
  </tr>
  <?php } else {?>
  <tr> 
    
  <td width="20%" align="right" valign="top"><a href="signin2.php" target="_self">Control 
    Panel</a></td>
    <td width="61%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
    <td width="19%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <?php }?>
  <tr align="center" bgcolor="#3333CC">
  <td bgcolor="#3333FF"></td> 
    <td height="40%" valign="top" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
	  <td valign="top" bgcolor="#3333FF"><div align="right"><strong><font size="4" face="Arial, Helvetica, sans-serif"><a href="/admin/" target="_self">Admin 
        Panel</a></font></strong></div></td>
  </tr>
  <tr> 
    <td align="center" colspan="3" bgcolor="#3333CC"><?php include_once('menu.php'); ?></td>
  </tr>
  <tr> 
    <td width="20%" valign="top"><?php include_once('searchjob.php');?><br>
       </td>
	<td width="61%" bgcolor="#CCFFFF" valign="top"> 
      <?php include_once('jobSectorMini.php');?><br>
Let employer find you by creating your own cv 
      at our site <a href="signin.php" target="_self"><font color="#0033CC" face="Arial, Helvetica, sans-serif"><strong>Register now</strong></font></a>
    </td>
    <td width="19%" bgcolor="#CCFFFF" valign="top"><img src="image/Nigeriamap.gif" width="241" height="400"></td>
  </tr>
  
  
  <tr> 
    <td width="20%" valign="top"></td>
	<td width="60%" bgcolor="#CCFFFF" align="center" bgcolor="#00FFCC" valign="top"><?php include_once('jobLocationMini.php');?></td>
    <td valign="top" width="20%"></td>
  
    
  </tr>
</table>

<map name="Map">
  <area shape="poly" coords="29,484,38,497,158,498,177,482,167,466,41,467,33,474" href="signin.php" target="_self" alt="Plz Sign In">
  <area shape="poly" coords="28,369,41,381,69,381,94,381,121,381,121,374,115,368,106,364,37,363" href="searchcv.php" target="_self">
  <area shape="poly" coords="22,223,82,221,177,221,200,221,205,238,203,248,115,248,52,248,25,245,17,233" href="addjob.php" target="_self">
</map>
</body>
</html>
