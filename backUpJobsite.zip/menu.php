<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr bordercolor="#FFFFFF" bgcolor="#3333CC"> 
    <td align="center" valign="middle"><a href="index.php" target="_self"><font face="Arial, Helvetica, sans-serif"><font color="#FFFFFF"><strong>Home</strong></font></font></a></td>
    <td align="center" valign="middle"><font face="Arial, Helvetica, sans-serif"><a href="clientPage.php" target="_self"><font color="#FFFFFF"><strong>Client 
      page</strong></font></a></font></td>
    <td align="center" valign="middle"><font face="Arial, Helvetica, sans-serif"><a href="service.php" target="_self"><font color="#FFFFFF"><strong>Services</strong></font></a></font></td>
    <td align="center" valign="middle"><font face="Arial, Helvetica, sans-serif"><a href="jobSector.php" target="_self"><font color="#FFFFFF"><strong>Sectors</strong></font></a></font></td>
    <td align="center" valign="middle"><font face="Arial, Helvetica, sans-serif"><a href="contactPage.php" target="_self"><font color="#FFFFFF"><strong>Contact</strong></font></a></font></td>
    <td align="center" valign="middle"><font face="Arial, Helvetica, sans-serif"><a href="helpPage.php" target="_self"><font color="#FFFFFF"><strong>Help</strong></font></a></font></td>
  </tr>
</table>
