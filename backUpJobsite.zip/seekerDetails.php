<?php session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
$email = $_SESSION['login'];
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM seekerreg WHERE email='$email'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query3 = "SELECT * FROM card WHERE email='$email'";
$result3=mysql_query($query3);
mysql_close();
$i=0;

while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$name = mysql_result($result,$i,"name");
$address = mysql_result($result,$i,"address");
$email = mysql_result($result,$i,"email");
$others = mysql_result($result,$i,"others");
$phone = mysql_result($result,$i,"phone");
$mobile = mysql_result($result,$i,"mobile");
$web = mysql_result($result,$i,"web");
$lastdegree = mysql_result($result,$i,"lastdegree");
$others = mysql_result($result,$i,"others");
$status = mysql_result($result,$i,"status");
$cv = mysql_result($result,$i,"cv");
$i++;
}
$j=0;
$password = mysql_result($result3,$j,"pin");
?>
</head>

<body>
<table width="100%" border="0">
<tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?></td>
	<td width="12%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td colspan="2" height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <?php include_once('Seekermenu.htm');?> 
  <tr>
    <td align="left" valign="top" colspan="2"><form action="seekerDetails2.php" method="post" target="_self" enctype="multipart/form-data">
	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
    <td>Applicant Name</td>
    <td><input name="name" type="text" value="<?php echo $name;?>"></td>
  </tr>
  <tr>
    <td>Email Address</td>
    <td><input name="email" type="text" value="<?php echo $email;?>" readonly="true"></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input name="password" type="text" value="<?php echo $password;?>"></td>
  </tr>
  <tr>
    <td>Height Degree</td>
    <td><select name="lastdegree">
	<option><?php echo $lastdegree;?></option>
		<?php
		mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM lastdegree";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?></select></td>
  </tr>
  <tr>
    <td>Phone Number</td>
    <td><input name="phone" type="text" value="<?php echo $phone;?>"></td>
  </tr>
  <tr>
    <td>Mobile Number</td>
    <td><input name="mobile" type="text" value="<?php echo $mobile;?>"></td>
  </tr>
  <tr>
    <td valign="top">Applicant Address</td>
    <td><textarea name="address" cols="18" rows="8"><?php echo $address;?></textarea></td>
  </tr>
  <tr>
    <td>Others Qualifications</td>
    <td><textarea name="others" cols="18" rows="8"><?php echo $others;?></textarea></td>
  </tr>
  <tr>
    <td>Web Site</td>
    <td><input name="web" type="text" value="<?php echo $web;?>">
              &nbsp;&nbsp;<a href="http://www.pakwebsites.com/" target="_blank">Need a 
              website?</a></td>
  </tr>
  <tr>
    <td>Upload CV</td>
    <td><input name="cv" type="file" value=""><?php echo '['.$cv.' '.'existed'.']';?></td>
  </tr>
  <tr>
    <td>Member's Status</td>
    <td><input name="status" type="text" value="<?php echo $status; ?>" readonly="true"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td><input name="" type="submit" value="Update Info"></td>
    <td></td>
  </tr>
</table>

	
	</form></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
