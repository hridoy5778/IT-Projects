<?php session_start();?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">


</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#CCFFFF">
<?php 
if(!isset($_SESSION['login']))
{?>
  <tr>
    <td align="right" valign="top" colspan="3" bgcolor="#3333CC"><a href="signin.php" target="_self"><font face="Arial, Helvetica, sans-serif" color="#FFFFFF"><strong>SignIn/Register</strong></font></a></td>
  </tr><?php } else {?>
  <tr>
    
  <td width="8%" align="right" valign="top"><a href="signin2.php" target="_self">Control 
    Panel</a></td>
	<td width="80%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%"><a href="signin.php" target="_self">Logout</a></td>
  </tr><?php }?>
  <tr align="center" bgcolor="#3333CC">
  <td bgcolor="#3333FF"></td> 
    <td height="40%" valign="top" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong> 
	  <td valign="top" bgcolor="#3333FF"><div align="right"><strong><font size="4" face="Arial, Helvetica, sans-serif"><a href="/admin/" target="_self">Admin 
        Panel</a></font></strong></div></td>
  </tr>
  <tr><td align="center" colspan="3"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="center" valign="top" width="23%"><?php include_once('searchjob.php');?></td>
	<td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" align="center"><H2>Browse jobs by specialist area</H2><br>
<br>
To view the individual roles for each sector, please click 
on the sector title.<br>
<?php 
	include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM jobcategory";
$result = mysql_query($query);
$num = mysql_numrows($result);
mysql_close();
$i=0;
$flag = 0;
while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$name = mysql_result($result,$i,"name");
?>

<a href="jobSubSector.php?category=<?php echo $name;?>" target="_self"><?php echo $name;?></a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php
$flag = $flag+1;
if($flag ==2)
{
echo ('<br/>');
$flag =0;
}
$i++;
}
?> 
</td>
  </tr>
</table>
</td>

	<td align="center" valign="top" colspan="3"><img src="image/Nigeriamap.gif" width="241" height="400"></td>
  </tr>
  
  
  
  
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
