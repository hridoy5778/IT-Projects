<?php
session_start();
$username = $_SESSION['login'];

$password = $_SESSION['Adminpass'];
include_once('config.php');
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if($num>0)
{
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">

</head>
<body>
<table width="100%" border="0">
  <tr>
    <td></td>
  </tr>
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $username;?></td>
	<td width="12%" align="right" valign="top"><a href="./admin/index.php" target="_self">Logout</a></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#3333FF" align="center" colspan="2"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr><td width="100%" align="center" colspan="2"><?php include_once('Adminmenu.php'); ?></td></tr>
  
  <tr>
  <td><table width="100%"> <tr>
      <td>
        <?php 

if(isset($_REQUEST['id']))
{
$carry = $_REQUEST['id'];
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM layout where id='$carry'";
$result = mysql_query($query);
mysql_close();
?><table width="97%" border="0" align="center">
        <tr> 
          <td width="16%" valign="top" class="links"> <table width="153" border="1"> 
            <tr> 
                      <td height="76"> 
                        <?php include_once('leftPan.php')?>
                      </td>
</tr> </table> </td> 
<td width="84%"><form action="savePage.php" method="post" target="_self" enctype="multipart/form-data">
    <table width="98%" border="0" align="center">
      <tr> 
        
        <td width="100%">
          <?php 

include("fckeditor.php") ;
$sBasePath = $_SERVER['PHP_SELF'] ;
$sBasePath = substr( $sBasePath, 0, strpos( $sBasePath, "_samples" ) ) ;

$oFCKeditor = new FCKeditor('FCKeditor1') ;
$oFCKeditor->BasePath	= $sBasePath ;
$i=0;
$oFCKeditor->Value		= html_entity_decode(mysql_result($result,$i,"content")); //'This is some <strong>sample text</strong>. You are using <a href="http://www.fckeditor.net/">FCKeditor</a>.' ;
$oFCKeditor->Create() ;

?>
        </td>
      </tr>
      <tr> 
        <td colspan="2"> <input name="carry" type="hidden" value="<?php echo $carry; ?>" /> 
          <br> <input name="save" type="submit" value="Save Data" /> </td>
      </tr>
    </table>
  </form></td></tr>
</table>
<?php

}
else
{
?><table width="97%" border="0" align="center">
<tr> 
  <td width="16%" valign="top" class="links"> <table width="153" border="1"> <tr> 
      <td height="76"> <?php include_once('leftPan.php')?></td>
</tr> </table> </td> 
<td width="84%"><table width="80%"  border="0" cellspacing="1" cellpadding="1">
    <tr> 
      <th scope="col">Please select the edit option from the left pane</th>
    </tr>
  </table></td></tr>
</table> 
<?PHP
}
?></td></tr>
</table></td></tr> 
  
  
  <tr>
    <td><?php }
	else
	{
	?></td>
  </tr>
  <tr>
    <td align="left" valign="top">Wrong User name/Password<br>
      Please try again to <a href="index.php" target="_self">Login</a><?php }?></td>
	
  </tr>
</table>

</body>
</html>
