<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="javascript">
function re()
{
alert("Page has been updated");
window.location.href="showPage.php"
}
</script>
</head>

<body>
<?php 

$id = $_REQUEST['carry'];
$contents = $_REQUEST['FCKeditor1'];

include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "update layout set content='$contents' where id='$id'";
$result = mysql_query($query);
mysql_close();


?>
<script language="javascript">
re();
</script>
</body>
</html>
