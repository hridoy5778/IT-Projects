<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<?php
$lastdegree = $_POST['lastdegree'];
$name = $_POST['name'];
$address = $_POST['address'];
$status = $_POST['status'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$mobile = $_POST['mobile'];
$web = $_POST['web'];
$others = $_POST['others'];
$role = $_POST['role'];
$cv = $_FILES["cv"]["name"];
//echo $cv;
include_once('config.php');
?>
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="center" valign="top"></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="left" valign="top">
	<?php
$dbconnection = mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM seekerreg WHERE email = '$email'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if($num<1)
{
$cv = $email.$_FILES["cv"]["name"];
$pin = $_POST['pin'];;
$query2 = "insert into seekerreg (name,address,email,phone,mobile,web,lastdegree,others,status,cv) values('$name','$address','$email','$phone','$mobile','$web','$lastdegree','$others','$status','$cv')";
$result = mysql_query($query2);
$carry = mysql_insert_id($dbconnection);
//$pin = rand()*$carry;
$query3 = "insert into card (pin,email,status,role) values('$pin','$email','$status','$role')";
$result3 = mysql_query($query3);
mysql_close();
move_uploaded_file($_FILES["cv"]["tmp_name"],
      "cv/" .$email .$_FILES["cv"]["name"]);
      //echo "Stored in: " . "image/" . $_FILES["cv"]["name"];
      
      echo "file has been uploaded"."<br/>"."<br/>";
	  //$tmp = $_FILES["cv"]["name"];
	  //echo $tmp;
?>

</td>
  </tr>
  
 <tr><td>Thank You for Registering<br>
      Your email is:&nbsp;<?php echo $email;?><br>
Your pin code is :&nbsp;<?php echo $pin;?><br>
You will be allowed to Apply for a job<br>
Please remember your email Id & pin code.<br>
Call for details 00-0000<?php 

$to = $email;
$subject = "UserName/Pass from evolutionandRecruitment";
$message = "Hello! This is from Evolution care and recruitment."."\n\n"."User Name:  ".$email."\n\n"."Password:  ".$pin."\n\n\n\n"."Thank you";
$from = "jobs@evolutioncareandrecruitment.com";
$server = 'smtp.fasthosts.co.uk';
//$headers = "From: $from";
//mail($to,$subject,$message,$headers);
//ini_set("sendmail_from",$from);
ini_set("sendmail_from", " jobs@evolutioncareandrecruitment.com ");
mail($to, "UserName/Pass from evolutionandRecruitment", $message, "From: jobs@evolutioncareandrecruitment.com\nReply-To: " . $email . "\nX-Mailer: PHP/" . phpversion() );
} else {?></td></tr>
<tr>
    <td>Sorry! Your given email address is existed.<br>
      Please try to <a href="seekerReg.php" target="_self">Register</a> with 
      another email address. 
      <?php }?>
    </td>
  </tr>

  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
