<?php
class PageNames
{
	 public static function pageRedirect($pageRedirect)
	  { 
	 	echo "<script>location.replace (\"$pageRedirect\");</script>";
	}
}
?>