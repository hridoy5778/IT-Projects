<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM lastdegree";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
</head>

<body>
<table width="100%" border="0">
  <tr align="center" valign="top"> 
    <td></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="right" valign="top"><form action="seekerrReg2.php" method="post" target="_self" enctype="multipart/form-data">
	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
    <td width="16%">Applicant Name</td>
    <td width="84%"><input name="name" type="text"></td>
  </tr>
  <tr>
    <td>Email Address</td>
    <td><input name="email" type="text"></td>
  </tr>
  <tr>
            <td>Pin</td>
    <td><input name="pin" type="text">
Insert PIN from your registration card            </td>
  </tr>
  <tr>
    <td>Height Degree</td>
    <td><select name="lastdegree">
	<option>Select Degree</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?></select></td>
  </tr>
  <tr>
    <td>Phone Number</td>
    <td><input name="phone" type="text"></td>
  </tr>
  <tr>
    <td>Mobile Number</td>
    <td><input name="mobile" type="text"></td>
  </tr>
  <tr>
    <td valign="top">Applicant Address</td>
    <td><textarea name="address" cols="50" rows="8"></textarea></td>
  </tr>
  <tr>
            <td valign="top">Insert Skills and Experience<br>
              e.g. PHP Developer 3 months, Oracle DBA 2 years</td>
    <td><textarea name="others" cols="50" rows="8"></textarea></td>
  </tr>
  <tr>
    <td>Web Site</td>
    <td><input name="web" type="text">
              &nbsp;&nbsp;<a href="http://www.dialawebsite.co.uk/" target="_blank">Need a 
              website?</a></td>
  </tr>
  <tr>
    <td>Upload CV</td>
    <td><input name="cv" type="file"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="status" type="hidden" value="<?php echo 'active'; ?>"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="role" type="hidden" value="<?php echo 'seeker'; ?>"></td>
  </tr>
  <tr>
    <td><input name="" type="submit" value="Register Me"></td>
    <td><input name="" type="reset"></td>
  </tr>
</table>

	
	</form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
