<?php
session_start();
if(isset($_SESSION['login']))
{
$email = $_SESSION['login'];
$pin = $_SESSION['pin'];
}
else
{
$email = $_POST['email'];
$pin = $_POST['pin'];
}
include_once('config.php');
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM card WHERE email = '$email' AND pin = '$pin' AND status='active'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if($num>0)
{
$_SESSION['login']=$email;
$_SESSION['pin']=$pin;
$i = 0;
$role = mysql_result($result,$i,"role");
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td colspan="2" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;<a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr> 
    <td> 
      <?php if(isset($_REQUEST['maincategory']))
{
echo $_REQUEST['maincategory'];
$maincategory = $_REQUEST['maincategory'];
$subcategory = $_REQUEST['subcategory'];
$type = $_REQUEST['type'];
$frequency = $_REQUEST['frequency'];
$city = $_REQUEST['city'];
$post = $_REQUEST['post'];
$rop = $_REQUEST['rop'];
$description = $_REQUEST['description'];

echo "<script>";
echo "self.location"."="."'showJob.php?maincategory=".$maincategory."&subcategory=".$subcategory."&type=".$type."&city=".$city."&frequency=".$frequency."&post=".$post."&rop=".$rop."&description=".$description."';";
echo "</script>"; 

}?>
    </td>
  </tr>
  <tr> 
    <td> 
      <?php if($role == 'employeer') {?>
    </td>
  </tr>
  <?php include_once('Employeermenu.htm'); } else {?>
  <tr> 
    <td width="100%" align="center"></td>
  </tr>
  <?php include_once('Seekermenu.htm');} ?>
  <tr> 
    <td width="100%" align="center"></td>
  </tr>
  <tr> 
    <td> 
      <?php if($role == 'employeer') {?>
    </td>
  </tr>
  <tr> 
    <td align="center" valign="top">Message for Employeer How to operate 
      <?php } else {?>
    </td>
  </tr>
  <tr> 
    <td align="center" valign="top">Message for Seeker How to operate 
      <?php } } else {?>
    </td>
  </tr>
  <tr> 
    <td align="left" valign="top">Wrong User name/Password<br>
      Please try again to <a href="signin.php" target="_self">Login</a> 
      <?php }?>
    </td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
</table>

</body>
</html>
