<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}

$id = $_REQUEST['id'];
$name = $_REQUEST['name'];
$address = $_REQUEST['address'];
$email = $_REQUEST['email'];
$others = $_REQUEST['others'];
$phone = $_REQUEST['phone'];
$mobile = $_REQUEST['mobile'];
$web = $_REQUEST['web'];
$lastdegree = $_REQUEST['lastdegree'];
$password = $_REQUEST['password'];
$cv = $_FILES["cv"]["name"];
if($cv=='')
{
$cv = $_FILES["cv"]["name"];
}
else
{
move_uploaded_file($_FILES["cv"]["tmp_name"],
      "cv/" .$email .$_FILES["cv"]["name"]);
      
      
      echo "file has been uploaded"."<br/>"."<br/>";
}
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>

  <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
    <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?></td>
	<td width="12%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td colspan="2" height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <?php include_once('Seekermenu.htm');?> 
	<tr><td></td><td><?php include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$query = "UPDATE seekerreg SET name ='$name',address ='$address',others ='$others',phone ='$phone',mobile ='$mobile',web ='$web',lastdegree ='$lastdegree',cv ='$cv' WHERE email='$email'";
mysql_query($query);
$query2 = "UPDATE card SET pin='$password' WHERE email='$email'";
$result2 = mysql_query($query2);
mysql_close();?>
</td>
</tr>
<tr><td></td><td>Updation Completed</td></tr>    
  </table>

</body>
</html>
