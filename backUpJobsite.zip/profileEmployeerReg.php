<?php session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
$email = $_SESSION['login'];
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM city WHERE status='a'";
$result = mysql_query($query);
$num = mysql_num_rows($result);

$query2 = "SELECT * FROM employeerreg WHERE email='$email'";
$result2=mysql_query($query2);
$num2 = mysql_num_rows($result2);

$query3 = "SELECT * FROM card WHERE email='$email'";
$result3=mysql_query($query3);
mysql_close();

$i=0;
while ($i < $num2) 
{
$id = mysql_result($result2,$i,"id");
$company = mysql_result($result2,$i,"company");
$name = mysql_result($result2,$i,"name");
$address = mysql_result($result2,$i,"address");
$email = mysql_result($result2,$i,"email");
$phone = mysql_result($result2,$i,"phone");
$mobile = mysql_result($result2,$i,"mobile");
$web = mysql_result($result2,$i,"web");
$city = mysql_result($result2,$i,"city");
$postcode = mysql_result($result2,$i,"postcode");

$i++;
}
$j=0;
$password = mysql_result($result3,$j,"pin");


?>
</head>

<body>
<table width="100%" border="0">
<tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td height="40%" bgcolor="#3333FF" colspan="2"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  
  <?php include_once('Employeermenu.htm'); ?>
  
  <tr>
    <td align="right" valign="top"><form name="myForm" action="profileEmployeerReg2.php" method="post" target="_self">
	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>Company Name</td>
    <td><input name="company" type="text" value="<?php echo $company;?>"></td>
  </tr>
  <tr>
    <td>Contact Person Name</td>
    <td><input name="name" type="text" value="<?php echo $name;?>"></td>
  </tr>
  <tr>
    <td>Email Address</td>
    <td><input name="email" type="text" value="<?php echo $email;?>" readonly="true"></td>
  </tr>
  <tr>
    <td>Phone Number</td>
    <td><input name="phone" type="text" value="<?php echo $phone;?>"></td>
  </tr>
  <tr>
    <td>Mobile Number</td>
    <td><input name="mobile" type="text" value="<?php echo $mobile;?>"></td>
  </tr>
  <tr>
    <td valign="top">Company Address</td>
    <td><textarea name="address" cols="18" rows="8"><?php echo $address;?></textarea></td>
  </tr>
   <tr>
    <td>City Name</td>
    <td><select name="city">
	<option><?php echo $city;?></option>
		<?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?></select></td>
  </tr>
  <tr>
    <td>Post Code</td>
    <td><input name="postcode" type="text" value="<?php echo $postcode;?>"></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input name="password" type="text" value="<?php echo $password;?>" ></td>
  </tr>
  <tr>
    <td>Web Site</td>
    <td><input name="web" type="text" value="<?php echo $web;?>">
              &nbsp;&nbsp;<a href="http://www.pakwebsites.com/" target="_blank">Need a 
              website?</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td><input name="" type="submit" value="Update Info"></td>
    <td><input name="" type="reset"></td>
  </tr>
</table>

	
	</form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
