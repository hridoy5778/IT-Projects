<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM city WHERE status='a'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
</head>

<body>
<table width="100%" border="0">
  <tr align="center" valign="top"> 
    <td height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="right" valign="top"><form name="myForm" action="employeerReg2.php" method="post" target="_self">
	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>Company Name</td>
    <td><input name="company" type="text"></td>
  </tr>
  <tr>
    <td>Contact Person Name</td>
    <td><input name="name" type="text"></td>
  </tr>
  <tr>
    <td>Email Address</td>
    <td><input name="email" type="text"></td>
  </tr>
  <tr>
    <td>Phone Number</td>
    <td><input name="phone" type="text"></td>
  </tr>
  <tr>
    <td>Mobile Number</td>
    <td><input name="mobile" type="text"></td>
  </tr>
  <tr>
    <td valign="top">Company Address</td>
    <td><textarea name="address" cols="18" rows="8">&nbsp;</textarea></td>
  </tr>
   <tr>
    <td>City Name</td>
    <td><select name="city">
	<option>Select City</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$name = mysql_result($result,$i,"name");
echo "<option>";
echo $name;
echo "</option>" ; 
$i++;
}
?></select></td>
  </tr>
  <tr>
    <td>Post Code</td>
    <td><input name="postcode" type="text" ></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input name="password" type="password" ></td>
  </tr>
  <tr>
    <td>Web Site</td>
    <td><input name="web" type="text">
              &nbsp;&nbsp;<a href="http://www.dialawebsite.co.uk/" target="_blank">Need a 
              website?</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="role" type="hidden" value="<?php echo 'employeer'; ?>"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input name="status" type="hidden" value="<?php echo 'active'; ?>"></td>
  </tr>
  <tr>
    <td><input name="" type="submit" value="Register Me"></td>
    <td><input name="" type="reset"></td>
  </tr>
</table>

	
	</form></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
