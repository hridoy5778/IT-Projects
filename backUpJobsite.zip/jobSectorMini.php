<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">


</head>

<body>
<table width="100%" border="0" bgcolor="#CCFFFF">

  
  
  
  
  <tr>
    <td align="center" valign="top"></td>
	<td align="center" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td valign="top" align="center"><H2><font color="#0000FF" face="Arial, Helvetica, sans-serif">Browse 
              jobs by specialist area</font></H2>
            <div align="left"><br>
              <br>
              <font color="#0000FF" face="Arial, Helvetica, sans-serif"><strong>To 
              view the individual roles for each sector, please click on the sector 
              title.</strong></font><br>
            </div></td>
        </tr>
        <tr>
          <td valign="top" align="center">
            <?php 
	include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM jobcategory";
$result = mysql_query($query);
$num = mysql_numrows($result);
mysql_close();
$i=0;
$flag = 0;
while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$name = mysql_result($result,$i,"name");
?>
            <a href="jobSubSector.php?category=<?php echo $name;?>" target="_self"><?php echo $name;?></a>&nbsp;&nbsp;&nbsp;&nbsp; 
            <?php
$flag = $flag+1;
if($flag ==2)
{
echo ('<br/>');
$flag =0;
}
$i++;
}
?>
          </td>
        </tr>
      </table>
</td>

	<td align="center" valign="top" colspan="3"></td>
  </tr>
  
  
  
  
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
