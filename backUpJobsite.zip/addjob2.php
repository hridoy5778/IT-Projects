<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
$name = $_POST['name'];
$vacancy = $_POST['vacancy'];
$maincategory = $_POST['maincategory'];
$subcategory = $_POST['subcategory'];
$email = $_POST['email'];
$status = $_POST['status'];
$city = $_POST['city'];
$salary = $_POST['salary'];
$frequency = $_POST['frequency'];
$type = $_POST['type'];
$description = $_POST['description'];
$status="inactive";
include("config.php");
$conn = mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

?>
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="signin.php" target="_self">Logout</a></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <?php include_once('Employeermenu.htm'); ?>
  <tr><td>&nbsp;</td></tr>
  <tr><td></td></tr>
  <tr>
    <td align="left" valign="top">
<?php 
	
	$query = "INSERT INTO job (name,vacancy,maincategory,subcategory,email,status,city,salary,type,frequency,description) VALUES ('$name','$vacancy','$maincategory','$subcategory','$email','$status','$city','$salary','$type','$frequency','$description')";
$result = mysql_query($query);

$carry = mysql_insert_id($conn);
mysql_close();
if($result>0)
{
?> 
<h3>Job has been Inserted to Database......</h3><br>
Your Job Reference Id is <?php echo $carry;?><br>
<br>
Thank You.
<a href="addjob.php" target="_self">Add Job</a>
<?php } else
{
?>
<br>
<h3>Sorry!! Link status down.Please try again to entry the Job<br>
<br>
......Thank You.</h3>
<?php }?>
<br>
<br>

<a href="addjob.php" target="_self">Bact to Job Entry Page</a> 
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
