<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
//if key string is empty
if($_REQUEST['key']=='')
{
$id ='%';
$name ='%';

$status = $_REQUEST['status'];
if($status=='All')
{
$status='%';
}
else
{
$status = $_REQUEST['status'];
}
}
//if key string is not empty
else
{
$key=$_REQUEST['key'];
if($_REQUEST['rop']=='title') //if title only radio is selected
{
$id ='%';
$name = $key;
$status = $_REQUEST['status'];
if($status=='All')
{
$status='%';
}
else
{
$status = $_REQUEST['status'];
}
}//end of rop if checking
else //if refId radio selected
{
$id =$key;
$name = '%';
$status = $_REQUEST['status'];
if($status=='All')
{
$status='%';
}
else
{
$status = $_REQUEST['status'];
}
}//end of rop else checking
}//end of else
?><html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM job WHERE id LIKE '$id' AND name LIKE '$name' AND status LIKE '$status'";
$result = mysql_query($query);
$num = mysql_num_rows($result);

?>
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="center" valign="top"><table width="100%" border="0">
  <tr>
    <td></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="center" valign="top">
	<?php 
	if($num > 0)
	{
	?>
	<form action="jobstatusUpdate.php" method="post" target="_self">
	
	    <table width="100%" border="0">
          <tr>
            <td width="5%" align="center" valign="top">Change Status</td>
			<td width="10%" align="center" valign="top">Status</td>
            <td width="15%" align="center" valign="top">Job Position</td>
            <td width="50%" align="center" valign="top">Description</td>
            
            <td width="20%" align="center" valign="top">Details</td>
  </tr>
  <?php
  $i=0;
while ($i < $num) 
{
  $id = mysql_result($result,$i,"id");
  $name = mysql_result($result,$i,"name");
  $status = mysql_result($result,$i,"status");
  $description = mysql_result($result,$i,"description"); 
  
  ?>
  <tr>
            <td align="center" valign="middle" width="5%"> 
              <input name="done[]" type="checkbox" value="<?php echo $id;?>"></td>
            <td align="center" valign="middle" width="10%"> 
              <?php echo $status;?>
            </td>
            <td align="center" valign="middle" width="15%"> 
              <?php echo $name;?>
            </td>
            <td align="left" valign="middle" width="50%"> 
              <?php echo $description;?>
            </td>
            
            <td align="center" valign="middle" width="20%"> 
              <a href="jobDetails.php?id=<?php echo $id;?>">Details</a>	
	</td>
  </tr>
  <tr><td colspan="6" valign="middle"><hr></td></tr>
  <?php
$i++;
}
?> 
<tr>
            <td width="5%"></td>
            <td width="15%"> 
              <select size="1" name="status">
  <option>Select Request Status</option>
  <option value="active">Active</option>
  <option value="inactive">Inactive</option>
  </select>
              <input name="stake" type="hidden" value="<?php echo $stake;?>">
            </td>
            <td width="26%"> 
              <input name="Input" type="submit" value="Update">
            </td>
            <td width="4%"> 
              <input name="email" type="hidden" value="<?php echo $email;?>"></td>
            <td width="18%">&nbsp;</td>
            <td width="32%"></td>
</tr>
</table>
</form>
<?php
}
else
{
?>
</td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="100%" border="0">
        <tr>
          <td align="center" valign="middle">No data found</td>
  </tr>
  <tr>
    <td align="center" valign="top"><a href="searchjobStatus.php" target="_self">Go 
      back to Status Search</a>
	  <?php 
}
?></td>
  </tr>
  <tr>
          <td>&nbsp;</td>
  </tr>
</table>
 
</td>
  </tr>
</table>

</body>
</html>
