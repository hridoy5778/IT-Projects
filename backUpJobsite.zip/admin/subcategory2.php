<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
}
?><html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$description = $_POST['description'];
$name = $_POST['name'];
$category = $_POST['category'];

$query = "INSERT INTO jobsubcategory VALUES ('','$name','$description','$category')";
$result = mysql_query($query);
mysql_close();
if($result>0)
{
?> 
<h3>Sub Category name has been Inserted to Database......Thank You.</h3>
<?php } else
{
?>
<br>
<h3>Sorry!! Link status down.Please try again to entry the Sub category name<br>
<br>
......Thank You.</h3>
<?php }?>
<br>
<br>

<a href="subcategory1.php" target="_self">Bact to Sub Category Entry Page</a> 
</body>
</html>
