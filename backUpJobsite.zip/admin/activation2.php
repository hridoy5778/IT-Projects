<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
}
?><html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<style type="text/css"> 
input.button 
{
  color: #fff; background: #0034D0;
  font-size: .8em;
  font-weight:bold;
  font-family: Verdana, Arial, Helvetica, sans-serif;
  border: solid 1px #ffcf31;
}
</style> 
<script language="JavaScript" type="text/javascript" src="js/expandCollapse.js"></script>
<?php 
$stake = $_POST['stake'];
$email = $_POST['email'];
$str = $_POST['str'];
if($email!='')
{
$email=$email;
}
else
{
$email=$str.'%';
}
if($email=='' && $str=='')
{
$email='%';
}
$status = $_POST['status'];
if($status!='All')
{
$status=$status;
}
else
{
$status='%';
}

include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
if($stake =='e')
{

$query = "SELECT * FROM employeerreg WHERE email LIKE '$email' AND status LIKE '$status'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
}
if($stake =='s')
{
$query = "SELECT * FROM seekerreg WHERE email LIKE '$email' AND status LIKE '$status'";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
}
?>
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="center" valign="top"><table width="100%" border="0">
  <tr>
    <td></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="center" valign="top">
	<?php 
	if($num > 0)
	{
	?>
	<form action="activation3.php" method="post" target="_self">
	
	    <table width="100%" border="0">
          <tr>
            <td width="5%" align="center" valign="top">Change Status</td>
            <td width="15%" align="center" valign="top">Name</td>
            <td width="26%" align="center" valign="top">Address</td>
            <td width="4%" align="center" valign="top">Email</td>
            <td width="18%" align="center" valign="top">Status</td>
            <td width="32%" align="center" valign="top">Details</td>
  </tr>
  <?php
  $i=0;
while ($i < $num) 
{
  $id = mysql_result($result,$i,"id");
  $name = mysql_result($result,$i,"name");
  $address = mysql_result($result,$i,"address");
  $email = mysql_result($result,$i,"email"); 
  $phone = mysql_result($result,$i,"phone");
  $mobile = mysql_result($result,$i,"mobile");
  $status = mysql_result($result,$i,"status");
  ?>
  <tr>
            <td align="center" valign="middle" width="5%"> 
              <input name="done[]" type="checkbox" value="<?php echo $id;?>"></td>
            <td align="center" valign="middle" width="15%"> 
              <?php echo $name;?>
            </td>
            <td align="center" valign="middle" width="26%"> 
              <?php echo $address;?>
            </td>
            <td align="center" valign="middle" width="4%"> 
              <?php echo $email;?>
            </td>
            <td align="center" valign="middle" width="18%"> 
              <?php echo $status;?>
            </td>
            <td align="center" valign="middle" width="32%"> 
              <input type="button" class="button" onclick="return toggleMe('<?php echo $id;?>')" value="Details">
<div id="<?php echo $id;?>" style="display:none"> 
                <?php
   
echo 'Name '.$name.'<br/>';
echo 'Address '.$address.'<br/>';
echo 'Email '.$email.'<br/>';
echo 'Phone '.$phone.'<br/>';
echo 'Mobile '.$mobile.'<br/>';
echo 'Status '.$status.'<br/>';

	   ?>
              </div>	
	</td>
  </tr>
  <tr><td colspan="6" valign="middle"><hr></td></tr>
  <?php
$i++;
}
?> 
<tr>
            <td width="5%"></td>
            <td width="15%"> 
              <select size="1" name="status">
  <option>Select Request Status</option>
  <option value="active">Active</option>
  <option value="inactive">Inactive</option>
  </select>
              <input name="stake" type="hidden" value="<?php echo $stake;?>">
            </td>
            <td width="26%"> 
              <input name="Input" type="submit" value="Update">
            </td>
            <td width="4%"> 
              <input name="email" type="hidden" value="<?php echo $email;?>"></td>
            <td width="18%">&nbsp;</td>
            <td width="32%"></td>
</tr>
</table>
</form>
<?php
}
else
{
?>
</td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="100%" border="0">
        <tr>
          <td align="center" valign="middle">No data found</td>
  </tr>
  <tr>
    <td align="center" valign="top"><a href="activation1.php" target="_self">Go 
      back to Status Search</a>
	  <?php 
}
?></td>
  </tr>
  <tr>
          <td>&nbsp;</td>
  </tr>
</table>
 
</td>
  </tr>
</table>

</body>
</html>
