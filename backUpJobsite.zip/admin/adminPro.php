<?php
session_start();
$username = $_POST['username'];
$_SESSION['login']=$username;
$password = $_POST['password'];
$_SESSION['Adminpass']=$password;
include_once('config.php');
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
if($num>0)
{
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">

</head>
<body>
<table width="100%" border="0">
 
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $username;?></td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
   <tr>
    <td valign="top" bgcolor="#3333FF" align="center"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td><?php }
	else
	{
	?></td>
  </tr>
  <tr>
    <td align="left" valign="top">Wrong User name/Password<br>
      Please try again to <a href="index.php" target="_self">Login</a><?php }?></td>
	
  </tr>
</table>

</body>
</html>
