<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FF9900">
<form action="showJob.php" method="post" target="_self" style="background-color: #FF9900">
  <table width="30%" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FF9900">
    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;Enter 
        Keyword(s)</font></strong></td>
    </tr>
	<tr align="left"> 
      <td height="46" valign="top">
<p>&nbsp; 
          <input name="key" type="text" size="35"><br>
          <strong><font face="Arial, Helvetica, sans-serif">&nbsp; </font></strong>
        <strong><font face="Arial, Helvetica, sans-serif">
          <input name="rop" type="radio" value="title" checked>
          in title only</font></strong>&nbsp;
          <input name="rop" type="radio" value="ref">
          in Ref: Id only</td>
    </tr>
	

   

    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">Job Status</font></strong></td>
    </tr>
    <tr align="left"> 
      <td> &nbsp; &nbsp; 
        <select name="status">
          <option>All</option>
          <OPTION>Active</OPTION>
          <OPTION>Inactive</OPTION>
          
        </select></td>
    </tr>
    <tr align="left"> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr align="left"> 
      <td></td>
      <td>&nbsp;</td>
    </tr>
    <tr align="left"> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2" align="left">
          <input name="" type="submit" value="Search">
        </td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    
  </table>
</form>
</body>
</html>
