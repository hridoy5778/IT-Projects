<?php
if(isset($_SESSION['login']))
{
unset($_SESSION['login']);
session_destroy();

}
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td valign="top" bgcolor="#3333FF" align="center"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#3333FF" align="center"><?php include_once('OutAdminmenu.php');?></td>
  </tr>
  <tr>
    <td align="right" valign="top"><form action="adminPro.php" method="post" target="_self"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>User Name</td>
    <td><input name="username" type="text"></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><input name="password" type="password"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><input name="" type="submit" value="Sign In"></td>
    <td><input name="" type="reset"></td>
  </tr>
</table>
</form>

</td>
  </tr>
  
  
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
