<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
}
?><html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
</table>

<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$name = $_POST['name'];
$status = $_POST['status'];

$query = "INSERT INTO city (name,status) VALUES ('$name','$status')";
mysql_query($query);

mysql_close();
?> 
<h3>City Info have been Inserted to Database......Thank You.</h3>
<br>
<br>
<br>

<a href="cityname.php" target="_self">Bact to City Entry Page</a> 
</body>
</html>
