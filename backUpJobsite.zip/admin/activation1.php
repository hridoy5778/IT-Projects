<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
}
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT DISTINCT email FROM card order by email";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="center" valign="top"><table width="100%" border="0">
  <tr>
    <td></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#3333FF" align="center"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="center" valign="top">
	
	<form action="activation2.php" method="post" target="_self">
        <table width="100%" border="0">
          <tr> 
            <td width="8%">Stake Holder</td>
            <td width="17%"><select size="1" name="stake">
                <option>Select Role</option>
                <option value="e">Employeer</option>
                <option value="s">Job Seeker</option>
              </select></td>
            <td width="12%">Select Email Address</td>
            <td width="20%"><select name="email">
                <option></option>
                <?php
	   $i=0;
while ($i < $num) 
{
$email = mysql_result($result,$i,"email");
echo "<option>";
echo $email;
echo "</option>" ; 
$i++;
}
?>
              </select></td>
            <td width="5%">Status</td>
            <td width="26%"><select size="1" name="status">
                <option>All</option>
                <option value="inactive">Inactive</option>
                <option value="active">Active</option>
              </select></td>
            <td width="12%"></td>
          </tr>
          <tr> 
            
            <td colspan="7" align="center">OR </td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td align="center" valign="top">&nbsp; </td>
            <td align="left">Part of an email address</td>
            <td align="center"><input name="str" type="text" size="28"></td>
			<td align="left">&nbsp;</td>
			<td align="left"><input type="submit" name="Submit" value="Search"></td>
			<td align="left">&nbsp;</td>
          </tr>
        </table>
</form>
	
	
	</td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="100%" border="0">
  <tr>
    <td></td>
  </tr>
</table>
</td>
  </tr>
</table>

</body>
</html>
