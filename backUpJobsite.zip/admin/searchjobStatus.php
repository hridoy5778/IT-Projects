<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<form action="showJob.php" method="post" target="_self">
  <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
    <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?></td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#3333FF" align="center" colspan="2"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
	<tr><td width="100%" align="center" colspan="2"><?php include_once('menu.php'); ?></td></tr>
	<tr>
      <td align="center" valign="top"><font color="#FFFFFF" face="Arial, Helvetica, sans-serif"><strong><u>Search 
        Job Status</u></strong></font></td>
    </tr>
    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;Enter 
        Keyword(s)</font></strong></td>
    </tr>
	<tr align="left"> 
      <td height="46" valign="top">
<p>&nbsp; 
          <input name="key" type="text" size="35"><br>
          <strong><font face="Arial, Helvetica, sans-serif">&nbsp; </font></strong>
        <strong><font face="Arial, Helvetica, sans-serif">
          <input name="rop" type="radio" value="title" checked>
          in title only</font></strong>&nbsp;
          <input name="rop" type="radio" value="ref">
          in Ref: Id only</td>
    </tr>
	

   

    <tr align="left"> 
      <td valign="top"><strong><font face="Arial, Helvetica, sans-serif">Job Status</font></strong></td>
    </tr>
    <tr align="left"> 
      <td> &nbsp; &nbsp; 
        <select name="status">
          <option>All</option>
          <OPTION>Active</OPTION>
          <OPTION>Inactive</OPTION>
          
        </select></td>
    </tr>
    <tr align="left"> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr align="left"> 
      <td></td>
      <td>&nbsp;</td>
    </tr>
    <tr align="left"> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2" align="center"><input name="" type="submit" value="Search"></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    
  </table>
</form>
</body>
</html>
