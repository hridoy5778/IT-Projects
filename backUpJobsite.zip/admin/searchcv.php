<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}
$employeer = $_SESSION['login'];
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM lastdegree";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>
<body>
<table width="100%" border="0">
 <tr> 
    <td align="right" valign="top" colspan="3"></td>
  </tr>
  
  <tr> 
    <td width="16%" align="right" valign="top">&nbsp;</td>
    <td width="78%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
    <td width="6%"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td height="40%" bgcolor="#3333FF" colspan="3"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr><td width="100%" align="center" colspan="3"><?php include_once('menu.php'); ?></td></tr>
  <tr> 
    <td colspan="3" align="center"><?php if($num>0) { ?>
	</td>
  </tr>
  <tr> 
    <td align="center" valign="top"></td>
    <td align="center" valign="top"><form action="searchcv2.php" method="post" target="_self"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
            <td width="23%">Search skills(e.g php developer)</td>
    <td width="1%"></td>
    <td width="76%"><input name="core" type="text" value=""></td>
  </tr>
  <tr>
    <td>Highest Degree</td>
    <td>&nbsp;</td>
    <td><select name="degree">
	<option>All</option>
		<?php
	   $i=0;
while ($i < $num) 
{
$degreename = mysql_result($result,$i,"name");
echo "<option>";
echo $degreename;
echo "</option>" ; 
$i++;
}
?></select></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><input name="" type="submit" value="Search Applicants"></td>
    <td>&nbsp;</td>
    <td><input name="" type="reset"></td>
  </tr>
</table></form><?php } else {?>
Please.<br>
Select one of the searching conditions.<?php }?>
</td>
    <td align="center" valign="top"></td>
  </tr>
  
  
  
  
  
</table>

</body>
</html>
