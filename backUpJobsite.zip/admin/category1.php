<?php
session_start();
if($_SESSION['login'] =="")
{
header("location:index.php");
exit;
}
?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?></td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr>
    <td valign="top" bgcolor="#3333FF" align="center" colspan="2"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="right" valign="top">
	<form action="category2.php" method="post" target="_self">
	<table width="90%" border="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Category Name</td>
    <td valign="middle"><input name="name" type="text" id="name"></td>
  </tr>
  <tr>
    <td>Description</td>
    <td valign="middle"><textarea name="description" cols="18" rows="10"></textarea></td>
  </tr>
  
  
  <tr><td></br></td><td></br></td></tr>
  <tr><td></br></td><td></br></td></tr>
  <tr><td></br></td><td></br></td></tr>
  <tr>
    <td align="center"><input name="submit" type="submit" value="Submit"></td>
    <td align="center"><input name="" type="reset" value="Reset"></td>
  </tr>
</table>
	
	</form>
	
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
