<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}

$id = $_REQUEST['id'];
$email = $_REQUEST['email'];
$name = $_REQUEST['name'];
$city = $_REQUEST['city'];
$vacancy = $_REQUEST['vacancy'];
$salary = $_REQUEST['salary'];
$frequency = $_REQUEST['frequency'];
$type = $_REQUEST['type'];
$description = $_REQUEST['description'];
$maincategory = $_REQUEST['maincategory'];
$subcategory = $_REQUEST['subcategory'];
$postcode = $_REQUEST['postcode'];
$status = $_REQUEST['status'];
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FF9900">

  <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FF9900">
    <tr>
    <td align="right" valign="top">Welcome&nbsp;&nbsp;
    <?php echo $_SESSION['login'];?></td>
	<td align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
	<tr><td width="100%" align="center" colspan="2"><?php include_once('menu.php'); ?></td></tr>
	<tr><td><?php include_once('minisearchjobStatus.php');?></td><td><?php include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$query = "UPDATE job SET name ='$name',description ='$description',type ='$type',frequency ='$frequency',city ='$city',salary ='$salary',vacancy ='$vacancy',subcategory ='$subcategory',maincategory ='$maincategory',postcode ='$postcode',status ='$status' WHERE id='$id'";
mysql_query($query);
mysql_close();?>
</td>
</tr>
<tr><td></td><td>Updation Completed</td></tr>    
  </table>

</body>
</html>
