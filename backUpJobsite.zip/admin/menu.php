<table width="100%" border="3" cellspacing="0" cellpadding="3">
  <tr bgcolor="#FFFFFF"> 
    <td align="center" valign="middle" bordercolor="#663300"><a href="activation1.php" target="_self"><font face="Arial, Helvetica, sans-serif">Account 
      Activation</font></a></td>
	  
    <td align="center" valign="middle" bordercolor="#663300"><a href="searchjobStatus.php" target="_self"><font face="Arial, Helvetica, sans-serif">Job 
      Activation</font></a></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="category1.php" target="_self">Add 
      Job Category</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="subcategory1.php" target="_self">Add 
      Sub Category</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="cityname.php" target="_self">Add 
      City</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="lastdegree1.php" target="_self">Add 
      Degree Name</a></font></td>
    <td align="center" valign="middle" bordercolor="#663300"><font face="Arial, Helvetica, sans-serif"><a href="../showPage.php" target="_self">Contents</a></font></td>
  </tr>
</table>
