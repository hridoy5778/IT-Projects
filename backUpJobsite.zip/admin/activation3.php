<?php 
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
}
?><html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php
$status = $_POST["status"];
$stake = $_POST["stake"];
$email = $_POST["email"];
$done = $_POST["done"];

include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
if($stake =='e')
{
foreach ($done as $d) 
{
$query = "UPDATE employeerreg SET status ='$status' WHERE id='$d'";
mysql_query($query);
$query2 = "UPDATE card SET status ='$status' WHERE email='$email'";
mysql_query($query2);
}
mysql_close();
}
if($stake =='s')
{
foreach ($done as $d) 
{
$query = "UPDATE seekerreg SET status ='$status' WHERE id='$d'";
mysql_query($query);
$query2 = "UPDATE card SET status ='$status' WHERE email='$email'";
mysql_query($query2);
}
mysql_close();
}
?>
<link href="test.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="center" valign="top"><table width="90%" border="0">
  <tr>
    <td>Header</td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?>&nbsp;&nbsp;</td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr><td width="100%" align="center"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="center" valign="top"><a href="activation1.php" target="_self">Go 
      back to Status Search</a></td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="90%" border="0">
  <tr>
    <td>Footer</td>
  </tr>
</table>
</td>
  </tr>
</table>

</body>
</html>
