<?php session_start();
if(!isset($_SESSION['login']))
{
header('location:signin.php');
exit();
}?>
<html>
<head>
<title><?php include_once('title.php');?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="test.css" rel="stylesheet" type="text/css">
<?php 
$id = $_REQUEST['id'];
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM job WHERE id='$id'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close();
$i=0;

while ($i < $num) 
{
$id = mysql_result($result,$i,"id");
$email = mysql_result($result,$i,"email");
$name = mysql_result($result,$i,"name");
$city = mysql_result($result,$i,"city");
$vacancy = mysql_result($result,$i,"vacancy");
$salary = mysql_result($result,$i,"salary");
$frequency = mysql_result($result,$i,"frequency");
$type = mysql_result($result,$i,"type");
$description = mysql_result($result,$i,"description");
$maincategory = mysql_result($result,$i,"maincategory");
$subcategory = mysql_result($result,$i,"subcategory");
$postcode = mysql_result($result,$i,"postcode");
$status = mysql_result($result,$i,"status");
$i++;
}
?>
</head>

<body>
<table width="100%" border="0">
<tr>
    <td width="88%" align="right" valign="top">Welcome&nbsp;&nbsp;<?php echo $_SESSION['login'];?></td>
	<td width="12%" align="right" valign="top"><a href="index.php" target="_self">Logout</a></td>
  </tr>
  <tr align="center" valign="top"> 
    <td colspan="2" height="40%" bgcolor="#3333FF"><strong><font size="4" face="Arial, Helvetica, sans-serif"><font color="#FFFFFF">Nigeria's 
      Largest Job Site</font></font></strong></td>
  </tr>
  <tr><td width="100%" align="center" colspan="2"><?php include_once('menu.php'); ?></td></tr>
  <tr>
    <td align="left" valign="top" colspan="2"><form action="jobDetailsUpdate.php" method="post" target="_self">
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>Job's Ref:</td>
    <td><input name="id" type="text" value="<?php echo $id;?>" readonly="true"></td>
  </tr>
  <tr>
    <td>Post Name</td>
    <td><input name="name" type="text" value="<?php echo $name;?>"></td>
  </tr>
  <tr>
    <td>Vacancy</td>
    <td><input name="vacancy" type="text" value="<?php echo $vacancy;?>"></td>
  </tr>
  <tr>
    <td>Category</td>
    <td><input name="category" type="text" value="<?php echo $maincategory;?>"></td>
  </tr>
  <tr>
    <td>Sub Category</td>
    <td><input name="subcategory" type="text" value="<?php echo $subcategory;?>"></td>
  </tr>
  <tr>
    <td>City Name</td>
    <td><input name="city" type="text" value="<?php echo $city;?>"></td>
  </tr>
  <tr>
    <td>Job Type</td>
    <td><input name="type" type="text" value="<?php echo $type;?>"></td>
  </tr>
  <tr>
    <td>Salary</td>
    <td><input name="salary" type="text" value="<?php echo $salary;?>"></td>
  </tr>
  <tr>
    <td valign="top">Description</td>
    <td><textarea name="description" cols="" rows="10"><?php echo $description;?></textarea></td>
  </tr>
  
  <tr>
    <td>Payment Frequency</td>
    <td><input name="frequency" type="text" value="<?php echo $frequency;?>"></td>
  </tr>
  
  <tr>
    <td>Employer's email</td>
    <td><input name="email" type="text" value="<?php echo $email;?>" readonly="true"></td>
  </tr>
  <tr>
    <td>Posting Status</td>
    <td><input name="status" type="text" value="active"></td>
  </tr>
  <tr><td></td><td><br>
<br>
</td></tr>
  
  <tr>
    <td><input name="" type="submit" value="Update Info"></td>
    <td></td>
  </tr>
</table>
</form></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
  </tr>
  
</table>

</body>
</html>
