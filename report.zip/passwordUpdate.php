<?php
session_start();
if(!isset($_SESSION['login']))
{
header('location:index.php');
exit();
}
$username = $_SESSION['login'];
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<?php include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query = "SELECT * FROM admin WHERE username = '$username'";
$result = mysql_query($query);
$num = mysql_num_rows($result);
?>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/CityBank_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
Password Change<br>
<br>
</td>
  </tr>
  <tr><td>
<form name="form1" method="post" action="passwordUpdateSQL.php" enctype="multipart/form-data">
        <table width="45%" border="3" align="center">
		<tr>
      
    <td colspan="2"><?php 
$i = 0;
$username = mysql_result($result,$i,"username");
$password = mysql_result($result,$i,"password");


?></td>
  </tr>
          <tr>
      <td width="36%">user name</td>
    <td width="64%"><input name="username" type="text" value="<?php echo $username;?>" readonly="yes"></td>
  </tr>
  <tr> 
            <td>old password</td>
            <td><input name="password" type="text" value="<?php echo $password;?>" readonly="yes"></td>
          </tr>
  <tr>
      <td>new password</td>
      <td> 
        <input name="passwordNew" type="text"></td>
  </tr>
  
  <tr>
    <td><input name="submit" type="submit" value="Update"></td>
    <td><input name="" type="reset" value="Reset"></td>
  </tr>
</table>
 </form></td></tr>
 <tr><td colspan="2" align="center"><br>
<br>
<br><br>
<br>

<?php include_once('footer.php');?></td></tr>
 </table>
</body>
</html>