<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20%"></td>
    <td width="75%"><?php include_once('menu.php')?></td>
    <td width="5%"><a href="index.php">Logout</a></td>
  </tr>
</table>