<?php
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$ref = $_POST['ref'];
$rname = $_POST['name'];
$clDateF = $_POST['clDateF'];
$clDateT = $_POST['clDateT'];
$mem = $_POST['mem'];


if($clDateF == "")
{
$clDateF="%";
}
if($clDateT == "")
{
$clDateT=date('Y-m-d');
}
if($ref == "")
{
$ref="%";
}
if($mem == "")
{
$mem="%";
}
if($rname == "")
{
$rname="%";
}
function replace($replace,$replacewith,$inme)
{
$doit = str_replace ("$replace", "$replacewith", $inme);
return $doit;
}

$mem = replace(" ",'%',"$mem");
$rname = replace(" ",'%',"$rname");



$query = "SELECT * FROM horeportd where (name like '%$rname%' and member like '%$mem%')";

$result = mysql_query($query);
$num = mysql_num_rows($result);
mysql_close(); 

?>

<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/CityBank_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center">
Detail Report<br>

<?php 
	if($num == 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>No 
  Records Found.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another search conditions</strong></font>');
exit();
}
?>
</td>
  </tr>
  <tr> 
  <td colspan="6" align="left">
  <table width="100%" align="left">
        <tr> 
          <td width="10%" bgcolor="#CCCCCC">Ref: Number</td>
          <td width="35%" bgcolor="#CCCCCC">Report Name</td>
          <td width="10%" bgcolor="#CCCCCC">Audit Date</td>
          <td width="10%" bgcolor="#CCCCCC">Report Date</td>
          <td width="20%" bgcolor="#CCCCCC">Team Members</td>
          <td width="10%" bgcolor="#CCCCCC">Report Download</td>
  </tr>
  </table></td></tr>
  
<?php

$i=0;


while ($i < $num) 
{
if($i==0)
{
$rColor='#FFFFCC';
}
if($i %2 != 0)
{
$rColor='#CCCCCC';
}
if($i %2 == 0)
{
$rColor='#FFFFCC';
}

$out = mysql_result($result,$i,"out");
$name = mysql_result($result,$i,"name");
$idate = mysql_result($result,$i,"idate");
$rdate = mysql_result($result,$i,"rdate");
$member = mysql_result($result,$i,"member");
$file = mysql_result($result,$i,"file");


?> 
<tr><td width="100%">



</td></tr>
      <table border="0" cellspacing="3" width="100%">
        <tr bgcolor="<?php echo $rColor; ?>">
 <td width="10%"><font color="#000000"><?php echo $out;?></font></td>
          <td width="35%"><font color="#000000"><?php echo $name;?></font></td>
          <td width="10%"><font color="#000000"><?php echo $idate;?></font></td>
		  <td width="10%"><font color="#000000"><?php echo $rdate;?></font></td>
		  <td width="20%"><font color="#000000"><?php echo $member;?></font></td>
          <td width="10%"><font color="#000000"><a href="./report/ho/detail/<?php echo $file;?>">Download REPORT</a></font></td>
    
  </tr>
  
</table>






<?php

$i++; 



}

?>  
  
  
  
  
</table>
</body>
</html>
