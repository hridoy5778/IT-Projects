-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 28, 2011 at 11:49 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `reportarchive`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `ip` varchar(50) default NULL,
  `hostName` varchar(100) default NULL,
  `dt` varchar(100) default NULL,
  `newUser` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `ip`, `hostName`, `dt`, `newUser`) VALUES
(19, '2010352', 'abcd1234.', '127.0.0.1', '192.168.214.40', 'December28,2011,11:11 am', 'n'),
(20, 'sadat3450', 'abcd1234.', '127.0.0.1', '127.0.0.1', 'February18,2011,8:07 am', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assign`
--

DROP TABLE IF EXISTS `assign`;
CREATE TABLE IF NOT EXISTS `assign` (
  `SLID` int(11) NOT NULL auto_increment,
  `PCN` int(11) default NULL,
  `TrainingCode` int(11) default NULL,
  `assignDate` date NOT NULL,
  `trainingDate` date default NULL,
  PRIMARY KEY  (`SLID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `assign`
--

INSERT INTO `assign` (`SLID`, `PCN`, `TrainingCode`, `assignDate`, `trainingDate`) VALUES
(1, 5778, 2, '2011-02-07', '2011-02-16'),
(2, 2021, 3, '2011-02-07', '2011-02-24'),
(3, 5778, 5, '2011-02-07', '2011-02-07'),
(4, 2010352, 3, '2011-02-02', '2011-02-24'),
(5, 2010325, 2, '2011-02-02', '2011-02-16'),
(6, 2010456, 1, '2011-01-14', '2011-02-06'),
(7, 2010789, 4, '2011-02-22', '2011-02-18'),
(8, 2010352, 4, '2011-02-11', '2011-02-18'),
(9, 2010852, 4, '2011-02-11', '2011-02-18'),
(10, 1983013, 4, '2011-02-11', '2011-02-18'),
(11, 2010456, 4, '2011-02-11', '2011-02-18'),
(12, 2011123, 4, '2011-02-11', '2011-02-18'),
(13, 2010352, 4, '2011-02-11', '2011-02-18'),
(14, 2010789, 2, '2011-02-11', '2011-02-16'),
(15, 2010326, 2, '2011-02-11', '2011-02-16'),
(16, 2010352, 4, '2011-02-11', '2011-02-18'),
(17, 2010352, 4, '2011-02-11', '2011-02-18'),
(18, 1983013, 3, '2011-02-11', '2011-02-24'),
(19, 2010456, 4, '2011-02-11', '2011-02-18'),
(20, 2010352, 6, '2011-02-11', '2011-02-06'),
(21, 2010352, 4, '2011-02-11', '2011-02-18'),
(22, 2010352, 1, '2011-02-11', '2011-02-06'),
(23, 1983013, 1, '2011-02-11', '2011-02-06');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE IF NOT EXISTS `branch` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`) VALUES
(1, 'ICCD'),
(2, 'Principal Office Branch'),
(3, 'Information Technology'),
(4, 'Banani Branch'),
(5, 'RFC'),
(6, 'Retail Banking');

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

DROP TABLE IF EXISTS `grade`;
CREATE TABLE IF NOT EXISTS `grade` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`id`, `name`) VALUES
(1, 'VP'),
(2, 'FVP'),
(3, 'SAVP'),
(4, 'AVP'),
(5, 'SEO'),
(6, 'SO'),
(7, 'Stenographer'),
(8, 'JCO'),
(9, 'EO'),
(10, 'Sr.Com.Op'),
(11, 'Officer'),
(12, 'SCO'),
(13, 'CO'),
(14, 'SECO'),
(15, 'ECO'),
(16, 'JO'),
(17, 'EVP'),
(18, 'ACO'),
(19, 'SVP'),
(20, 'SEVP'),
(21, 'DMD'),
(22, 'MD'),
(23, 'Test job grade2'),
(24, 'test3 job grade');

-- --------------------------------------------------------

--
-- Table structure for table `inspection`
--

DROP TABLE IF EXISTS `inspection`;
CREATE TABLE IF NOT EXISTS `inspection` (
  `id` int(11) NOT NULL auto_increment,
  `out` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `idate` date default NULL,
  `rdate` date default NULL,
  `file` varchar(255) default NULL,
  `member` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `inspection`
--

INSERT INTO `inspection` (`id`, `out`, `name`, `idate`, `rdate`, `file`, `member`) VALUES
(1, '1234', 'abcd', '2011-12-02', '2011-12-28', 'Investigation Report on Moneytary Fraud-Account Bismillah Fabrics.pdf', 'a\r\nb\r\nc\r\nd'),
(2, '1234', '', '0000-00-00', '0000-00-00', '', ''),
(3, '1234', 'fdfdsf', '2011-12-02', '2011-12-28', 'Investigation report on SSC-Foreign Exchange.pdf', 'fd\r\ndf\r\ndf\r\nd'),
(4, '1234', 'abcd', '2011-12-20', '2011-12-28', 'Report on Prada Fashion Ltd.pdf', 'a\r\nb\r\nv\r\n'),
(5, '1234', 'abcd', '2011-12-14', '2011-12-28', 'Investigation report on SSC-Foreign Exchange.pdf', 'd\r\nf\r\nb\r\n'),
(6, '1234', 'abcd', '2011-12-20', '2011-12-28', 'Investigation Report on Moneytary Fraud-Account Bismillah Fabrics.pdf', 'd\r\nf\r\ng\r\nh'),
(7, '1234', 'abcd', '2011-12-13', '2011-12-28', 'Report on Prada Fashion Ltd.pdf', 'a\r\nb\r\nc\r\nd'),
(8, '1234', '', '0000-00-00', '0000-00-00', '', ''),
(9, '1234', 'abcd', '2011-12-06', '2011-12-28', 'Investigation report on duplicate cheque payment SSC-PO.pdf', 's\r\nd\r\nf'),
(10, '1234', '', '0000-00-00', '0000-00-00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sal`
--

DROP TABLE IF EXISTS `sal`;
CREATE TABLE IF NOT EXISTS `sal` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sal` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sal`
--

INSERT INTO `sal` (`id`, `name`, `sal`) VALUES
(1, 'a', 23),
(2, 'b', 275),
(3, 'c', 10),
(4, 'd', 82),
(5, 'g', 52),
(6, 'b', 63);

-- --------------------------------------------------------

--
-- Table structure for table `training`
--

DROP TABLE IF EXISTS `training`;
CREATE TABLE IF NOT EXISTS `training` (
  `TrainingCode` int(11) NOT NULL auto_increment,
  `TrainingDate` date default NULL,
  `Title` varchar(255) default NULL,
  `Venue` varchar(255) default NULL,
  `Organizedby` varchar(255) default NULL,
  PRIMARY KEY  (`TrainingCode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `training`
--

INSERT INTO `training` (`TrainingCode`, `TrainingDate`, `Title`, `Venue`, `Organizedby`) VALUES
(1, '2011-02-06', 'ABC', 'DHK', 'HRD'),
(2, '2011-02-16', '123', 'CTG', 'IT'),
(3, '2011-02-24', 'Basic', 'Banani', 'ICCD'),
(4, '2011-02-18', 'Professional', 'Gulshan', 'RFC'),
(5, '2011-02-07', 'Test training name', 'Dilkusha building', 'ICCD'),
(6, '2011-02-06', '2nd Test traing', 'Old buliding', 'IT');
