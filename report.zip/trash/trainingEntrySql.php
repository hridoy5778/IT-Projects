<html>
<head>

<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");


$name = $_POST['name'];
$ven = $_POST['ven'];
$org = $_POST['org'];
$clDate = $_POST['clDate'];
/*

$querySearch = "select * from employee where pcn = '$pcn'";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num > 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Record already existed.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another PCN</strong></font><br>
<br>
<br>
<a href="employeeEntry.php" target="_parent">Bact to Employee Entry Page</a>');
exit();
}
*/
$query = "INSERT INTO training VALUES ('','$clDate','$name','$ven','$org')";
mysql_query($query);

mysql_close();
?> 
<h3>Training Info have been Inserted to Database......Thank You.</h3>
<br>
<br>
<br>

<a href="trainingEntry.php" target="_parent">Bact to Training Entry Page</a> </div>
    
   

</body>
</html>













<body>

</body>
</html>
