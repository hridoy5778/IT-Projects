<html>
<head>

<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");



$pcn = $_POST['pcn'];
$code = $_POST['code'];
$assdate = $_POST['assdate'];
//echo $code;
$query1 = "select * from training where trainingcode = $code";
$result1 = mysql_query($query1);
$num1 = mysql_num_rows($result1);
$i=0;
$trainingdate = mysql_result($result1,$i,"trainingdate");
//echo $trainingdate;
/*
$query = "select * from employee where pcn = '$pcn'";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num > 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Record already existed.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please use 

another PCN</strong></font><br>
<br>
<br>
<a href="employeeEntry.php" target="_parent">Bact to Employee Entry Page</a>');
exit();
}
*/
$query = "INSERT INTO assign VALUES ('','$pcn','$code','$assdate','$trainingdate')";
mysql_query($query);

mysql_close();
?> 
<h3>Training Allocation Info have been Inserted to Database......Thank You.</h3>
<br>
<br>
<br>

<a href="assignEntry.php" target="_parent">Bact to Training Allocation Page</a> </div>
    
   

</body>
</html>













<body>

</body>
</html>
