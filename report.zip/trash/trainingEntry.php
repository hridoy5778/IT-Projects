<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">@import url(./jscalendar/calendar-win2k-1.css);</style>
<script type="text/javascript" src="./jscalendar/calendar.js"></script>
<script type="text/javascript" src="./jscalendar/lang/calendar-en.js"></script>
<script type="text/javascript" src="./jscalendar/calendar-setup.js"></script>
<link rel="stylesheet" href="dropdown.css" type="text/css" />
<script type="text/javascript" src="dropdown.js"></script>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
/*$query = "SELECT name FROM grade order by name";
$result = mysql_query($query);
$num = mysql_num_rows($result);
$query2 = "SELECT name FROM branch order by name";
$result2 = mysql_query($query2);
$num2 = mysql_num_rows($result2);*/
mysql_close();
?>
</head>

<body>
<table width="100%" border="0">
  <tr> 
    <td width="100%"><div align="center"><img src="images/CityBank_Banner.jpg" width="1000" height="106"></div></td>
  </tr>
  <tr> 
    <td width="100%"><?php include_once('header.php');?></td>
  </tr>
  
  <tr> 
    <td width="100%" align="center"><br>
<br>
New Training Entry<br>
<br>
</td>
  </tr>
  <tr><td>
<form name="form1" method="post" action="trainingEntrySql.php">
        <table width="45%" border="3" align="center">
          <tr>
      <td width="28%">training title</td>
    <td width="72%"><input name="name" type="text" size="40">
     </td>
  </tr>
  <tr>
      <td>training venue</td>
    <td><input name="ven" type="text" size="40"></td>
  </tr>
  <tr>
            <td>training date</td>
      <td> 
        <input name="clDate" type="text" size="40" id="clDate" readonly="true">
                      <img src="images/search_calendar.png" id="calF"
style="cursor: pointer; border: 1px solid red;"
title="Date selector" /></td>
  </tr>
  <tr>
      <td>organizer</td>
    <td><input name="org" type="text" size="40"></td>
  </tr>
  
  <tr>
    <td><input name="submit" type="submit" value="ADD ENTRY"></td>
    <td><input name="" type="reset" value="Reset"></td>
  </tr>
</table>
 </form></td></tr>
 <tr><td colspan="2" align="center"><br>
<br>
<br><br>
<br>

<?php include_once('footer.php');?></td></tr>
 </table>
 
 <script type="text/javascript">
Calendar.setup({
inputField : "clDate",
ifFormat : "%Y-%m-%d",
button : "calF",
align : "T1",
singleClick : true
});
</script>
</body>
</html>
