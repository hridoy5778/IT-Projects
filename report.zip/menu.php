<dl class="dropdown">
  <dt id="one-ddheader" onmouseover="ddMenu('one',1)" onmouseout="ddMenu('one',-1)">Investigation</dt>
  <dd id="one-ddcontent" onmouseover="cancelHide('one')" onmouseout="ddMenu('one',-1)">
    <ul>
      <li><a href="investigationEntry.php" class="underline">New Submission</a></li>
      <li><a href="investigationSearch.php" class="underline">Report Search</a></li>
      
    </ul>
  </dd>
</dl>

<dl class="dropdown">
  <dt id="two-ddheader" onmouseover="ddMenu('two',1)" onmouseout="ddMenu('two',-1)">Branch Audit</dt>
  <dd id="two-ddcontent" onmouseover="cancelHide('two')" onmouseout="ddMenu('two',-1)">
    <ul>
      <li><a href="branchReportEntry.php" class="underline">Executive Summary Submission</a></li>
      <li><a href="highLightReportEntry.php" class="underline">High Lights Submission</a></li>
      <li><a href="detailReportEntry.php" class="underline">Detail Report Submission</a></li>
      <li><a href="branchReportSearch.php" class="underline">Executive Summary Search</a></li>
      <li><a href="highLightReportSearch.php" class="underline">High Lights Search</a></li>
      <li><a href="detailReportSearch.php" class="underline">Detail Report Search</a></li>
    </ul>
  </dd>
</dl>

<dl class="dropdown">
  <dt id="three-ddheader" onmouseover="ddMenu('three',1)" onmouseout="ddMenu('three',-1)">Head Office Audit</dt>
  <dd id="three-ddcontent" onmouseover="cancelHide('three')" onmouseout="ddMenu('three',-1)">
    <ul>
      <li><a href="HOReportEntry.php" class="underline">Executive Summary Submission</a></li>
      <li><a href="HOReportDetailEntry.php" class="underline">Details Report Submission</a></li>
      <li><a href="HOReportSearch.php" class="underline">Executive Summary Search</a></li>
      <li><a href="HOReportDetailSearch.php" class="underline">Details Report Search</a></li>
      </ul>
  </dd>
</dl>

<dl class="dropdown">
  <dt id="four-ddheader" onmouseover="ddMenu('four',1)" onmouseout="ddMenu('four',-1)">Maintenance</dt>
  <dd id="four-ddcontent" onmouseover="cancelHide('four')" onmouseout="ddMenu('four',-1)">
    <ul>
      <li><a href="branchEntry.php" class="underline">New Branch</a></li>
      <li><a href="reportTypeEntry.php" class="underline">Division/Department</a></li>
      <li><a href="passwordUpdate.php">Change Password</a></li>
    </ul>
  </dd>
</dl>


<div style="clear:both" />