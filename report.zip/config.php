<?php 
$db = "reportarchive";			// Database Name 
$dbhost = "localhost";		// Database Host
$dbuser = root;		// Database Username
$dbpass = "";		// Database Password
?>