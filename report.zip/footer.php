<font color="#FF0000" face="Courier New, Courier, mono"><strong><em>All Rights 
Reserved @ ICCD, city bank limited.........</em></strong></font>
