<?php
session_start();
if(isset($_SESSION['login']))
{
$usr = $_SESSION['login'];
$ip = $_SESSION['ip'];
include_once('config.php');
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");
$query2 = "update admin set ip = '$ip' where username = '$usr'";
$result2 = mysql_query($query2);
mysql_close();

unset($_SESSION['login']);
session_destroy();

}
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<table width="100%" border="0">

<tr><td colspan="2" align="center"><div align="center"><img src="images/CityBank_Banner.jpg" width="1000" height="106"></div></td></tr>
<tr><td colspan="2"><br>
<br>
<br>
</td></tr>
<tr>
    <td colspan="2" align="center"><strong><font size="4" face="Arial, Helvetica, sans-serif">Report Repository System</font></strong></td>
  </tr>
<tr>
    <td align="left" valign="top"><form action="login.php" method="post" target="_self">
              <font color="#000000" face="Arial, Helvetica, sans-serif"><strong>User 
                    Name</strong></font></td>
					<td><input name="username" type="text"></td>
                </tr>
                
<tr> 
    <td><font color="#000000" face="Arial, Helvetica, sans-serif"><strong>Password</strong></font></td>
                  <td width="81%"><input name="password" type="password"></td>
                </tr>
                
                <tr> 
                  <td></td>
                  <td><input name="" type="submit" value="Sign In"></td>
              </tr>

 <tr><td colspan="2"><br><br><br><br><br><br></td></tr> 
 <tr><td colspan="2"><?php include_once('footer.php');?></td></tr>
</table>
</body>
</html>