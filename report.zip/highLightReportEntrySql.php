<html>
<head>

<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php 
include("config.php");
mysql_connect($dbhost,$dbuser,$dbpass);
@mysql_select_db($db) or die( "Unable to select database");

$out = $_POST['out'];
$name = $_POST['name'];
$type = $_POST['type'];
$brn = $_POST['brn'];
$risk = $_POST['risk'];
$iDate = $_POST['iDate'];
$rDate = $_POST['rDate'];
$inv = $_FILES["inv"]["name"];
$mem = $_POST['mem'];
//echo $inv;
//echo $out;
$querySearch = "SELECT * FROM `brreporth` WHERE `out` =$out";
$result = mysql_query($querySearch);
$num = mysql_num_rows($result);
//echo $num;
if($num > 0)
{
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>High Lights Report has already uploaded.</strong></font><br><br>');
echo ('<font color="#0000FF" size="4" face="Arial, Helvetica, sans-serif"><strong>Please upload new High Lights Report</strong></font><br>
<br>
<br>
<a href="highLightReportEntry.php" target="_parent">Bact to Highlight Report Submission Page</a>');
exit();
}
$name = $type." on ".$brn;
$query = "INSERT INTO brreporth VALUES ('','$out','$name','$type','$brn','$risk','$iDate','$rDate','$inv','$mem')";
mysql_query($query);

mysql_close();

move_uploaded_file($_FILES["inv"]["tmp_name"],"report/branch/highLight/".$_FILES["inv"]["name"]);
      //echo "Stored in: " . "image/" . $_FILES["cv"]["name"];
      
      //echo "file has been uploaded"."<br/>"."<br/>";
	  //$tmp = $_FILES["cv"]["name"];
	  //echo $tmp;
?> 
<h3>Copy of High Lights Report has been Uploaed to Database......<br><br>Thank You.</h3>
<br>
<br>
<br>

<a href="highLightReportEntry.php" target="_parent">Bact to Report of High Lights Submission Page</a> </div>
</body>
</html>













<body>

</body>
</html>
