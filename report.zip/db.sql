-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 14, 2012 at 06:53 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `reportarchive`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `ip` varchar(50) default NULL,
  `hostName` varchar(100) default NULL,
  `dt` varchar(100) default NULL,
  `newUser` varchar(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `ip`, `hostName`, `dt`, `newUser`) VALUES
(1, '2008015', 'Cbl%1234', '', '', '', ''),
(2, '1983013', 'Cbl%1234', '', '', '', ''),
(3, '1983033', 'Cbl%1234', '', '', '', ''),
(4, '1984038', 'Cbl%1234', '', '', '', ''),
(5, '1984043', 'Cbl%1234', '', '', '', ''),
(6, '1996002', 'Cbl%1234', '', '', '', ''),
(7, '1999018', 'Cbl%1234', '', '', '', ''),
(8, '1989016', 'Cbl%1234', '', '', '', ''),
(9, '1985024', 'Cbl%1234', '', '', '', ''),
(10, '2003051', 'Cbl%1234', '', '', '', ''),
(11, '2010364', 'Cbl%1234', '', '', '', ''),
(12, '2011092', 'Cbl%1234', '192.168.214.194', '192.168.214.118', 'January4,2012,10:45 am', ''),
(13, '2007013', 'Cbl%1234', '', '', '', ''),
(14, '1987014', 'Cbl%1234', '', '', '', ''),
(15, '1988032', 'Cbl%1234', '', '', '', ''),
(16, '2011071', 'Cbl%1234', '', '', '', ''),
(17, '1988083', 'Cbl%1234', '', '', '', ''),
(18, '2010327', 'Cbl%1234', '', '', '', ''),
(19, '2010353', 'Cbl%1234', '', '', '', ''),
(20, '2009180', 'Cbl%1234', '', '', '', ''),
(21, '2011043', 'Cbl%1234', '', '', '', ''),
(22, '2011066', 'Cbl%1234', '', '', '', ''),
(23, '2011093', 'Cbl%1234', '192.168.214.96', '192.168.214.118', 'January4,2012,10:42 am', ''),
(24, '2011108', 'Cbl%1234', '', '', '', ''),
(25, '1995041', 'Cbl%1234', '192.168.214.32', '192.168.214.118', 'January4,2012,12:04 pm', ''),
(26, '2010329', '123456', '192.168.100.99', '192.168.214.118', 'January4,2012,10:54 am', 'n'),
(27, '2010352', 'Cbl%1234', '127.0.0.1', '127.0.0.1', 'January14,2012,6:51 pm', ''),
(28, '2011101', 'Cbl%1234', '', '', '', ''),
(29, '2011185', 'Cbl%1234', '192.168.214.181', '192.168.214.118', 'January4,2012,11:08 am', ''),
(30, '2010348', 'Cbl%1234', '', '', '', ''),
(31, '2010386', 'Cbl%1234', '', '', '', ''),
(32, '2011058', 'Cbl%1234', '192.168.214.142', '192.168.214.118', 'January5,2012,5:58 am', ''),
(33, '2011060', '356025', '192.168.214.24', '192.168.214.118', 'January4,2012,10:52 am', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
CREATE TABLE IF NOT EXISTS `branch` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`) VALUES
(1, 'PRINCIPAL OFFICE'),
(2, 'B.B. AVENUE'),
(3, 'PABNA'),
(4, 'AGRABAD'),
(5, 'KHATUNGONJ'),
(6, 'IMAMGONJ'),
(7, 'BANDAR BAZAR'),
(8, 'BANGABANDHU ROAD BR.-NARAYANGONJ'),
(9, 'ZINZIRA'),
(10, 'RANGPUR'),
(11, 'JOHNSON ROAD'),
(12, 'ISLAMPUR ROAD'),
(13, 'KHULNA'),
(14, 'BOW BAZAR'),
(15, 'BOGRA'),
(16, 'COMILLA'),
(17, 'PATHERHAT'),
(18, 'TANGAIL'),
(19, 'MOULVI BAZAR'),
(20, 'JESSORE'),
(21, 'JUBILEE ROAD'),
(22, 'RAJSHAHI'),
(23, 'MYMENSINGH'),
(24, 'SAIDPUR'),
(25, 'DHAKA DAKSHIN'),
(26, 'NEW MARKET'),
(27, 'NARSHINGDI'),
(28, 'CHOUDDAGRAM'),
(29, 'BANDARTILA'),
(30, 'GULSHAN'),
(31, 'TONGI'),
(32, 'CHANDPUR'),
(33, 'FENI'),
(34, 'SIRAJGONJ'),
(35, 'GOBINDAGONJ'),
(36, 'KADAMTALI'),
(37, 'COXS BAZAR'),
(38, 'NAWABGONJ'),
(39, 'SHAYMOLI'),
(40, 'ZINDABAZAR'),
(41, 'DHANMONDI'),
(42, 'DAULATGONJ'),
(43, 'LAXMIPUR'),
(44, 'KAWRAN BAZAR'),
(45, 'SATKANIA'),
(46, 'ANDERKILLA BR.'),
(47, 'BARISAL'),
(48, 'AMBERKHANA'),
(49, 'NETAIGONJ'),
(50, 'KUSHTIA'),
(51, 'PAHARTALI'),
(52, 'POSTA'),
(53, 'HAJIGONJ'),
(54, 'REKABI BAZAR'),
(55, 'FARIDPUR'),
(56, 'KALIGONJ'),
(57, 'CHAUMUHANI'),
(58, 'MOUCHAK'),
(59, 'DINAJPUR'),
(60, 'MADHABDI'),
(61, 'SREEMONGAL'),
(62, 'FOREIGN EX.BR.'),
(63, 'BENAPOLE'),
(64, 'MANIKGONJ'),
(65, 'MIRPUR'),
(66, 'NOWABPUR'),
(67, 'URDU ROAD'),
(68, 'O.R. NIZAM ROAD'),
(69, 'JAGANNATHPUR'),
(70, 'CHAPAINAWABGONJ'),
(71, 'SATKHIRA'),
(72, 'SHERPUR'),
(73, 'SADARGHAT'),
(74, 'BHAIRAB BAZAR'),
(75, 'DHAKA CHAMBER'),
(76, 'UTTARA'),
(77, 'ISLAMIC BANKING'),
(78, 'BEANI BAZAR'),
(79, 'CHAWKBAZAR'),
(80, 'BISHAWNATH'),
(81, 'VIP ROAD'),
(82, 'PRAGATI SARANI'),
(83, 'DSE NIKUNJA'),
(84, 'KOCHUA'),
(85, 'GULSHAN AVENUE'),
(86, 'B. BARIA'),
(87, 'BANANI'),
(88, 'PROBARTAK CROSSING'),
(89, 'PALLABI-MIRPUR'),
(90, 'MOGH BAZAAR'),
(91, 'KISHORGONJ SME SERVICE CENTRE'),
(92, 'LOHAGORA SME SERVICE CENTRE'),
(93, 'JAMALPUR SME SERVICE CENTRE'),
(94, 'GAZIPUR SME SERVICE CENTRE'),
(95, 'CHATAK SME/AGRI BRANCH'),
(96, 'SAVAR SME SERVICE CENTRE'),
(97, 'JATRABARI SME SERVICE CENTRE'),
(98, 'JOYPARA SME SERVICE CENTRE'),
(99, 'BHATIARY SME SERVICE CENTRE'),
(100, 'MAIJDI SME SERVICE CENTRE'),
(101, 'HABIGANJ SME SERVICE CENTRE'),
(102, 'NATORE SME/AGRI BRANCH');

-- --------------------------------------------------------

--
-- Table structure for table `brreport`
--

DROP TABLE IF EXISTS `brreport`;
CREATE TABLE IF NOT EXISTS `brreport` (
  `id` int(11) NOT NULL auto_increment,
  `out` int(11) default NULL,
  `name` varchar(255) default NULL,
  `type` varchar(255) default NULL,
  `branch` varchar(255) default NULL,
  `risk` varchar(255) default NULL,
  `idate` date default NULL,
  `rdate` date default NULL,
  `file` varchar(255) default NULL,
  `member` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `brreport`
--

INSERT INTO `brreport` (`id`, `out`, `name`, `type`, `branch`, `risk`, `idate`, `rdate`, `file`, `member`) VALUES
(1, 7568, '', 'Executive Summary', 'Banani Branch', NULL, '2012-01-01', '2012-01-02', 'Cashcounters.pdf', 'k\r\nl'),
(2, 9632, '', 'High Lights', 'Principal Office Branch', NULL, '2012-01-01', '2012-01-02', 'Office Order on VISA_Audit.doc', 'p\r\no\r\ni'),
(3, 7561, '', 'Details Report', 'Principal Office Branch', NULL, '2012-01-01', '2012-01-03', 'All Lecture Slides - Law, Circulars, STR Indicators, Self Assessment & ITP.pdf', 'j\r\nl\r\nm'),
(4, 4589, '', 'Details Report', 'Principal Office Branch', NULL, '2012-01-01', '2012-01-03', 'muna.png', 'yu'),
(5, 7412, 'Report on RMD', 'Executive Summary', 'RMD', NULL, '2012-01-01', '2012-01-03', 'BB_ICT_GuideLine.pdf', 'a\r\ns\r\nd'),
(6, 9546, 'Head office detail', 'Details Report', 'GAD', NULL, '2012-01-01', '2012-01-03', 'CBL IT Security Policy.pdf', 'y\r\nt\r\ny'),
(7, 0, '', 'High Lights', 'Select Branch', NULL, '0000-00-00', '0000-00-00', '', ''),
(8, 9643, '', 'Executive Summary', 'BARISAL', 'Excellent', '2012-01-02', '2012-01-09', 'Investigation report on SSC-Foreign Exchange.pdf', 't\r\ne\r\ns\r\nt'),
(9, 1234, '', 'Executive Summary', 'BOGRA', 'Excellent', '2012-01-01', '2012-01-10', 'Special Investigation report of SSC-Feni.pdf', 'l'),
(10, 1234, '', 'Executive Summary', 'BOGRA', 'Excellent', '2012-01-02', '2012-01-16', 'Investigation Report on Moneytary Fraud-Account Bismillah Fabrics.pdf', 'a\r\ns'),
(11, 1234, '', 'Executive Summary', 'BOGRA', 'Excellent', '2012-01-02', '2012-01-10', 'Special Investigation of forged cheque on Lankabangla Securities Ltd.pdf', 'j'),
(12, 1234, '', 'Executive Summary', 'Select Branch', 'Excellent', '2012-01-01', '2012-01-10', 'Review Special Investigation Report as of 21.11.2011.pdf', 'k'),
(13, 1234, '', 'Executive Summary', 'BOGRA', 'Excellent', '2012-01-02', '2012-01-10', 'Special Investigation Report on Ms United Trade Corporation.pdf', 'a\r\ns'),
(14, 1234, '', 'Executive Summary', 'BOGRA', 'Excellent', '2012-01-02', '2012-01-10', 'Investigation Report on Marine Security Service of DSE Nikunja Branch.pdf', 'j'),
(15, 5778, 'Executive Summary on DHAKA CHAMBER', 'Executive Summary', 'DHAKA CHAMBER', 'Excellent', '2012-01-02', '2012-01-13', 'lab2.pdf', 's\r\na\r\nd\r\na\r\nt'),
(16, 3456, 'Executive Summary on Select Branch', 'Executive Summary', 'Select Branch', 'Select Risk Grade', '0000-00-00', '0000-00-00', '', ''),
(17, 5771, 'Executive Summary on DHANMONDI', 'Executive Summary', 'DHANMONDI', 'Good', '2012-01-02', '2012-01-13', 'lab2.pdf', 'c\r\nv'),
(18, 786, 'test ho report', 'Executive Summary', 'IT Division', 'Not defined', '2012-01-02', '2012-01-12', 'Name.docx', 'omar sadat'),
(19, 963, 'detail test exe ho', '', 'RFC', 'Good', '2012-01-03', '2012-01-12', 'contact.txt', 'hridoy');

-- --------------------------------------------------------

--
-- Table structure for table `brreportd`
--

DROP TABLE IF EXISTS `brreportd`;
CREATE TABLE IF NOT EXISTS `brreportd` (
  `id` int(11) NOT NULL auto_increment,
  `out` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `type` varchar(255) default NULL,
  `branch` varchar(255) default NULL,
  `risk` varchar(255) default NULL,
  `idate` date default NULL,
  `rdate` date default NULL,
  `file` varchar(255) default NULL,
  `member` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `brreportd`
--

INSERT INTO `brreportd` (`id`, `out`, `name`, `type`, `branch`, `risk`, `idate`, `rdate`, `file`, `member`) VALUES
(1, '5778', 'Details Report on DHAKA DAKSHIN', 'Details Report', 'DHAKA DAKSHIN', '', '2012-01-03', '2012-01-10', 'lab2.pdf', 'gb'),
(2, '967', 'Details Report on DHAKA DAKSHIN', 'Details Report', 'DHAKA DAKSHIN', '', '2012-01-03', '2012-01-13', 'lab2.pdf', 'd\r\nf');

-- --------------------------------------------------------

--
-- Table structure for table `brreporth`
--

DROP TABLE IF EXISTS `brreporth`;
CREATE TABLE IF NOT EXISTS `brreporth` (
  `id` int(11) NOT NULL auto_increment,
  `out` int(11) default NULL,
  `name` varchar(255) default NULL,
  `type` varchar(255) default NULL,
  `branch` varchar(255) default NULL,
  `risk` varchar(255) default NULL,
  `idate` date default NULL,
  `rdate` date default NULL,
  `file` varchar(255) default NULL,
  `member` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `brreporth`
--

INSERT INTO `brreporth` (`id`, `out`, `name`, `type`, `branch`, `risk`, `idate`, `rdate`, `file`, `member`) VALUES
(1, 1234, 'High Lights on DHAKA CHAMBER', 'High Lights', 'DHAKA CHAMBER', 'Excellent', '2012-01-02', '2012-01-13', 'Acknowledgement.pdf', 'ghj'),
(2, 5771, 'High Lights on DAULATGONJ', 'High Lights', 'DAULATGONJ', 'Good', '2012-01-02', '2012-01-11', 'muna.png', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `brrisk`
--

DROP TABLE IF EXISTS `brrisk`;
CREATE TABLE IF NOT EXISTS `brrisk` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `brrisk`
--

INSERT INTO `brrisk` (`id`, `name`) VALUES
(1, 'Excellent'),
(2, 'Good'),
(3, 'Satisfactory'),
(4, 'Unsatisfactory'),
(5, 'Poor'),
(6, 'Not defined');

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

DROP TABLE IF EXISTS `grade`;
CREATE TABLE IF NOT EXISTS `grade` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`id`, `name`) VALUES
(1, 'CPC Chittagong'),
(2, 'CPC Dhaka'),
(3, 'RFC'),
(4, 'HRD'),
(5, 'GAD'),
(6, 'CAD-Corporate-Dhaka'),
(7, 'CAD-Corporate-CTG'),
(8, 'CAD-SME-Medium-Dhaka'),
(9, 'CAD-SME-Medium-CTG'),
(10, 'CAD-SME-Small-CTG'),
(11, 'CAD-SME-Small-Dhaka'),
(12, 'SMA Management'),
(13, 'Cards-VISA'),
(14, 'Cards-AMEX'),
(15, 'Treasury'),
(16, 'RMD'),
(17, 'NRB'),
(18, 'Finance'),
(19, 'ADC'),
(20, 'IT Division');

-- --------------------------------------------------------

--
-- Table structure for table `inspection`
--

DROP TABLE IF EXISTS `inspection`;
CREATE TABLE IF NOT EXISTS `inspection` (
  `id` int(11) NOT NULL auto_increment,
  `out` int(11) default NULL,
  `name` varchar(255) default NULL,
  `idate` date default NULL,
  `rdate` date default NULL,
  `file` varchar(255) default NULL,
  `member` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `inspection`
--

INSERT INTO `inspection` (`id`, `out`, `name`, `idate`, `rdate`, `file`, `member`) VALUES
(1, 1234, 'abcd', '2011-12-02', '2011-12-28', 'Investigation Report on Moneytary Fraud-Account Bismillah Fabrics.pdf', 'a\r\nb\r\nc\r\nd'),
(2, 1234, '', '0000-00-00', '0000-00-00', '', ''),
(3, 1234, 'fdfdsf', '2011-12-02', '2011-12-28', 'Investigation report on SSC-Foreign Exchange.pdf', 'fd\r\ndf\r\ndf\r\nd'),
(4, 1234, 'abcd', '2011-12-20', '2011-12-28', 'Report on Prada Fashion Ltd.pdf', 'a\r\nb\r\nv\r\n'),
(5, 1234, 'abcd', '2011-12-14', '2011-12-28', 'Investigation report on SSC-Foreign Exchange.pdf', 'd\r\nf\r\nb\r\n'),
(6, 1234, 'abcd', '2011-12-20', '2011-12-28', 'Investigation Report on Moneytary Fraud-Account Bismillah Fabrics.pdf', 'd\r\nf\r\ng\r\nh'),
(7, 1234, 'abcd', '2011-12-13', '2011-12-28', 'Report on Prada Fashion Ltd.pdf', 'a\r\nb\r\nc\r\nd'),
(8, 1234, '', '0000-00-00', '0000-00-00', '', ''),
(9, 1234, 'abcd', '2011-12-06', '2011-12-28', 'Investigation report on duplicate cheque payment SSC-PO.pdf', 's\r\nd\r\nf'),
(10, 1234, '', '0000-00-00', '0000-00-00', '', ''),
(11, 7894, 'test abc', '2012-01-01', '2012-01-02', 'CBL IT Asset Requisition Form.doc', 'a\r\ns\r\nd'),
(12, 3456, '', '2012-01-01', '2012-01-02', 'APPRAISAL FORM_NEW.doc', 'e\r\ng\r\nh\r\nh'),
(13, 1234, 'asdf', '2012-01-01', '2012-01-10', 'Investigation report on duplicate cheque payment SSC-PO.pdf', 'a\r\ns'),
(14, 3456, 'asdf', '2012-01-02', '2012-01-13', 'lab2.pdf', 'f'),
(15, 5849, 'zxcv', '2012-01-02', '2012-01-13', 'Acknowledgement.pdf', 'e\r\nf');
